<?php
/**
 * WHMCS Language File
 * French (fr)
 *
 * Please Note: These language files are overwritten during software updates
 * and therefore editing of these files directly is not advised. Instead we
 * recommend that you use overrides to customise the text displayed in a way
 * which will be safely preserved through the upgrade process.
 *
 * For instructions on overrides, please visit:
 *   https://developers.whmcs.com/languages/overrides/
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2018
 * @license    https://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       https://www.whmcs.com/
 */

if (!defined("WHMCS")) die("This file cannot be accessed directly");

$_LANG['locale'] = "fr_FR";

$_LANG['accountinfo'] = "Informations sur le compte";
$_LANG['accountstats'] = "Statistiques du compte";
$_LANG['addfunds'] = "Ajouter des fonds";
$_LANG['addfundsamount'] = "Montant à ajouter";
$_LANG['addfundsmaximum'] = "Dépôt maximum";
$_LANG['addfundsmaximumbalance'] = "Solde maximal";
$_LANG['addfundsmaximumbalanceerror'] = "Le solde maximal est de";
$_LANG['addfundsmaximumerror'] = "Le dépôt maximum est de";
$_LANG['addfundsminimum'] = "Dépôt minimum";
$_LANG['addfundsminimumerror'] = "Le dépôt minimum est de";
$_LANG['addmore'] = "Ajouter";
$_LANG['addtocart'] = "Ajouter au panier";
$_LANG['affiliatesactivate'] = "Activer le compte d'affilié";
$_LANG['affiliatesamount'] = "Montant";
$_LANG['affiliatesbalance'] = "Solde courant";
$_LANG['affiliatesbullet1'] = "Recevez un boni initial dans votre compte d'affilié de";
$_LANG['affiliatesbullet2'] = "de chaque paiement de tout client nous référant un consommateur adhérant à l'un de nos plans d'hébergement Web.";
$_LANG['affiliatescommission'] = "Commission";
$_LANG['affiliatesdescription'] = "Cliquez ici pour adhérer à notre programme d'affilié.";
$_LANG['affiliatesdisabled'] = "Nous n'offrons pas de système d'affiliés actuellement.";
$_LANG['affiliatesearn'] = "Gagne";
$_LANG['affiliatesearningstodate'] = "Gains jusqu'à maintenant";
$_LANG['affiliatesfootertext'] = "lorsque vous référez une personne à notre site web avec votre identifiant unique, un cookie est placé sur l'ordinateur du référencé contenant votre identification. Si le site est placé dans les favoris et que le client revient plus tard, vous recevrez votre commission.";
$_LANG['affiliateshostingpackage'] = "Plan d'hébergement";
$_LANG['affiliatesintrotext'] = "Activer votre compte d'affilié aujourd'hui:";
$_LANG['affiliateslinktous'] = "Lien vers nous";
$_LANG['affiliatesnosignups'] = "Aucun signataire jusqu'à maintenant";
$_LANG['affiliatesrealtime'] = "Ces statistiques sont en temps réel et mises à jour instantanément.";
$_LANG['affiliatesreferallink'] = "Lien unique de référence";
$_LANG['affiliatesreferals'] = "Vos références";
$_LANG['affiliatesregdate'] = "Date d'inscription";
$_LANG['affiliatesrequestwithdrawal'] = "Demander un retrait";
$_LANG['affiliatessignupdate'] = "Date de signature";
$_LANG['affiliatesstatus'] = "État";
$_LANG['affiliatestitle'] = "Affiliés";
$_LANG['affiliatesvisitorsreferred'] = "Nombre de visiteurs référés";
$_LANG['affiliateswithdrawalrequestsuccessful'] = "Votre demande de retrait a été soumise. Nous vous contacterons bientôt.";
$_LANG['affiliatesWithdrawalRequestUnsuccessful'] = "Your request for a withdrawal was not successful. Please try again later.";
$_LANG['affiliateswithdrawn'] = "Montant total retiré";
$_LANG['all'] = "Tous";
$_LANG['alreadyregistered'] = "Déjà inscrit ?";
$_LANG['announcementsdescription'] = "Afficher les dernières nouvelles/annonces.";
$_LANG['announcementsnone'] = "Aucune nouvelles/annonces à afficher";
$_LANG['announcementsrss'] = "Afficher le flux RSS";
$_LANG['announcementstitle'] = "Actualités";
$_LANG['announcementscontinue'] = "Continuer la lecture";
$_LANG['bannedbanexpires'] = "Le bannissement se termine";
$_LANG['bannedbanreason'] = "Raison :";
$_LANG['bannedhasbeenbanned'] = "a été bannie";
$_LANG['bannedtitle'] = "IP Bannie";
$_LANG['bannedyourip'] = "Votre adresse IP";
$_LANG['cartaddons'] = "Ajouts";
$_LANG['cartbrowse'] = "Parcourir les produits & services";
$_LANG['cartconfigdomainextras'] = "Configurer les options du domaine";
$_LANG['cartconfigoptionsdesc'] = "Ce produit/service a des options supplémentaires que vous pouvez ajouter à votre commande.";
$_LANG['cartconfigserver'] = "Configurer le serveur";
$_LANG['cartcustomfieldsdesc'] = "Ce produit/service requiert des informations supplémentaires afin de nous permettre d'exécuter votre commande.";
$_LANG['cartdomainsconfig'] = "Configuration des domaines";
$_LANG['cartdomainsconfigdesc'] = "Ci-dessous, vous pouvez configurer les domaines de votre panier en choisissant les services supplémentaires désirés. Indiquez les informations requises et inscrivez les serveurs DNS qui seront utilisés.";
$_LANG['cartdomainshashosting'] = "Est hébergé";
$_LANG['cartdomainsnohosting'] = "Aucun hébergement ! Cliquez pour en ajouter un";
$_LANG['carteditproductconfig'] = "Modifier la configuration";
$_LANG['cartempty'] = "Votre panier est vide";
$_LANG['cartemptyconfirm'] = "Êtes-vous certain de vouloir vider votre panier ?";
$_LANG['cartexistingclientlogin'] = "Connexion client";
$_LANG['cartexistingclientlogindesc'] = "Pour ajouter cette commande à votre compte, connectez-vous ci-dessous.";
$_LANG['cartnameserversdesc'] = "Si vous voulez utiliser des serveurs DNS personnalisés, inscrivez-les ci-dessous. Par défaut pour les nouveaux domaines, nous utilisons nos propres serveurs DNS pour l'hébergement sur notre réseau.";
$_LANG['cartproductaddons'] = "Produits additionnels";
$_LANG['cartproductaddonschoosepackage'] = "Choisir le produit";
$_LANG['cartproductaddonsnone'] = "Aucun produits ou services additionnels disponibles";
$_LANG['cartproductconfig'] = "Configuration des produits";
$_LANG['cartproductdesc'] = "Le produit/service que vous avez choisi a des options supplémentaires parmi lesquelles vous pouvez choisir.";
$_LANG['cartproductdomain'] = "Nom de domaines";
$_LANG['cartproductdomainchoose'] = "Choisir un nom de domaine";
$_LANG['cartproductdomaindesc'] = "Le produit/service que vous avez choisi requiert un nom de domaine. Inscrivez le nom de domaine ci-dessous.";
$_LANG['cartproductdomainuseincart'] = "Utiliser un nom de domaine déjà présent dans mon panier.";
$_LANG['cartremove'] = "Enlever";
$_LANG['cartremoveitemconfirm'] = "Voulez-vous supprimer cet article de votre panier ?";
$_LANG['carttaxupdateselections'] = "Les taxes peuvent être ajoutées en fonction de l'état, de la province ou du pays choisi. Cliquez pour recalculer après avoir fait vos choix.";
$_LANG['carttaxupdateselectionsupdate'] = "Mettre à jour";
$_LANG['carttitle'] = "Votre panier";
$_LANG['changessavedsuccessfully'] = "Changements sauvegardés avec succès!";
$_LANG['checkavailability'] = "Vérifier la disponibilité";
$_LANG['checkout'] = "Finaliser vos achats";
$_LANG['choosecurrency'] = "Sélectionnez la devise";
$_LANG['choosedomains'] = "Choisir les noms de domaine";
$_LANG['clickheretologin'] = "Cliquez ici pour vous connecter";
$_LANG['clientareaaccountaddons'] = "Ajouts";
$_LANG['clientareaactive'] = "Actif";
$_LANG['clientareaaddfundsdisabled'] = "Nous n'autorisons pas l'ajout de fonds à l'avance pour le moment.";
$_LANG['clientareaaddfundsnotallowed'] = "Vous devez avoir au moins une commande active avant de pouvoir ajouter des fonds!";
$_LANG['clientareaaddon'] = "Ajouts";
$_LANG['clientareaaddonorderconfirmation'] = "Merci. Votre demande d'ajout a été placée. Veuillez choisir ci-dessous votre mode de paiement.";
$_LANG['clientareaaddonpricing'] = "Prix";
$_LANG['clientareaaddonsfor'] = "Ajout de";
$_LANG['clientareaaddress1'] = "Adresse 1";
$_LANG['clientareaaddress2'] = "Adresse 2";
$_LANG['clientareabwlimit'] = "Bande passante disponible";
$_LANG['clientareabwusage'] = "Bande passante utilisée";
$_LANG['clientareacancel'] = "Annuler";
$_LANG['clientareacancelconfirmation'] = "Merci. Votre demande d'annulation a été transmise. S'il s'agit d'une erreur, veuillez nous en aviser en nous envoyant une demande de support afin d'éviter que votre compte ne soit annulé.";
$_LANG['clientareacancelinvalid'] = "ERREUR! Le compte pour lequel vous demandez une annulation est déjà en attente d'annulation.";
$_LANG['clientareacancellationendofbillingperiod'] = "Fin de la période de facturation";
$_LANG['clientareacancellationimmediate'] = "Immédiate";
$_LANG['clientareacancellationtype'] = "Type d'annulation";
$_LANG['clientareacancelled'] = "Annulé";
$_LANG['clientareacancelproduct'] = "Demande d'annulation pour";
$_LANG['clientareacancelreason'] = "Veuillez décrire brièvement la raison de l'annulation";
$_LANG['clientareacancelrequest'] = "Demande d'annulation du compte";
$_LANG['clientareacancelrequestbutton'] = "Demande d'annulation";
$_LANG['clientareachangepassword'] = "Modifier le mot de passe";
$_LANG['clientareachangesuccessful'] = "Vos informations ont été modifiées avec succès";
$_LANG['clientareachoosecontact'] = "Choisir le contact";
$_LANG['clientareacity'] = "Ville";
$_LANG['clientareacompanyname'] = "Nom d'entreprise";
$_LANG['clientareaconfirmpassword'] = "Confirmer le mot de passe";
$_LANG['clientareacontactsemails'] = "Préférences courriel";
$_LANG['clientareacontactsemailsdomain'] = "Courriels noms de domaines - Avis de renouvellement, Confirmation d'enregistrement, etc.";
$_LANG['clientareacontactsemailsgeneral'] = "Courriels généraux - Annonces & rappels de mots de passe";
$_LANG['clientareacontactsemailsinvoice'] = "Courriels de facturation  - Facturation et rappels";
$_LANG['clientareacontactsemailsproduct'] = "Courriels produits - Détails de commande, messages de bienvenue, etc.";
$_LANG['clientareacontactsemailssupport'] = "Courriels de support - Autorise l'utilisateur à ouvrir des demandes de support";
$_LANG['clientareacountry'] = "Pays";
$_LANG['clientareacurrentsecurityanswer'] = "Veillez entrer votre réponse à la question précédente";
$_LANG['clientareacurrentsecurityquestion'] = "Merci de choisir votre question de sécurité";
$_LANG['clientareadeletecontact'] = "Supprimer ce contact";
$_LANG['clientareadeletecontactareyousure'] = "Êtes-vous certain de vouloir supprimer ce contact?";
$_LANG['clientareadescription'] = "Cliquez ici pour modifier vos informations, afficher les détails de votre facturation ou pour commander des services additionnels.";
$_LANG['clientareadisklimit'] = "Espace disponible";
$_LANG['clientareadiskusage'] = "Espace utilisé";
$_LANG['clientareadomainexpirydate'] = "Date d'expiration";
$_LANG['clientareadomainnone'] = "Aucun nom de domaine enregistré chez nous";
$_LANG['clientareaemail'] = "Adresse courriel";
$_LANG['clientareaemails'] = "Mes courriels";
$_LANG['clientareaemailsdate'] = "Date d'envoi";
$_LANG['clientareaemailsintrotext'] = "Ci-dessous se trouve l'historique des courriels que nous vous avons fait parvenir. Vous pourrez les consulter facilement où cas où vous les auriez égarés.";
$_LANG['clientareaemailssubject'] = "Objet du message";
$_LANG['clientareaerroraddress1'] = "Vous n'avez pas inscrit votre adresse (ligne 1)";
$_LANG['clientareaerroraddress12'] = "Votre adresse doit contenir uniquement des lettres, chiffres ou espaces.";
$_LANG['clientareaerrorbannedemail'] = "Les utilisateurs utilisant ce fournisseur de courriel ne sont pas autorisés sur ce site. Essayez une autre adresse de courriel.";
$_LANG['clientareaerrorcity'] = "Vous n'avez pas inscrit le nom de votre ville";
$_LANG['clientareaerrorcity2'] = "Le nom de la ville doit contenir uniquement des lettres ou des espaces.";
$_LANG['clientareaerrorcountry'] = "Veuillez choisir votre pays dans la liste déroulante.";
$_LANG['clientareaerroremail'] = "Vous n'avez pas inscrit votre adresse courriel";
$_LANG['clientareaerroremailinvalid'] = "L'adresse courriel inscrite n'est pas valide";
$_LANG['clientareaerroremailexists'] = "L'adresse e-mail saisie est déjà utilisée.";
$_LANG['clientareaerrorusernotassoc'] = "L'adresse e-mail saisie n'est pas disponible.";
$_LANG['clientareaerrorfirstname'] = "Vous n'avez pas inscrit votre prénom";
$_LANG['clientareaerrorfirstname2'] = "Le prénom doit contenir uniquement des lettres";
$_LANG['clientareaerrorisrequired'] = "est requis";
$_LANG['clientareaerrorlastname'] = "Vous n'avez pas inscrit votre nom";
$_LANG['clientareaerrorlastname2'] = "Votre nom doit contenir uniquement des lettres";
$_LANG['clientareaerroroccured'] = "Une erreur est survenue. Veuillez essayer plus tard.";
$_LANG['clientareaerrorpasswordconfirm'] = "Vous avez omis de confirmer votre mot de passe";
$_LANG['clientareaerrorpasswordnotmatch'] = "Les mots de passe saisis sont différents";
$_LANG['clientareaerrorphonenumber'] = "Vous n'avez pas inscrit votre numéro de téléphone";
$_LANG['clientareaerrorphonenumber2'] = "Le numéro de téléphone doit contenir uniquement des chiffres ou des espaces.";
$_LANG['clientareaerrorpostcode'] = "Vous n'avez pas inscrit votre code postal";
$_LANG['clientareaerrorpostcode2'] = "Votre code postal doit contenir uniquement des lettres, des chiffres ou des espaces.";
$_LANG['clientareaerrors'] = "Les erreurs suivantes se sont produites :";
$_LANG['clientareaerrorstate'] = "Vous n'avez pas inscrit le nom de votre département";
$_LANG['clientareaerrorlanguage'] = "A valid language was not provided";
$_LANG['clientareaexpired'] = "Expiré";
$_LANG['clientareafirstname'] = "Prénom";
$_LANG['clientareafraud'] = "Fraude";
$_LANG['clientareafullname'] = "Nom complet";
$_LANG['clientareaheader'] = "Bienvenue dans votre espace client. Dans cette section, vous pourrez afficher et modifier les informations vous concernant, afficher les informations de vos packs hébergement, envoyer des demandes d'aide et commander des produits ou services additionnels.";
$_LANG['clientareahostingaddons'] = "Ajouts";
$_LANG['clientareahostingaddonsintro'] = "Vous avez les ajouts suivants pour ce produit.";
$_LANG['clientareahostingaddonsview'] = "Afficher";
$_LANG['clientareahostingamount'] = "Montant";
$_LANG['clientareahostingdomain'] = "Domaine";
$_LANG['clientareahostingnextduedate'] = "Date d'échéance";
$_LANG['clientareahostingpackage'] = "Plan";
$_LANG['clientareahostingregdate'] = "Date d'inscription";
$_LANG['clientarealastname'] = "Nom";
$_LANG['clientarealastupdated'] = "Dernière mise à jour";
$_LANG['clientarealeaveblank'] = "Ne rien inscrire sauf si vous voulez modifier votre mot de passe.";
$_LANG['clientareamodifydomaincontactinfo'] = "Modifier les informations de contact du nom de domaine";
$_LANG['clientareamodifynameservers'] = "Modifier les Serveurs DNS";
$_LANG['clientareamodifywhoisinfo'] = "Modifier les informations de contact WHOIS";
$_LANG['clientareanameserver'] = "Serveurs DNS";
$_LANG['clientareanavaddcontact'] = "Ajouter un contact";
$_LANG['clientareanavchangecc'] = "Modifier les détails de la carte de crédit";
$_LANG['clientareanavchangepw'] = "Modifier le mot de passe";
$_LANG['clientareanavdetails'] = "Mes informations";
$_LANG['clientareanavdomains'] = "Mes noms de domaines";
$_LANG['clientareanavhome'] = "Espace client";
$_LANG['clientareanavlogout'] = "Quitter";
$_LANG['clientareanavorder'] = "Commander des produits supplémentaires";
$_LANG['clientareanavsecurityquestions'] = "Changer votre question de sécurité";
$_LANG['clientareanavservices'] = "Mes produits & services";
$_LANG['clientareanavsupporttickets'] = "Support";
$_LANG['clientareanocontacts'] = "Aucun contact trouvé";
$_LANG['clientareapassword'] = "Mot de passe";
$_LANG['clientareapending'] = "En attente";
$_LANG['clientareapendingregistration'] = "Enregistrement en cours";
$_LANG['clientareapendingtransfer'] = "Transfert en cours";
$_LANG['clientareaphonenumber'] = "Téléphone";
$_LANG['clientareapostcode'] = "Code Postal";
$_LANG['clientareaproductdetails'] = "Info-produit";
$_LANG['clientareaproducts'] = "Mes produits & services";
$_LANG['clientareaproductsnone'] = "Aucun Produits/Services commandés";
$_LANG['clientarearegistrationperiod'] = "Durée d'enregistrement";
$_LANG['clientareasavechanges'] = "Sauvegarder les modifications";
$_LANG['clientareasecurityanswer'] = "Merci d'entrer une réponse";
$_LANG['clientareasecurityconfanswer'] = "Veuillez confirmer votre réponse";
$_LANG['clientareasecurityquestion'] = "Veuillez choisir une question";
$_LANG['clientareaselectcountry'] = "Sélectionner le pays";
$_LANG['clientareasetlocking'] = "Bloquer";
$_LANG['clientareastate'] = "Département";
$_LANG['clientareastatus'] = "État";
$_LANG['clientareasuspended'] = "Suspendu";
$_LANG['clientareaterminated'] = "Terminé";
$_LANG['clientareaticktoenable'] = "Cocher pour activer";
$_LANG['clientareatitle'] = "Espace client";
$_LANG['clientareaunlimited'] = "Illimitée";
$_LANG['clientareaupdatebutton'] = "Mettre à jour";
$_LANG['clientareaupdateyourdetails'] = "Mise à jour de vos informations";
$_LANG['clientareaused'] = "Utilisée";
$_LANG['clientareaviewaddons'] = "Afficher les ajouts disponibles";
$_LANG['clientareaviewdetails'] = "Afficher les détails";
$_LANG['clientarealanguage'] = "Language";
$_LANG['clientlogin'] = "Connexion client";
$_LANG['clientregisterheadertext'] = "Complétez les champs ci-dessous pour créer un nouveau compte. Les champs comportant un astérisque (*) sont obligatoires.";
$_LANG['clientregistertitle'] = "Inscription";
$_LANG['clientregisterverify'] = "Vérifier l'inscription";
$_LANG['clientregisterverifydescription'] = "Veuillez entrer le texte qui se trouve dans l'image ci-dessous dans la case prévue. Ceci est requis pour empêcher les enregistrements automatisés par des 'robots'.";
$_LANG['clientregisterverifyinvalid'] = "Code de l'image incorrect";
$_LANG['closewindow'] = "Fermer cette fenêtre";
$_LANG['completeorder'] = "Régler la commande";
$_LANG['confirmnewpassword'] = "Confirmer le nouveau mot de passe";
$_LANG['contactemail'] = "Courriel";
$_LANG['contacterrormessage'] = "Vous n'avez pas inscrit le message";
$_LANG['contacterrorname'] = "Vous n'avez pas inscrit votre nom";
$_LANG['contacterrorsubject'] = "Vous n'avez pas inscrit l'objet du message";
$_LANG['contactheader'] = "Si vous avez des questions avant de commander ou si vous désirez nous contacter, veuillez compléter le formulaire ci-dessous.";
$_LANG['contactmessage'] = "Message";
$_LANG['contactname'] = "Nom";
$_LANG['contactsend'] = "Envoyer Message";
$_LANG['contactUs'] = "Nous contacter";
$_LANG['contactsent'] = "Message envoyé";
$_LANG['contactsubject'] = "Sujet";
$_LANG['contacttitle'] = "Contactez-nous";
$_LANG['continueshopping'] = "Continuer vos achats";
$_LANG['creditcard'] = "Payer par carte de crédit";
$_LANG['creditcard3dsecure'] = "A des fins de prévention contre la fraude, nous vous demandons de vérifier le code de sécurité de votre carte Visa ou Mastercard si vous avez activé ce mode de paiement pour ce service.";
$_LANG['creditcardcardexpires'] = "Date d'expiration";
$_LANG['creditcardcardissuenum'] = "Cas numéro";
$_LANG['creditcardcardnumber'] = "Numéro de la carte";
$_LANG['creditcardcardstart'] = "Date de début";
$_LANG['creditcardcardtype'] = "Type de Carte";
$_LANG['creditcardccvinvalid'] = "Le code de la carte est invalide";
$_LANG['creditcardconfirmation'] = "Merci! Vos informations ont été acceptées et le premier paiement a été fait avec succès. Un courriel de confirmation vous a été envoyé.";
$_LANG['creditcardcvvnumber'] = "Numéro CVV/CVC2";
$_LANG['creditcardcvvnumbershort'] = "CVV/CVC2";
$_LANG['creditcardcvvwhere'] = "Où puis-je le trouver?";
$_LANG['creditcarddeclined'] = "Votre carte a été refusée. Essayez avec une autre carte ou contactez notre service clientèle.";
$_LANG['creditcarddetails'] = "Détails de la carte de crédit";
$_LANG['creditcardenterexpirydate'] = "Vous n'avez pas inscrit la date d'expiration";
$_LANG['creditcardenternewcard'] = "Inscrire les informations de la nouvelle carte ci-dessous";
$_LANG['creditcardenternumber'] = "Vous n'avez pas entré votre numéro de carte";
$_LANG['creditcardinvalid'] = "Les informations inscrites sont invalides. Essayez avec une autre carte ou contactez notre centre de support.";
$_LANG['creditcardnumberinvalid'] = "Le numéro de la carte de crédit n'est pas valide";
$_LANG['creditcardsecuritynotice'] = "Toutes les données inscrites ici sont envoyées de façon sécurisée et sont cryptées pour éviter les risques de fraude.";
$_LANG['creditcarduseexisting'] = "Utiliser la carte existante";
$_LANG['customfieldvalidationerror'] = "Valeur incorrecte";
$_LANG['days'] = "Jours";
$_LANG['hours'] = "Heures";
$_LANG['minutes'] = "Minutes";
$_LANG['seconds'] = "Secondes";
$_LANG['defaultbillingcontact'] = "Contact de facturation par défaut";
$_LANG['domainalternatives'] = "Essayez ces autres choix :";
$_LANG['domainavailable'] = "Disponible! Commander maintenant";
$_LANG['domainavailable1'] = "Félicitations!";
$_LANG['domainavailable2'] = "est disponible!";
$_LANG['domainavailableexplanation'] = "Pour enregistrer ce nom de domaine cliquez sur le lien ci-dessous";
$_LANG['domainbulksearch'] = "Recherche de noms de domaines multiples";
$_LANG['domainbulksearchintro'] = "Recherchez jusqu'à 20 noms de domaines en même temps. Entrez les noms de domaines un par ligne, sans mettre de http:// ou de www.";
$_LANG['domainbulktransferdescription'] = "Vous pouvez transféré vos noms de domaine actuels chez nous aujourd'hui. Pour démarrer, entrez simplement ceux-ci ci-dessous, un par ligne, sans www. ni http://";
$_LANG['domainbulktransfersearch'] = "Transfert en bloc de noms de domaine";
$_LANG['domaincontactinfo'] = "Info contact";
$_LANG['domaincurrentrenewaldate'] = "Date de renouvellement";
$_LANG['domaindnsaddress'] = "Adresse";
$_LANG['domaindnshostname'] = "Nom de l'hôte";
$_LANG['domaindnsmanagement'] = "Gestion DNS";
$_LANG['domaindnsmanagementdesc'] = "Pointe votre nom de domaine vers un site web pointant vers une adresse IP, ou redirige vers un autre site, ou pointe vers une page temporaire (connu en tant que domaine garé), et plus. Ces enregistrements sont également connus en tant que sous-domaines.";
$_LANG['domaindnsrecordtype'] = "Type d'enregistrement";
$_LANG['domainemailforwarding'] = "Redirection courriel";
$_LANG['domainemailforwardingdesc'] = "Si le serveur de redirection des courriels détermine que la redirection est invalide, nous désactiverons l'enregistrement de redirection automatiquement. Veuillez vérifier l'adresse de redirection avant de la réactiver. Les modifications d'une redirection existante peuvent prendre jusqu'à 1 heure avant de prendre effet.";
$_LANG['domainemailforwardingforwardto'] = "Rediriger vers";
$_LANG['domainemailforwardingprefix'] = "Préfixe";
$_LANG['domaineppcode'] = "Code EPP";
$_LANG['domaineppcodedesc'] = "Doit être obtenu du registraire courant pour autorisation";
$_LANG['domaineppcoderequired'] = "Vous devez inscrire le code EPP pour";
$_LANG['domainerror'] = "Il y a eu une erreur de connexion au registre du domaine. Veuillez réessayer plus tard.";
$_LANG['domainerrornodomain'] = "Inscrivez un nom de domaine valide";
$_LANG['domainerrortoolong'] = "Le nom de domaine inscrit est trop long. Les noms de domaine ne peuvent avoir une longueur supérieure à 67 caractères.";
$_LANG['domaingeteppcode'] = "Obtenez le code EPP";
$_LANG['domaingeteppcodeemailconfirmation'] = "Le code EPP vient d'être envoyé à l'adresse du titulaire du nom de domaine.";
$_LANG['domaingeteppcodeexplanation'] = "Le code EPP permet d'initier le transfert d'un nom de domaine vers un autre opérateur de domaines.";
$_LANG['domaingeteppcodefailure'] = "Une erreur s'est produite lors de la demande du code EPP :";
$_LANG['domaingeteppcodeis'] = "Le code EPP pour votre nom de domaine est :";
$_LANG['domainidprotection'] = "Protection ID";
$_LANG['domainintrotext'] = "Inscrivez le nom du domaine et l'extension que vous désirez utiliser ci-dessous. Cliquez sur Vérifier pour voir si le nom de domaine est disponible pour enregistrement.";
$_LANG['domainlookupbutton'] = "Vérifier";
$_LANG['domainmanagementtools'] = "Outils de gestion";
$_LANG['domainminyears'] = "Années Min.";
$_LANG['domainmoreinfo'] = "Plus d'infos";
$_LANG['domainname'] = "Nom de domaine";
$_LANG['domainnameserver1'] = "Serveur DNS 1";
$_LANG['domainnameserver2'] = "Serveur DNS 2";
$_LANG['domainnameserver3'] = "Serveur DNS 3";
$_LANG['domainnameserver4'] = "Serveur DNS 4";
$_LANG['domainnameserver5'] = "Serveur DNS 5";
$_LANG['domainnameservers'] = "Serveurs DNS";
$_LANG['domainordernow'] = "Commander!";
$_LANG['domainorderrenew'] = "Commande de renouvellement";
$_LANG['domainprice'] = "Prix";
$_LANG['domainregisterns'] = "Enregistrer un serveur de noms (DNS)";
$_LANG['domainregisternscurrentip'] = "Adresse IP actuelle";
$_LANG['domainregisternsdel'] = "Supprimer un serveur de noms";
$_LANG['domainregisternsdelsuccess'] = "Le serveur de noms a été supprimé avec succès";
$_LANG['domainregisternsexplanation'] = "Ici vous pouvez créer et gérer des serveurs de noms personnalisés pour votre domaine (ex: ns1.example.com, ns2.example.com...).";
$_LANG['domainregisternsip'] = "Adresse IP";
$_LANG['domainregisternsmod'] = "Modifier l'adresse IP d'un serveur de noms";
$_LANG['domainregisternsmodsuccess'] = "Le serveur de noms a été modifié";
$_LANG['domainregisternsnewip'] = "Nouvelle adresse IP";
$_LANG['domainregisternsns'] = "Serveur de noms";
$_LANG['domainregisternsreg'] = "Enregistrer un serveur de noms";
$_LANG['domainregisternsregsuccess'] = "Le serveur de noms a été enregistré";
$_LANG['domainregistrantchoose'] = "Choisir le contact que vous voulez utiliser";
$_LANG['domainregistrantinfo'] = "Information sur le propriétaire du domaine";
$_LANG['domainregistrarlock'] = "Domaine protégé";
$_LANG['domainregistrarlockdesc'] = "Activer la protection du domaine (recommandé). Tout transfert non autorisé sera interdit si cette protection est active.";
$_LANG['domainregistration'] = "Enregistrement de domaine";
$_LANG['domainregistryinfo'] = "Info-domaine";
$_LANG['domainregnotavailable'] = "N/D";
$_LANG['domainrenew'] = "Renouveler le domaine";
$_LANG['domainrenewal'] = "Renouvellement de domaine";
$_LANG['domainrenewalprice'] = "Renouvellement";
$_LANG['domainrenewdesc'] = "Protégez votre nom de domaine en y ajoutant des années.  Choisissez le nombre d'années à ajouter ci-dessous et cliquez sur renouveler.";
$_LANG['domainsautorenew'] = "Renouvellement automatique";
$_LANG['domainsautorenewdisable'] = "Désactiver le renouvellement automatique";
$_LANG['domainsautorenewdisabled'] = "Désactivé";
$_LANG['domainsautorenewdisabledwarning'] = "ATTENTION! Ce domaine n'est pas configuré pour être renouvelé automatiquement. Il expirera donc et deviendra inactif à sa date d'échéance s'il n'est pas renouvellé manuellement.";
$_LANG['domainsautorenewenable'] = "Activer le renouvellement automatique";
$_LANG['domainsautorenewenabled'] = "Actif";
$_LANG['domainsautorenewstatus'] = "Statut";
$_LANG['domainsimplesearch'] = "Recherche simple de noms de domaines";
$_LANG['domainspricing'] = "Tarif des noms de domaine";
$_LANG['domainsregister'] = "Enregistrement";
$_LANG['domainsrenew'] = "Renouvellement";
$_LANG['domainsrenewnow'] = "Renouveler maintenant";
$_LANG['domainstatus'] = "État";
$_LANG['domainstransfer'] = "Transfert";
$_LANG['domaintitle'] = "Nom de domaine";
$_LANG['domaintld'] = "Extension";
$_LANG['domaintransfer'] = "Transfert de domaine";
$_LANG['domainunavailable'] = "Non disponible";
$_LANG['domainunavailable1'] = "Désolé!";
$_LANG['domainunavailable2'] = "a déjà été enregistré!";
$_LANG['domainreserved'] = "Réservé";
$_LANG['domainreserved1'] = "Le nom de domaine";
$_LANG['domainreserved2'] = "est disponible, mais déjà réservé.";
$_LANG['domainviewwhois'] = "Afficher le rapport WHOIS";
$_LANG['downloaddescription'] = "Description";
$_LANG['downloadloginrequired'] = "Accès refusé - Vous devez être authentifié pour télécharger ce fichier";
$_LANG['downloadname'] = "Téléchargement";
$_LANG['downloadpurchaserequired'] = "Accès refusé - Vous devez acheter le produit associé avant de pouvoir télécharger celui-ci";
$_LANG['downloadscategories'] = "Catégories";
$_LANG['downloadsdescription'] = "Consulter notre section de téléchargements.";
$_LANG['downloadsfiles'] = "Fichiers";
$_LANG['downloadsfilesize'] = "Taille du fichier";
$_LANG['downloadsintrotext'] = "La section téléchargements contient des informations, manuels, scripts pouvant vous être utiles dans l'élaboration de votre site Web.";
$_LANG['downloadspopular'] = "Téléchargements les plus populaires";
$_LANG['downloadsnone'] = "Aucun téléchargement disponible";
$_LANG['downloadstitle'] = "Téléchargements";
$_LANG['email'] = "Adresse courriel";
$_LANG['emptycart'] = "Vider le panier";
$_LANG['existingpassword'] = "Mot de passe actuel";
$_LANG['existingpasswordincorrect'] = "Votre mot de passe actuel est invalide";
$_LANG['firstpaymentamount'] = "Montant du premier paiement";
$_LANG['flashtutorials'] = "Tutoriels Flash";
$_LANG['flashtutorialsdescription'] = "Cliquez ici pour voir les tutoriels vous expliquant comment utiliser le panneau de contrôle.";
$_LANG['flashtutorialsheadertext'] = "Nos tutoriels Flash vous aideront à bien utiliser votre panneau de contrôle. Sélectionnez une tâche ci-dessous pour voir les étapes pas-à-pas sur comment réaliser cette tâche.";
$_LANG['forwardingtogateway'] = "Veuillez patienter pendant que nous vous dirigeons vers le service de paiement ...";
$_LANG['globalsystemname'] = "Accueil";
$_LANG['globalyouarehere'] = "Vous êtes ici";
$_LANG['go'] = "Aller";
$_LANG['headertext'] = "Bienvenue dans votre espace client et centre de support";
$_LANG['hometitle'] = "Accueil";
$_LANG['imagecheck'] = "Pour une sécurité accrue, inscrivez le code apparaissant ci-dessous";
$_LANG['invoiceaddcreditamount'] = "Entrez le montant";
$_LANG['invoiceaddcreditapply'] = "Utiliser le crédit disponible";
$_LANG['invoiceaddcreditdesc1'] = "Votre solde";
$_LANG['invoiceaddcreditdesc2'] = "Il peut être utilisé pour payer votre facture via le formulaire ci-dessous.";
$_LANG['invoiceaddcreditoverbalance'] = "Vous ne pouvez pas utiliser plus de crédit que votre solde actuel";
$_LANG['invoiceaddcreditovercredit'] = "Vous ne pouvez pas utiliser plus de crédit que ce qui est disponible sur votre compte";
$_LANG['invoicenumber'] = "Facture #";
$_LANG['invoiceofflinepaid'] = "Le paiement hors ligne par carte de crédit est fait manuellement. Lorsque votre paiement aura été fait, vous recevrez un courriel.";
$_LANG['invoicerefnum'] = "Référence pour le paiement";
$_LANG['invoices'] = "Mes factures";
$_LANG['invoicesamount'] = "Montant";
$_LANG['invoicesattn'] = "ATTN";
$_LANG['invoicesbacktoclientarea'] = "&laquo; Retour à la section client";
$_LANG['invoicesbalance'] = "Solde";
$_LANG['invoicesbefore'] = "Avant";
$_LANG['invoicescancelled'] = "ANNULÉE";
$_LANG['invoicescollections'] = "Collections";
$_LANG['invoicescredit'] = "Crédit";
$_LANG['invoicesdatecreated'] = "Date de facturation";
$_LANG['invoicesdatedue'] = "Date d'échéance";
$_LANG['invoicesdescription'] = "Description";
$_LANG['invoicesdownload'] = "Télécharger";
$_LANG['invoiceserror'] = "Une erreur est survenue. Essayez à nouveau.";
$_LANG['invoicesinvoicedto'] = "Facturé à";
$_LANG['invoicesinvoicenotes'] = "Notes";
$_LANG['invoicesnoinvoices'] = "Aucune facture";
$_LANG['invoicesnotes'] = "Notes";
$_LANG['invoicesoutstandinginvoices'] = "Factures";
$_LANG['invoicespaid'] = "PAYÉE";
$_LANG['invoicespaynow'] = "Payer maintenant";
$_LANG['invoicespayto'] = "Payer à";
$_LANG['invoicesrefunded'] = "REMBOURSÉE";
$_LANG['invoicesstatus'] = "État";
$_LANG['invoicessubtotal'] = "Sous-total";
$_LANG['invoicestax'] = "Taxe due";
$_LANG['invoicestaxindicator'] = "Indique un article taxable.";
$_LANG['invoicestitle'] = "Facture #";
$_LANG['invoicestotal'] = "Total";
$_LANG['invoicestransactions'] = "Transactions";
$_LANG['invoicestransamount'] = "Montant";
$_LANG['invoicestransdate'] = "Date de la transaction";
$_LANG['invoicestransgateway'] = "Passerelle";
$_LANG['invoicestransid'] = "Transaction #";
$_LANG['invoicestransnonefound'] = "Aucune transaction trouvée";
$_LANG['invoicesunpaid'] = "NON PAYÉE";
$_LANG['invoicesdraft'] = "Brouillon";
$_LANG['invoicesview'] = "Afficher la facture";
$_LANG['jobtitle'] = "Titre";
$_LANG['kbsuggestions'] = "Suggestions pour la base de connaissance";
$_LANG['kbsuggestionsexplanation'] = "Les articles suivants ont été trouvés dans la base de connaissance et pourraient répondre à votre question. Veillez vérifier ces suggestions avant de nous faire parvenir votre question.";
$_LANG['knowledgebasearticles'] = "Articles";
$_LANG['knowledgebasecategories'] = "Catégories";
$_LANG['nokbcategories'] = "Aucune catégorie n'existe";
$_LANG['knowledgebasedescription'] = "Parcourir la section des questions posées fréquemment (FAQ).";
$_LANG['knowledgebasefavorites'] = "Ajouter aux favoris";
$_LANG['knowledgebasehelpful'] = "Cette réponse était-elle pertinente?";
$_LANG['knowledgebaseintrotext'] = "La base de connaissances est divisée en différentes catégories. Choisissez une catégorie ou recherchez une réponse à votre question dans cette base de connaissances.";
$_LANG['knowledgebasemore'] = "Plus";
$_LANG['knowledgebaseno'] = "Non";
$_LANG['knowledgebasenoarticles'] = "Aucun article trouvé";
$_LANG['knowledgebasenorelated'] = "Aucun article connexe";
$_LANG['knowledgebasepopular'] = "Les plus consultés";
$_LANG['knowledgebaseprint'] = "Imprimer cet article";
$_LANG['knowledgebaserating'] = "Évaluation :";
$_LANG['knowledgebaseratingtext'] = "Utilisateurs l'ont trouvée utile";
$_LANG['knowledgebaserelated'] = "Articles connexes";
$_LANG['knowledgebasesearch'] = "Rechercher";
$_LANG['knowledgebasetitle'] = "Base de connaissances";
$_LANG['knowledgebaseviews'] = "Vu";
$_LANG['knowledgebasevote'] = "Vote";
$_LANG['knowledgebasevotes'] = "Votes";
$_LANG['knowledgebaseyes'] = "Oui";
$_LANG['knowledgebaseArticleRatingThanks'] = "Merci d'avoir évalué cet article";
$_LANG['language'] = "Langue";
$_LANG['latefee'] = "Frais de retard";
$_LANG['latefeeadded'] = "Ajoutés";
$_LANG['latestannouncements'] = "Dernières annonces";
$_LANG['loginbutton'] = "Connexion";
$_LANG['loginemail'] = "Adresse courriel";
$_LANG['loginforgotten'] = "Mot de passe oublié?";
$_LANG['loginforgotteninstructions'] = "Pour réinitialiser votre mot de passe, cliquez ici.";
$_LANG['loginincorrect'] = "Adresse de courriel ou mot de passe incorrects. Veuillez essayer à nouveau.";
$_LANG['loginintrotext'] = "Connexion requise pour accéder à cette page. Les identifiants (nom d'utilisateur et mot de passe) de connexion sont différents de ceux utilisés pour accéder à la section administrative du panneau de configuration de votre site Web.";
$_LANG['loginpassword'] = "Mot de passe";
$_LANG['loginrememberme'] = "Rester connecté";
$_LANG['logoutcontinuetext'] = "Cliquez ici pour continuer.";
$_LANG['logoutsuccessful'] = "Vous vous êtes déconnecté avec succès.";
$_LANG['logouttitle'] = "Se déconnecter";
$_LANG['maxmind_anonproxy'] = "Proxy anonyme détecté ! Nous ne pouvons pas accepter votre commande. Veuillez désactiver votre proxy puis réessayer.";
$_LANG['maxmind_callingnow'] = "Nous plaçons maintenant un appel automatisé sur votre ligne téléphonique. Cela fait partie des mesures de sécurité pour contrer les fraudes. Un code de sécurité à 4 chiffres vous sera donné. Vous devrez l'inscrire ci-dessous pour compléter votre commande.";
$_LANG['maxmind_countrymismatch'] = "Votre adresse IP et votre pays ne correspondent pas. Nous ne pouvons accepter votre commande";
$_LANG['maxmind_error'] = "Erreur";
$_LANG['maxmind_faileddescription'] = "Le code que vous avez inscrit est incorrect. Si vous pensez qu'il s'agit d'une erreur, veuillez contacter notre service client dès que possible.";
$_LANG['maxmind_highfraudriskscore'] = "Votre commande a été identifiée comme potentiellement à haut risque et a été retenue pour un examen manuel.<br /><br />Si vous pensez que vous avez reçu ce message par erreur, veuillez accepter toutes nos excuses et <a href=\"submitticket.php\">ouvrez un billet</a> auprès de notre département du service à la clientèle. Nous vous remercions.";
$_LANG['maxmind_highriskcountry'] = "Nous n'acceptons pas les commandes en provenance de votre pays. Au besoin, contactez-nous afin d'effectuer l'achat avec l'un de nos agents.";
$_LANG['maxmind_incorrectcode'] = "Code incorrect";
$_LANG['maxmind_pincode'] = "Code NIP";
$_LANG['maxmind_rejectemail'] = "Nous n'acceptons pas les commandes utilisant une adresse courriel gratuite. Veuillez inscrire une autre adresse courriel.";
$_LANG['maxmind_title'] = "MaxMind";
$_LANG['more'] = "Plus";
$_LANG['morechoices'] = "Plus de choix";
$_LANG['networkissuesaffecting'] = "Concerne";
$_LANG['networkissuesaffectingyourservers'] = "Veillez noter que les problèmes affectant un serveur sur lequel vous avez un compte sont surlignés.";
$_LANG['networkissuesdate'] = "Date";
$_LANG['networkissuesdescription'] = "Découvrez plus d'informations sur les éventuels problèmes de réseau actuels ou programmés";
$_LANG['networkissueslastupdated'] = "Dernière mise à jour";
$_LANG['networkissuesnonefound'] = "Aucun problème réseau trouvé";
$_LANG['networkissuespriority'] = "Priorité";
$_LANG['networkissuesprioritycritical'] = "Critique";
$_LANG['networkissuespriorityhigh'] = "Haute";
$_LANG['networkissuesprioritylow'] = "Basse";
$_LANG['networkissuesprioritymedium'] = "Moyenne";
$_LANG['networkissuesstatusinprogress'] = "Résolution en cours";
$_LANG['networkissuesstatusinvestigating'] = "Examen en cours";
$_LANG['networkissuesstatusopen'] = "Ouvert";
$_LANG['networkissuesstatusoutage'] = "Coupure";
$_LANG['networkissuesstatusreported'] = "Reporté";
$_LANG['networkissuesstatusresolved'] = "Résolu";
$_LANG['networkissuesstatusscheduled'] = "Programmé";
$_LANG['networkissuestitle'] = "Problèmes réseau";
$_LANG['networkissuestypeother'] = "Autre";
$_LANG['networkissuestypeserver'] = "Serveur";
$_LANG['networkissuestypesystem'] = "Système";
$_LANG['networkIssuesAware'] = "Nous sommes informés d'un problème pouvant avoir un impact sur le service.";
$_LANG['networkIssuesScheduled'] = "Il y a des événements de maintenance planifiés pouvant avoir un impact sur nos services.";
$_LANG['newpassword'] = "Votre nouveau mot de passe";
$_LANG['nextpage'] = "Page suivante";
$_LANG['no'] = "Non";
$_LANG['nocarddetails'] = "Aucun détail de carte enregistré";
$_LANG['none'] = "Aucun";
$_LANG['norecordsfound'] = "Aucun enregistrement trouvé";
$_LANG['or'] = "ou";
$_LANG['orderadditionalrequiredinfo'] = "Information additionnelle";
$_LANG['orderaddon'] = "Ajout";
$_LANG['orderaddondescription'] = "Les ajouts suivants sont disponibles pour ce service/produit. Choisissez ci-dessous les ajouts que vous désirez.";
$_LANG['orderavailable'] = "Disponible";
$_LANG['orderavailableaddons'] = "Cliquez pour afficher les ajouts disponibles.";
$_LANG['orderbillingcycle'] = "Cycle de facturation";
$_LANG['ordercategories'] = "Catégories";
$_LANG['orderchangeaddons'] = "Modifier ajouts";
$_LANG['orderchangeconfig'] = "Modifier les options configurables";
$_LANG['orderchangedomain'] = "Modifier un nom de domaine";
$_LANG['orderchangenameservers'] = "Modifier les serveurs DNS seulement";
$_LANG['orderchangeproduct'] = "Modifier un produit";
$_LANG['ordercheckout'] = "Terminer";
$_LANG['orderchooseaddons'] = "Sélectionner l'ajout";
$_LANG['orderchooseapackage'] = "Choisir un plan";
$_LANG['ordercodenotfound'] = "Le code promotionnel entré n'est pas valide";
$_LANG['ordercompletebutnotpaid'] = "Attention! Votre commande a été complétée mais non payée. Votre compte ne sera pas activé. <br />Cliquez sur le lien ci-dessous pour effectuer votre paiement.";
$_LANG['orderconfigpackage'] = "Options configurables";
$_LANG['orderconfigure'] = "Configurer";
$_LANG['orderconfirmation'] = "Confirmation de commande";
$_LANG['orderconfirmorder'] = "Confirmer la commande";
$_LANG['ordercontinuebutton'] = "Cliquez pour continuer >>";
$_LANG['orderdesc'] = "Description";
$_LANG['orderdescription'] = "Passer une nouvelle commande";
$_LANG['orderdiscount'] = "Réduction";
$_LANG['orderdomain'] = "Domaine";
$_LANG['orderdomainoption1part1'] = "Je veux que";
$_LANG['orderdomainoption1part2'] = "enregistre un nouveau nom de domaine pour moi.";
$_LANG['orderdomainoption2'] = "Je mettrai à jour mes serveurs DNS OU j'enregistrerai un nouveau nom de domaine.";
$_LANG['orderdomainoption3'] = "Je veux transférer mon nom de domaine à";
$_LANG['orderdomainoption4'] = "Je veux utiliser gratuitement un sous-domaine.";
$_LANG['orderdomainoptions'] = "Option du domaine";
$_LANG['orderdomainregistration'] = "Enregistrement d'un nom de domaine";
$_LANG['orderdomainregonly'] = "Commande d'un nom de domaine seulement";
$_LANG['orderdomaintransfer'] = "Transférer un nom de domaine";
$_LANG['orderdontusepromo'] = "Ne pas utiliser le code promotionnel";
$_LANG['ordererroraccepttos'] = "Vous devez accepter les conditions d'utilisation";
$_LANG['ordererrordomainalreadyexists'] = "Le nom de domaine que vous avez entré est déjà enregistré chez nous. Vous devez l'annuler avant de poursuivre votre commande";
$_LANG['ordererrordomaininvalid'] = "Le nom de domaine inscrit n'est pas valide.";
$_LANG['ordererrordomainnotld'] = "Vous devez inscrire l'extension du nom de domaine.";
$_LANG['ordererrordomainnotregistered'] = "Vous ne pouvez pas transférer un nom de domaine non enregistré.";
$_LANG['ordererrordomainregistered'] = "Le nom de domaine inscrit est déjà enregistré.";
$_LANG['ordererrornameserver1'] = "Vous devez inscrire le nom du serveur DNS 1.";
$_LANG['ordererrornameserver2'] = "Vous devez inscrire le nom du serveur DNS 2.";
$_LANG['ordererrornodomain'] = "Vous devez inscrire le nom du domaine";
$_LANG['ordererrorpassword'] = "Vous n'avez pas inscrit de mot de passe.";
$_LANG['ordererrorserverhostnameinuse'] = "Le nom d'hôte que vous avez entré est déjà utilisé. Veuillez en choisir un autre.";
$_LANG['ordererrorservernohostname'] = "Vous devez inscrire le nom d'hôte de votre serveur.";
$_LANG['ordererrorservernonameservers'] = "Vous devez inscrire le préfixe des deux nameservers.";
$_LANG['ordererrorservernorootpw'] = "Vous devez inscrire le mot de passe.";
$_LANG['ordererrorsubdomaintaken'] = "Le sous-domaine que vous avez inscrit est déja utilisé. Veuillez essayer un autre nom.";
$_LANG['ordererrortransfersecret'] = "Vous devez inscrire le code du transfert secret.";
$_LANG['ordererroruserexists'] = "Un utilisateur avec cette adresse courriel existe déjà.";
$_LANG['orderexistinguser'] = "Je suis client et je veux ajouter cette commande à mon compte.";
$_LANG['orderfailed'] = "La commande a échoué";
$_LANG['orderfinalinstructions'] = "Si vous avez des questions concernant votre commande, veuillez nous envoyer une demande d'aide à partir du centre de support et spécifiez votre numéro de commande.";
$_LANG['orderfree'] = "GRATUIT !";
$_LANG['orderfreedomainappliesto'] = "s'applique seulement aux extensions suivantes";
$_LANG['orderfreedomaindescription'] = "sur certains types de paiement";
$_LANG['orderfreedomainonly'] = "Domaine gratuit";
$_LANG['orderfreedomainregistration'] = "Enregistrement gratuit du nom de domaine";
$_LANG['ordergotoclientarea'] = "Cliquez ici pour accéder à la section client";
$_LANG['orderinvalidcodeforbillingcycle'] = "Ce code ne peut être appliqué à ce type de facturation";
$_LANG['orderlogininfo'] = "Information de connexion";
$_LANG['orderlogininfopart1'] = "Inscrivez le mot de passe que vous désirez utiliser pour vous connecter à l'";
$_LANG['orderlogininfopart2'] = "espace client. Ces informations sont différentes de celles pour vous connecter à la Section administrative de votre Site Web.";
$_LANG['ordernewuser'] = "Je suis un nouveau client et je veux créer un compte.";
$_LANG['ordernoproducts'] = "Aucun produit trouvé";
$_LANG['ordernotes'] = "Notes / Informations additionnelles";
$_LANG['ordernotesdescription'] = "Vous pouvez entrer ici des notes supplémentaires ou informations nécessaires au traitement de votre commande";
$_LANG['ordernowbutton'] = "Commander";
$_LANG['ordernumberis'] = "Numéro de commande :";
$_LANG['orderpaymentmethod'] = "Mode de paiement";
$_LANG['orderpaymentterm12month'] = "Tarif 12 mois";
$_LANG['orderpaymentterm1month'] = "Tarif 1 mois";
$_LANG['orderpaymentterm24month'] = "Tarif 24 mois";
$_LANG['orderpaymentterm3month'] = "Tarif 3 mois";
$_LANG['orderpaymentterm6month'] = "Tarif 6 mois";
$_LANG['orderpaymenttermannually'] = "Annuel";
$_LANG['orderpaymenttermbiennially'] = "Bi-annuel";
$_LANG['orderpaymenttermfreeaccount'] = "Compte gratuit";
$_LANG['orderpaymenttermmonthly'] = "Mensuel";
$_LANG['orderpaymenttermonetime'] = "Une fois";
$_LANG['orderpaymenttermquarterly'] = "Trimestriel";
$_LANG['orderpaymenttermsemiannually'] = "Semi-annuel";
$_LANG['orderprice'] = "Prix";
$_LANG['orderproduct'] = "Produit/Service";
$_LANG['orderprogress'] = "Étapes";
$_LANG['orderpromoexpired'] = "Code promotionnel expiré";
$_LANG['orderpromoinvalid'] = "La promotion ne s'applique pas à cet article";
$_LANG['orderpromomaxusesreached'] = "Le code promotionnel entré a déjà été utilisé";
$_LANG['orderpromotioncode'] = "Code promotionnel";
$_LANG['orderpromovalidatebutton'] = "Valider le Code >>";
$_LANG['orderPromoCodePlaceholder'] = "Entrez le code promotionnel";
$_LANG['orderprorata'] = "Prorata";
$_LANG['orderreceived'] = "Merci pour votre commande. Un courriel de confirmation vous parviendra bientôt.";
$_LANG['orderregisterdomain'] = "Enregistrer un nom de domaine";
$_LANG['orderregperiod'] = "Durée d'enregistrement";
$_LANG['ordersecure'] = "Ce formulaire est fourni dans un environnement sécurisé, afin de prévenir les fraudes. Votre adresse IP";
$_LANG['ordersecure2'] = "est enregistrée.";
$_LANG['orderserverhostname'] = "Nom d'hôte du serveur";
$_LANG['orderservernameservers'] = "Serveurs de noms";
$_LANG['orderservernameserversdescription'] = "Les préfixes inscrits ici détermineront les noms des serveurs par défaut. Exemple: ns1.votredomaine.com et ns2.votredomaine.com";
$_LANG['orderservernameserversprefix1'] = "Préfixe 1";
$_LANG['orderservernameserversprefix2'] = "Préfixe 2";
$_LANG['orderserverrootpassword'] = "Mot de passe";
$_LANG['ordersetupfee'] = "Frais de configuration";
$_LANG['orderstartover'] = "Recommencer";
$_LANG['ordersubdomaininuse'] = "Ce sous-domaine est déjà utilisé.";
$_LANG['ordersubtotal'] = "Sous-total";
$_LANG['ordersummary'] = "Résumé de la commande";
$_LANG['ordertaxcalculations'] = "Calcul des taxes";
$_LANG['ordertaxstaterequired'] = "Vous devez inscrire le nom de votre état ou province pour que le calcul des taxes s'effectue correctement";
$_LANG['ordertitle'] = "Passer une commande";
$_LANG['ordertos'] = "Conditions d'utilisation";
$_LANG['ordertosagreement'] = "J'ai lu et j'accepte les";
$_LANG['ordertotalduetoday'] = "Total à payer aujourd'hui";
$_LANG['ordertotalrecurring'] = "Prochains paiements";
$_LANG['ordertransferdomain'] = "Transférer un nom de domaine existant";
$_LANG['ordertransfersecret'] = "Code EPP";
$_LANG['ordertransfersecretexplanation'] = "Le code EPP du nom de domaine peut être obtenu du registraire actuel du nom de domaine.";
$_LANG['orderusesubdomain'] = "Utiliser un sous-domaine";
$_LANG['orderyears'] = "An(s)";
$_LANG['orderyourinformation'] = "Vos informations";
$_LANG['orderyourorder'] = "Votre commande";
$_LANG['organizationname'] = "Nom de l'organisation";
$_LANG['outofstock'] = "Rupture de stock";
$_LANG['outofstockdescription'] = "Cet article est actuellement en rupture de stock et a donc été suspendu jusqu'à ce que de nouveaux stocks soient disponibles. Pour plus d'informations, n’hésitez pas à communiquer avec notre service à la clientèle.";
$_LANG['page'] = "Page";
$_LANG['pageof'] = "de";
$_LANG['please'] = "SVP";
$_LANG['pleasewait'] = "Merci de patienter...";
$_LANG['presalescontactdescription'] = "Posez-nous vos questions avant de commander.";
$_LANG['previouspage'] = "Page précédente";
$_LANG['proformainvoicenumber'] = "Facture proforma #";
$_LANG['promoexistingclient'] = "Vous devez avoir un produit ou service actif pour pouvoir utiliser ce code promotionnel.";
$_LANG['promoonceperclient'] = "Ce code ne peut être utilisé qu'une seule fois par client.";
$_LANG['pwstrengthfail'] = "Le mot de passe que vous avez entré est trop simple. Veuillez entrer un mot de passe plus complexe.";
$_LANG['pwdoesnotmatch'] = "Les mots de passe ne correspondent pas";
$_LANG['quicknav'] = "Navigation rapide";
$_LANG['recordsfound'] = "Enregistrement(s) trouvé(s)";
$_LANG['recurring'] = "Récurent";
$_LANG['recurringamount'] = "Montant récurrent";
$_LANG['every'] = "Chaque";
$_LANG['registerdomain'] = "Enregistrer un nom de domaine";
$_LANG['registerdomaindesc'] = "Inscrivez le nom de domaine dont vous voulez vérifier la disponibilité.";
$_LANG['registerdomainname'] = "Enregistrer un nom de domaine";
$_LANG['relatedservice'] = "Service lié";
$_LANG['rssfeed'] = "Flux RSS";
$_LANG['securityanswerrequired'] = "Vous devez entrer une réponse à la question de sécurité";
$_LANG['securityquestionrequired'] = "You must select a security question";
$_LANG['securitybothnotmatch'] = "Votre réponse et sa confirmation ne correspondent pas";
$_LANG['securitycurrentincorrect'] = "Votre question et sa réponse sont incorrectes";
$_LANG['serverchangepassword'] = "Modifier le mot de passe";
$_LANG['serverchangepasswordintro'] = "D'ici vous pouvez modifier le mot de passe de vos produits & services (Note: Ceci n'affecte pas votre mot de passe de l'espace client, ni celui de vos autres produits)";
$_LANG['serverchangepasswordconfirm'] = "Réinscrivez le mot de passe";
$_LANG['serverchangepasswordenter'] = "Inscrivez le mot de passe";
$_LANG['serverchangepasswordfailed'] = "Échec de modification du mot de passe!";
$_LANG['serverchangepasswordsuccessful'] = "Mot de passe modifié avec succès!";
$_LANG['serverchangepasswordupdate'] = "Mise à jour";
$_LANG['serverhostname'] = "Nom de l'hôte";
$_LANG['serverlogindetails'] = "Informations de connexion";
$_LANG['serverns1prefix'] = "Préfixe NS1";
$_LANG['serverns2prefix'] = "Préfixe NS2";
$_LANG['serverpassword'] = "Mot de passe";
$_LANG['serverrootpw'] = "Mot de passe racine (root)";
$_LANG['serverstatusdescription'] = "Vérifier l'état des serveurs.";
$_LANG['serverstatusnoservers'] = "Aucun serveur en vérification";
$_LANG['serverstatusnotavailable'] = "Non disponible";
$_LANG['serverstatusoffline'] = "Hors ligne";
$_LANG['serverstatusonline'] = "En ligne";
$_LANG['serverstatusphpinfo'] = "Info PHP";
$_LANG['serverstatusserverload'] = "Charge du serveur";
$_LANG['serverstatustitle'] = "État des serveurs";
$_LANG['serverstatusuptime'] = "Uptime";
$_LANG['serverusername'] = "Nom d'utilisateur";
$_LANG['show'] = "Montrer";
$_LANG['ssladmininfo'] = "Informations du contact administratif";
$_LANG['ssladmininfodetails'] = "L'information pour le contact ci-dessous n'apparaîtra pas sur le certificat - elle ne sera utilisée que pour vous contacter relativement à cette commande.  Le Certificat SSL et tous les avis de renouvellements seront expédiés à l'adresse spécifiée ci-dessous.";
$_LANG['sslcertinfo'] = "Information du Certificat SSL";
$_LANG['pleasechooseone'] = "Veuillez en choisir un SVP";
$_LANG['sslcerttype'] = "Type de certificat";
$_LANG['sslconfigcomplete'] = "Configuration terminée";
$_LANG['sslconfsslcertificate'] = "Configuration du Certificat SSL.";
$_LANG['sslcsr'] = "CSR";
$_LANG['sslerrorapproveremail'] = "Vous devez entrer l'adresse courriel du responsable de ce certificat";
$_LANG['sslerrorentercsr'] = "Vous devez entrer votre requête de signature de certificat (CSR)";
$_LANG['sslerrorselectserver'] = "Vous devez choisir votre type de serveur";
$_LANG['sslinvalidlink'] = "Lien invalide. Veuillez essayer de nouveau.";
$_LANG['sslorderdate'] = "Date de commande";
$_LANG['sslserverinfo'] = "Information du serveur";
$_LANG['sslserverinfodetails'] = "Vous devez avoir une requête de signature de certificat (CSR) valide afin de pouvoir configurer votre certificat SSL. Le CSR est un texte crypté généré par le serveur web où le certificat sera installé. Si vous n'avez pas votre CSR, vous devez le générer ou demander à votre hébergeur de le générer pour vous. Assurez-vous également de l'exactitude des informations entrées, car elles ne peuvent être changés après le déploiement du certificat.";
$_LANG['sslservertype'] = "Type de serveur web";
$_LANG['ssl']['selectWebserver'] = "Select a :serverType";
$_LANG['sslstatus'] = "Statut de la configuration";
$_LANG['sslawaitingconfig'] = "En attente de configuration";
$_LANG['sslconfigure'] = "Configurer";
$_LANG['ssldomain'] = "Domaine";
$_LANG['sslproduct'] = "Produit SSL";
$_LANG['sslrenewaldate'] = "Date de renouvellement";
$_LANG['sslresendmail'] = "Renvoyer l'e-mail";
$_LANG['statscreditbalance'] = "Balance de crédit du compte";
$_LANG['statsdueinvoicesbalance'] = "Solde des factures dues";
$_LANG['statsnumdomains'] = "Nombre de domaines";
$_LANG['statsnumproducts'] = "Nombre de produits/services";
$_LANG['statsnumreferredsignups'] = "Nombre d'abonnements référés";
$_LANG['statsnumtickets'] = "Nombre de demandes de support";
$_LANG['submitticketdescription'] = "Soumettre une demande d'aide.";
$_LANG['supportclickheretocontact'] = "cliquez ici pour nous contacter";
$_LANG['supportpresalesquestions'] = "Si vous avez des questions avant de commander";
$_LANG['supportticketinvalid'] = "Une erreur est survenue. Cette demande de support n'a pu être trouvée.";
$_LANG['supportticketsallowedextensions'] = "Extensions permises";
$_LANG['supportticketschoosedepartment'] = "Sélectionnez le département";
$_LANG['supportticketsclient'] = "Client";
$_LANG['supportticketsclientemail'] = "Courriel";
$_LANG['supportticketsclientname'] = "Nom";
$_LANG['supportticketsdate'] = "Date";
$_LANG['supportticketsdepartment'] = "Département";
$_LANG['supportticketsdescription'] = "Voir et répondre aux demandes existantes";
$_LANG['supportticketserror'] = "Erreur";
$_LANG['supportticketserrornoemail'] = "Vous n'avez pas inscrit votre adresse courriel";
$_LANG['supportticketserrornomessage'] = "Vous n'avez pas inscrit de message";
$_LANG['supportticketserrornoname'] = "Vous n'avez pas inscrit votre nom";
$_LANG['supportticketserrornosubject'] = "Vous n'avez pas inscrit l'objet de votre demande";
$_LANG['supportticketsfilenotallowed'] = "Ce type de fichier est interdit.";
$_LANG['supportticketsheader'] = "Si la réponse ne peut être trouvée dans la base de connaissances, n'hésitez pas à nous envoyer un message à l'aide du formulaire ci-dessous.";
$_LANG['supportticketsnotfound'] = "Demande introuvable";
$_LANG['supportticketsopentickets'] = "Demandes de support en attente";
$_LANG['supportticketspagetitle'] = "Demande de support";
$_LANG['supportticketsposted'] = "Envoyé";
$_LANG['supportticketsreply'] = "Répondre";
$_LANG['supportticketsstaff'] = "Équipe";
$_LANG['supportticketsstatus'] = "État";
$_LANG['supportticketsstatusanswered'] = "Répondu";
$_LANG['supportticketsstatusclosed'] = "Fermé";
$_LANG['supportticketsstatuscloseticket'] = "Fermer la demande";
$_LANG['supportticketsstatuscustomerreply'] = "Réponse du client";
$_LANG['supportticketsstatusinprogress'] = "En cours";
$_LANG['supportticketsstatusonhold'] = "En attente";
$_LANG['supportticketsstatusopen'] = "Ouvert";
$_LANG['supportticketssubject'] = "Objet";
$_LANG['supportticketssubmitticket'] = "Ouvrir une demande";
$_LANG['supportticketssystemdescription'] = "Notre système de demande de support nous permet de répondre à vos demandes d'aide le plus rapidement possible. Lorsqu'une réponse est disponible, un courriel vous en avisera immédiatement.";
$_LANG['supportticketsticketattachments'] = "Pièce(s) jointe(s)";
$_LANG['supportticketsticketcreated'] = "Demande créée";
$_LANG['supportticketsticketcreateddesc'] = "Votre demande de support a été créée avec succès. Un courriel avec les détails de votre demande vous a été expédié. Si vous désirez consulter votre demande, vous pouvez le faire dès à présent.";
$_LANG['supportticketsticketid'] = "Numéro de la demande";
$_LANG['supportticketsticketsubject'] = "Objet";
$_LANG['supportticketsticketsubmit'] = "Envoyer";
$_LANG['supportticketsticketurgency'] = "Urgence";
$_LANG['supportticketsticketurgencyhigh'] = "Haute";
$_LANG['supportticketsticketurgencylow'] = "Faible";
$_LANG['supportticketsticketurgencymedium'] = "Moyenne";
$_LANG['supportticketsuploadfailed'] = "Impossible de téléverser le fichier joint";
$_LANG['supportticketsuploadtoolarge'] = "Le fichier joint est trop volumineux. Veuillez essayer avec un fichier plus léger.";
$_LANG['supportticketsviewticket'] = "Afficher la demande";
$_LANG['supportticketclosedmsg'] = "Cette demande est fermée. Vous pouvez y répondre pour l'ouvrir de nouveau.";
$_LANG['telesignincorrectpin'] = "NIP incorrect!";
$_LANG['telesigninitiatephone'] = "Nous ne pouvons faire la validation téléphonique de votre numéro. Veuillez contacter notre service à la clientèle.";
$_LANG['telesigninvalidnumber'] = "Numéro de téléphone invalide";
$_LANG['telesigninvalidpin'] = "Le NIP entré est invalide!";
$_LANG['telesigninvalidpin2'] = "Le NIP entré n'est pas valide.";
$_LANG['telesigninvalidpinmessage'] = "La vérification du NIP a échouée!";
$_LANG['telesignmessage'] = "La vérification téléphonique pour le numéro %s a débuté. Veuillez S.V.P. patienter...";
$_LANG['telesignphonecall'] = "Appel téléphonique";
$_LANG['telesignpin'] = "Entrez votre NIP : ";
$_LANG['telesignsms'] = "SMS";
$_LANG['telesignsmstextmessage'] = "Merci d'utiliser notre service de vérification SMS.  Votre code est: %s S.V.P. veuillez entrez ce code sur votre ordinateur maintenant.";
$_LANG['telesigntitle'] = "Vérification téléphonique TeleSign.";
$_LANG['telesigntype'] = "Choisissez le type de vérification pour le numéro %s:";
$_LANG['telesignverificationcanceled'] = "Il y a un problème temporaire avec le service de vérification téléphonique, la vérification a été annulée.";
$_LANG['telesignverificationproblem'] = "Il y a un problème avec le service de vérification téléphonique et votre commande n'a pu être validé, S.V.P. veuillez essayez plus tard.";
$_LANG['telesignverify'] = "Votre numéro de téléphone %s doit être vérifié afin de compléter votre commande.";
$_LANG['ticketratingexcellent'] = "Excellent";
$_LANG['ticketratingpoor'] = "Mauvais";
$_LANG['ticketratingquestion'] = "Comment qualifieriez-vous cette réponse ?";
$_LANG['ticketreatinggiven'] = "Vous avez déjà donné votre avis sur cette réponse";
$_LANG['transferdomain'] = "Transférer un nom de domaine";
$_LANG['transferdomaindesc'] = "Souhaitez-vous nous transférer votre nom de domaine? Si oui, inscrivez ci-dessous votre nom de domaine pour débuter le processus.";
$_LANG['transferdomainname'] = "Transférer un nom de domaine";
$_LANG['updatecart'] = "Mise à jour du panier";
$_LANG['upgradechooseconfigoptions'] = "Augmenter/Diminuer les options configurables de ce produit.";
$_LANG['upgradechoosepackage'] = "Choisissez le nouveau plan ou le produit que vous voulez dans les options ci-dessous.";
$_LANG['upgradecurrentconfig'] = "Configuration actuelle";
$_LANG['upgradedowngradeconfigoptions'] = "Augmenter/Diminuer vos options";
$_LANG['upgradenewconfig'] = "Nouvelle configuration";
$_LANG['upgradenochange'] = "Aucune modification";
$_LANG['upgradeproductlogic'] = "Le coût de la mise à niveau est calculé à partir d'un crédit sur la portion inutilisée du plan courant et le coût du nouveau plan pour la même période.";
$_LANG['upgradesummary'] = "Ci-dessous se trouve le résumé de votre commande de mise à jour.";
$_LANG['usedefaultcontact'] = "Utiliser le contact par défaut (Détails ci-dessus)";
$_LANG['varilogixfraudcall_callnow'] = "Appeler maintenant!";
$_LANG['varilogixfraudcall_description'] = "En guise de mesure de prévention des fraudes, nous allons maintenant placer un appel téléphonique au numéro de téléphone que vous avez inscrit pour votre compte. Nous vous demandons d'inscrire le code donné ci-dessus. Veuillez noter ce code et lorsque vous êtes prêt pour recevoir l'appel, cliquez sur le bouton ci-dessous.";
$_LANG['varilogixfraudcall_error'] = "Une erreur est survenue. L'appel pour vérifier votre commande n'a pu être placé. Contactez notre service à la clientèle afin de compléter votre commande.";
$_LANG['varilogixfraudcall_fail'] = "L'appel pour vérifier votre commande a échoué. Votre numéro de téléphone a peut-être été composé incorrectement ou est sur la liste noire. Contactez notre service à la clientèle dès que possible pour compléter votre commande.";
$_LANG['varilogixfraudcall_failed'] = "Échec";
$_LANG['varilogixfraudcall_pincode'] = "Code PIN";
$_LANG['varilogixfraudcall_title'] = "Appel antifraude VariLogix";
$_LANG['viewcart'] = "Afficher le panier";
$_LANG['welcomeback'] = "Bienvenue à nouveau";
$_LANG['whoisresults'] = "Résultats WHOIS pour";
$_LANG['yes'] = "Oui";
$_LANG['yourdetails'] = "Vos informations";
$_LANG['user'] = "Utilisateur";
$_LANG['loggedInAs'] = "Connecté en tant que";
$_LANG['viewAllPricing'] = "Voir tous les tarifs";
$_LANG['default'] = "Défaut";
$_LANG['maxFileSize'] = "Taille de fichier max: :fileSize";

# Version 4.1

$_LANG['clientareafiles'] = "Fichiers joints";
$_LANG['clientareafilesdate'] = "Date d'ajout";
$_LANG['clientareafilesfilename'] = "Nom du fichier";

$_LANG['pwreset'] = "Réinitialiser le mot de passe";
$_LANG['pwresetdesc'] = "Vous pouvez réinitialiser votre mot de passe si vous l'avez oublié. Une fois votre adresse courriel saisie (et après avoir répondu à la question de sécurité si elle est activée), vous allez recevoir par courriel les instructions pour procéder à la réinitialisation de votre mot de passe.";
$_LANG['pwresetemailrequired'] = "Vous n'avez pas entré votre adresse courriel";
$_LANG['pwresetemailnotfound'] = "Aucun compte client ne correspond à l'adresse courriel saisie";
$_LANG['pwresetsecurityquestionrequired'] = "Vous avez une question de sécurité validée dans votre profil, vous devez donc entrer sa réponse ci-dessous.";
$_LANG['pwresetsecurityquestionincorrect'] = "La réponse fournie à la question de sécurité ne correspond pas à celle de votre profil.";
$_LANG['pwresetsubmit'] = "Envoyer";
$_LANG['pwresetrequested'] = "Courriel de validation envoyé";
$_LANG['pwresetcheckemail'] = "La réinitialisation de votre mot de passe à débuté. Merci de consulter vos courriels afin de poursuivre la procédure.";
$_LANG['pwresetkeyinvalid'] = "Le lien de réinitialisation que vous avez suivi est invalide. Merci d'essayer à nouveau.";
$_LANG['pwresetkeyexpired'] = "Le lien de réinitialisation que vous avez suivi a expiré. Merci d'essayer à nouveau.";
$_LANG['pwresetvalidationsuccess'] = "Réinitialisation du mot de passe effectuée";

$_LANG['overagescharges'] = "Facturation du dépassement";
$_LANG['overagestotaldiskusage'] = "Utilisation totale de l'espace disque";
$_LANG['overagestotalbwusage'] = "Utilisation totale de la bande passante";

$_LANG['affiliatescommissionspending'] = "Commissions en attente";
$_LANG['affiliatescommissionsavailable'] = "Commissions disponibles";

$_LANG['configoptionqtyminmax'] = "%s requiert un minimum de %s et un maximum de %s";

$_LANG['creditcardnostore'] = "Cochez cette case si vous souhaitez que nous NE stockions PAS les informations de votre carte de crédit pour les paiements récurrents";
$_LANG['creditcarddelete'] = "Supprimer la carte de crédit enregistrée";
$_LANG['creditcarddeleteconfirmation'] = "La carte de crédit a été retirée de votre compte";
$_LANG['creditcardupdatenotpossible'] = "Les informations de la carte de crédit ne peuvent pas être mis à jour pour le moment. Merci d'essayer ultérieurement.";

$_LANG['invoicepaymentsuccessconfirmation'] = "Merci ! Le paiement a été effectué avec succès.";
$_LANG['invoicepaymentfailedconfirmation'] = "Malheureusement votre tentative de paiement a échouée.<br />Merci d'essayer à nouveau ou contactez le service à la clientèle.";

# Version 4.2

$_LANG['promoappliedbutnodiscount'] = "Le code promotionnel que vous avez saisi a été appliqué à votre panier, mais ne s'applique pour l'instant à aucun élément - merci de vérifier les conditions de la promotion";

$_LANG['upgradeerroroverdueinvoice'] = "Vous ne pouvez pas mettre à jour votre produit pour l'instant, car une facture a déjà été générée pour la prochaine échéance.<br /><br />Afin de poursuivre, veuillez d'abord régler la facture en attente. Il vous sera ensuite possible de mettre à jour immédiatement votre produit et vous serez crédité ou facturé pour la différence.";
$_LANG['upgradeexistingupgradeinvoice'] = "Vous ne pouvez actuellement pas mettre à niveau/rétrograder ce produit, car une mise à niveau/rétrogradation est déjà en cours.<br /><br />Pour continuer, veuillez d'abord régler la facture impayée, vous serez alors en mesure d'effectuer la mise à niveau/rétrogradation et vous serez chargé de la différence ou crédité de la différence.<br/><br/>Si vous pensez que vous recevez ce message par erreur, veuillez ouvrir un ticket de support.";

$_LANG['subaccountactivate'] = "Activer un sous-compte";
$_LANG['subaccountactivatedesc'] = "Cocher pour autoriser et configurer l'accès à l'espace client";
$_LANG['subaccountpermissions'] = "Permissions du sous-compte";
$_LANG['subaccountpermsprofile'] = "Modification du profil du Compte Principal";
$_LANG['subaccountpermscontacts'] = "Voir et gérer les contacts";
$_LANG['subaccountpermsproducts'] = "Voir les produits et services";
$_LANG['subaccountpermsmanageproducts'] = "Voir et modifier les mots de passe des produits";
$_LANG['subaccountpermsdomains'] = "Voir les domaines";
$_LANG['subaccountpermsmanagedomains'] = "Gérer les paramètres des domaines";
$_LANG['subaccountpermsinvoices'] = "Voir et payer les factures";
$_LANG['subaccountpermstickets'] = "Voir et ouvrir des demandes de support";
$_LANG['subaccountpermsaffiliates'] = "Voir et gérer les comptes d'affiliés";
$_LANG['subaccountpermsemails'] = "Voir les courriels";
$_LANG['subaccountpermsorders'] = "Passer de nouvelles commandes/mises à jour/annulations";
$_LANG['subaccountpermissiondenied'] = "Vous n'avez pas les permissions nécessaires pour accéder à cette page";
$_LANG['subaccountallowedperms'] = "Vos permissions actuelles sont :";
$_LANG['subaccountcontactmaster'] = "Contactez le propriétaire du compte principal si vous pensez qu'il y a une erreur.";
$_LANG['subaccountSsoDenied'] = "Vous n'avez pas la permission de vous connecter avec l'authentification unique.";

$_LANG['knowledgebasealsoread'] = "Consultez aussi";

$_LANG['orderpaymenttermtriennially'] = "Triannuel";
$_LANG['orderpaymentterm36month'] = "Prix pour 36 mois";

$_LANG['domainrenewals'] = "Renouveler un nom de domaine";
$_LANG['domaindaysuntilexpiry'] = "Jours jusqu'à expiration";
$_LANG['domainrenewalsnoneavailable'] = "Il n'y a pas de domaine éligible à un renouvellement";
$_LANG['domainrenewalspastgraceperiod'] = "Période de renouvellement terminée";
$_LANG['domainrenewalsingraceperiod'] = "Dernière chance pour le renouvellement !";
$_LANG['domainrenewalsdays'] = "Jours";
$_LANG['domainrenewalsdaysago'] = "jour(s) passé(s)";

$_LANG['invoicespartialpayments'] = "Paiements partiels";
$_LANG['invoicestotaldue'] = "Total à régler";

$_LANG['masspaytitle'] = "Paiement en masse";
$_LANG['masspaydescription'] = "Vous trouverez ci-dessous un récapitulatif des factures choisies ainsi que le montant total pour les régler. Pour procéder au paiement, choisissez la méthode ci-dessous et validez.";
$_LANG['masspayselected'] = "Payer les factures sélectionnée(s)";
$_LANG['masspayall'] = "Payer la totalité";
$_LANG['masspaymakepayment'] = "Effectuer le paiement";

# Version 4.3

$_LANG['searchenterdomain'] = "Saisissez le domaine à rechercher";
$_LANG['searchfilter'] = "Filtrer";

$_LANG['suspendreason'] = "Raison pour la suspension";
$_LANG['suspendreasonoverdue'] = "En retard sur le paiement";

$_LANG['vpsnetmanagement'] = "Gestion VPS";
$_LANG['vpsnetpowermanagement'] = "Gestion électrique";
$_LANG['poweron'] = "Allumer";
$_LANG['poweroffforced'] = "Éteindre (Forcé)";
$_LANG['powerreboot'] = "Redémarrage";
$_LANG['powershutdown'] = "Éteindre";
$_LANG['vpsnetcpugraphs'] = "Graphique CPU";
$_LANG['vpsnetnetworkgraphs'] = "Graphiques réseau";
$_LANG['vpsnethourly'] = "Horaire";
$_LANG['vpsnetdaily'] = "Journalier";
$_LANG['vpsnetweekly'] = "Hebdomadaire";
$_LANG['vpsnetmonthly'] = "Mensuel";
$_LANG['view'] = "Voir";
$_LANG['vpsnetbackups'] = "Options de sauvegarde";
$_LANG['vpsnetgenbackup'] = "Générer la sauvegarde";
$_LANG['vpsnetrestorebackup'] = "Restaurer la sauvegarde";
$_LANG['vpsnetrestorebackupwarning'] = "La restauration de la sauvegarde effacera vos paramètres actuels du VPS";
$_LANG['vpsnetnobackups'] = "Il n'y a pas de sauvegarde";
$_LANG['vpsnetrunning'] = "En fonction";
$_LANG['vpsnetnotrunning'] = "Éteint";
$_LANG['vpsnetpowercycling'] = "Redémarrage en cours";
$_LANG['vpsnetcloud'] = "Nuage (Cloud)";
$_LANG['vpsnettemplate'] = "Modèle";
$_LANG['vpsnetstatus'] = "État du système";
$_LANG['vpsnetbwusage'] = "Utilisation de la bande passante";

$_LANG['twitterlatesttweets'] = "Nos derniers Tweets";
$_LANG['twitterfollow'] = "Suivez-nous sur Twitter";
$_LANG['twitterfollowus'] = "Suivez-nous";
$_LANG['twitterfollowuswhy'] = "pour ne rater aucune annonce ou offre";

$_LANG['chatlivehelp'] = "Aide en direct";

$_LANG['domainrelease'] = "Libérer le domaine";
$_LANG['domainreleasedescription'] = "Saisissez un nouveau TAG ici pour transférer votre domaine chez un nouveau registrar";
$_LANG['domainreleasetag'] = "Tag du nouveau registrar";

# Ajax Order Form

$_LANG['orderformtitle'] = "Bon de commande";

$_LANG['signup'] = "S'enregistrer";
$_LANG['loading'] = "Chargement en cours...";

$_LANG['cartchooseproduct'] = "Choisissez un produit";
$_LANG['cartconfigurationoptions'] = "Options de configuration";

$_LANG['ordererrorsoccurred'] = "Les erreurs suivantes se sont produites et doivent être corrigées avant de poursuivre :";
$_LANG['ordererrortermsofservice'] = "Vous devez accepter nos conditions générales de vente";
$_LANG['ordertostickconfirm'] = "Merci de cocher la case pour accepter les";

$_LANG['cartnewcustomer'] = "Je suis un nouveau client";
$_LANG['cartexistingcustomer'] = "Je suis déjà client";

$_LANG['cartpromo'] = "Promotion";
$_LANG['cartenterpromo'] = "Entrez le code de la promotion";
$_LANG['cartremovepromo'] = "Retirer la promotion";

$_LANG['cartrecurringcharges'] = "Montant récurrent";

$_LANG['cartenterdomain'] = "Merci de saisir le nom de domaine que vous souhaitez utiliser ci-dessous.";

$_LANG['cartdomainavailableoptions'] = "Félicitations, ce domaine est disponible !";
$_LANG['cartdomainavailableregister'] = "Merci d'enregistrer ce domaine pour";
$_LANG['cartdomainavailablemanual'] = "Je vais enregistrer ce domaine moi-même séparément";

$_LANG['cartdomainunavailableoptions'] = "Désolé, ce domaine n'est plus disponible. Si vous en êtes le propriétaire, choisissez une option ci-dessous...";
$_LANG['cartdomainunavailabletransfer'] = "Merci de transférer mon domaine pour";
$_LANG['cartdomainunavailablemanual'] = "Ce domaine m'appartient déjà et je vais mettre les serveurs de noms (DNS) à jour";

$_LANG['cartdomaininvalid'] = "Le domaine que vous avez saisi n'est pas valide. Saisissez uniquement la partie après le www. puis sélectionnez l'extension dans la liste";

# Version 4.4

$_LANG['dlinvalidlink'] = "Vous avez suivi un lien non valide. Merci de contacter le service à la clientèle.";

$_LANG['domaindnsmanagementlaunch'] = "Lancer le gestionnaire DNS";
$_LANG['domainemailforwardinglaunch'] = "Lancer le gestionnaire de transfert des courriels";

# Version 4.5

$_LANG['domaindnspriority'] = "Priorité";
$_LANG['domaindnsmxonly'] = "Priorité pour les entrées MX seulement";

$_LANG['orderpromoprestart'] = "Cette promotion n'est pas encore active. Veuillez S.V.P. essayer plus tard.";

$_LANG['ticketmerge'] = "FUSIONNÉ";

$_LANG['quote'] = "Devis";
$_LANG['quotestitle'] = "Mes devis";
$_LANG['quoteview'] = "Voir";
$_LANG['quotedownload'] = "Télécharger";
$_LANG['quoteacceptbtn'] = "Accepter le devis";
$_LANG['quotedlpdfbtn'] = "Télécharger (PDF)";
$_LANG['quotediscountheading'] = "Rabais (%)";
$_LANG['noquotes'] = "Il n'y a pas de devis présents dans votre compte.<br />Pour demander un devis, veuillez S.V.P. contacter le service à la clientèle.";
$_LANG['quotenumber'] = "Devis #";
$_LANG['quotesubject'] = "Objet";
$_LANG['quotedatecreated'] = "Date de création";
$_LANG['quotevaliduntil'] = "Valide jusqu'au";
$_LANG['quotestage'] = "État";
$_LANG['quoterecipient'] = "Destinataire";
$_LANG['quoteqty'] = "Qté";
$_LANG['quotedesc'] = "Description";
$_LANG['quoteunitprice'] = "Prix unitaire";
$_LANG['quotediscount'] = "Rabais %";
$_LANG['quotelinetotal'] = "Total";
$_LANG['quotestagedraft'] = "Brouillon";
$_LANG['quotestagedelivered'] = "Active";
$_LANG['quotestageonhold'] = "En attente";
$_LANG['quotestageaccepted'] = "Accepté";
$_LANG['quotestagelost'] = "Perdu";
$_LANG['quotestagedead'] = "Inactive";
$_LANG['quoteref'] = "Re Devis #";
$_LANG['quotedeposit'] = "Dépôt";
$_LANG['quotefinalpayment'] = "Solde restant";

$_LANG['invoiceoneoffpayment'] = "Faire un seul paiement";
$_LANG['invoicesubscriptionpayment'] = "Créer un abonnement récurrent";

$_LANG['invoicepaymentpendingreview'] = "Merci! Votre paiement a été un succès et sera appliqué à votre facture dès que le processus d'examen de 2CheckOut sera terminé.<br /><br />Cela peut prendre jusqu'à quelques heures, votre patience est appréciée.";

$_LANG['step'] = "Étape %s";
$_LANG['cartdomainexists'] = "Ce nom de domaine existe déjà dans notre base de données et ne peut donc pas être commandé à nouveau.";
$_LANG['cartcongratsdomainavailable'] = "Félicitation, %s est disponible!";
$_LANG['cartregisterhowlong'] = "Pour combien de temps voulez-vous enregistrer ce service?";
$_LANG['cartdomaintaken'] = "Désolé, %s n'est pas disponible";
$_LANG['carttransfernotregistered'] = "%s ne semble pas être encore enregistré";
$_LANG['carttransferpossible'] = "Félicitation, nous pouvons transférer %s chez nous pour seulement %s";
$_LANG['cartotherdomainsuggestions'] = "D'autres domaines que vous seriez peut-être intéressé par...";
$_LANG['cartdomainsconfiginfo'] = "Les options et les paramètres suivants sont disponibles pour les domaines que vous avez choisis. Les champs requis sont indiqués d'un astérisque (*).";
$_LANG['cartnameserverchoice'] = "choix des serveurs de nom";
$_LANG['cartnameserverchoicedefault'] = "Utiliser les serveurs de noms par défaut pour notre hébergement";
$_LANG['cartnameserverchoicecustom'] = "Utiliser des serveurs de noms personnalisés";
$_LANG['cartfollowingaddonsavailable'] = "Les ajouts suivants sont disponibles pour vos produits et services actifs.";
$_LANG['cartregisterdomainchoice'] = "Enregistrer un nom de domaine";
$_LANG['carttransferdomainchoice'] = "Transfert de votre domaine depuis un autre registraire";
$_LANG['cartexistingdomainchoice'] = "Je vais utiliser mon nom de domaine existant et mettre à jour mes serveurs de noms";
$_LANG['cartsubdomainchoice'] = "Utiliser un sous-domaine de %s";
$_LANG['carterrordomainconfigskipped'] = "vous devez revenir en arrière et remplir les champs obligatoires de configuration du nom de domaine ci-dessus";
$_LANG['cartproductchooseoptions'] = "Choisissez les options";
$_LANG['cartproductselection'] = "Choix du produit";
$_LANG['cartreviewcheckout'] = "Vérifier & commander";
$_LANG['cartchoosecycle'] = "Choisissez un cycle de facturation";
$_LANG['cartavailableaddons'] = "Ajouts disponibles";
$_LANG['cartsetupfees'] = "Frais de configuration";
$_LANG['cartchooseanotherproduct'] = "Choisir un autre produit";
$_LANG['cartaddandcheckout'] = "Ajouter au panier & commander";
$_LANG['cartchooseanothercategory'] = "Choisir une autre catégorie";
$_LANG['carttryanotherdomain'] = "Essayez un autre nom de domaine";
$_LANG['cartmakedomainselection'] = "S'il vous plaît veuillez nous fournir le nom de domaine que vous souhaitez utiliser avec votre service d'hébergement en sélectionnant une option dans le choix ci-dessous.";
$_LANG['cartfraudcheck'] = "Vérification des fraudes";
$_LANG['cartapifailedtoloadcart'] = "The system could not load the requested cart. <strong><a href=\"cart.php\">Click here</a></strong> to start a new order.";

$_LANG['newcustomer'] = "Nouveau client";
$_LANG['existingcustomer'] = "Client existant";
$_LANG['newcustomersignup'] = "Pas encore inscrit ? %sInscrivez-vous ici%s";

$_LANG['upgradeonselectedoptions'] = "(Sur les options choisies)";
$_LANG['recurringpromodesc'] = "Ce code de promotion comprend aussi une remise récurrente de %s<br />(Ce rabais s'appliquera au prix total des futurs renouvellements du produit)";

# Version 4.5.2

$_LANG['ajaxcartcheckout'] = "Passer directement à la caisse";
$_LANG['ajaxcartconfigreqnotice'] = "Vous êtes sur le point de passer votre commande avec nous, mais vous devez choisir un nom de domaine avant de pouvoir ajouter ce produit à votre panier...";

# Version 5.0.0

$_LANG['cancelrequestdomain'] = "Annuler le renouvellement du domaine?";
$_LANG['cancelrequestdomaindesc'] = "Vous avez aussi un enregistrement de domaine actif pour le domaine associé à ce produit <br /> Ce domaine est à renouveler le %s à un coût de %s pour %s an(s) <br /> <br /> Si vous souhaitez annuler le domaine et le laisser expirer à la fin de l'enregistrement en cours, alors cochez la case ci-dessous.";
$_LANG['cancelrequestdomainconfirm'] = "Je confirme que je ne souhaite pas renouveler ce domaine à nouveau";

$_LANG['startingfrom'] = "À partir de";

$_LANG['orderpromopriceoverride'] = "Prix remplacé";
$_LANG['orderpromofreesetup'] = "Installation gratuite";

$_LANG['thereisaproblem'] = "Oops, il y a un problème...";
$_LANG['problemgoback'] = "Revenez & réessayer plus tard";

$_LANG['quantity'] = "Quantité";
$_LANG['cartqtyenterquantity'] = "Vous désirez plus d'une fois cet article? Entrez la quantité ici:";
$_LANG['cartqtyupdate'] = "Mettre à jour";
$_LANG['invoiceqtyeach'] = "/chaque";

$_LANG['nschoicedefault'] = "Utiliser les serveurs de nom par défaut";
$_LANG['nschoicecustom'] = "Utiliser des serveurs de noms personnalisés (inscrire ci-dessous)";

$_LANG['jumpto'] = "Aller à";
$_LANG['top'] = "Haut";

$_LANG['domaincontactusexisting'] = "Utilisez le contact du compte existant";
$_LANG['domaincontactusecustom'] = "Indiquez ci-dessous des informations personnalisées";
$_LANG['domaincontactchoose'] = "Choisir le contact";
$_LANG['domaincontactprimary'] = "Données du profil primaire";

$_LANG['invoicepdfgenerated'] = "PDF généré le";

$_LANG['domainrenewalsbeforerenewlimit'] = "Le renouvellement anticipé minimum est de %s jours";

$_LANG['promonewsignupsonly'] = "Ce code promotionnel est uniquement valide pour les nouveaux clients";

# Bulk Domain Management

$_LANG['domainbulkmanagement'] = "Gestion d'action en vrac";
$_LANG['domainbulkmanagementchangesaffect'] = "Les modifications apportées ci-dessous auront une incidence sur les domaines suivants:";
$_LANG['domainbulkmanagementchangeaffect'] = "Les modifications apportées ci-dessous auront une incidence sur les domaines suivants:";
$_LANG['domaincannotbemanaged'] = "Ne peut pas être géré automatiquement - merci de contactez le support concernant toute modification que vous souhaitez effectuer";
$_LANG['domainbulkmanagementnotpossible'] = "Malheureusement, ces réglages ne peuvent pas être modifiés à partir de notre espace client actuellement. Pour toute modification merci de contacter le support client.";

$_LANG['domainmanagens'] = "Gérer les serveurs de noms";

$_LANG['domainautorenewstatus'] = "Statut d'auto-renouvellement";
$_LANG['domainautorenewinfo'] = "Le renouvellement automatique vous aide à protéger votre domaine. Lorsqu'il est activé, vous recevrez automatiquement une facture de renouvellement quelques semaines avant que votre domaine expire, et le paiement du renouvellement sera automatique.";
$_LANG['domainautorenewrecommend'] = "Nous vous recommandons de conserver le renouvellement automatique activé pour éviter de perdre votre nom de domaine.";

$_LANG['domainreglockstatus'] = "Statut de verrouillage";
$_LANG['domainreglockinfo'] = "Le verrouillage du domaine sécurise votre domaine contre les transferts non autorisés.";
$_LANG['domainreglockrecommend'] = "Nous vous recommandons de le garder activé, sauf lorsque vous désirerez transférer votre domaine.";
$_LANG['domainreglockenable'] = "Activer le verrouillage";
$_LANG['domainreglockdisable'] = "Désactiver le verrouillage";

$_LANG['domaincontactinfoedit'] = "Modifier les informations du contact";

$_LANG['domainmassrenew'] = "renouveler les domaines";

# reCAPTCHA

$_LANG['captchatitle'] = "Vérification Anti-Spam";
$_LANG['captchaverify'] = "S'il vous plaît veuillez entrer les caractères que vous voyez dans l'image ci-dessous dans la zone de texte fournie. Ceci est nécessaire pour empêcher des soumissions automatisées.";
$_LANG['captchaverifyincorrect'] = "Les caractères que vous avez saisis ne correspondent pas à l'image affichée. S'il vous plaît, veuillez essayer de nouveau.";
$_LANG['googleRecaptchaIncorrect'] = "Veuillez compléter le captcha et essayer de nouveau.";
$_LANG['recaptcha-invalid-site-private-key'] = "Une erreur s'est produite, s'il vous plaît veuillez contactez le support technique (code d'erreur: CAP1)";
$_LANG['recaptcha-invalid-request-cookie'] = "Une erreur s'est produite, s'il vous plaît veuillez essayer de nouveau (code d'erreur: CAP2)";
$_LANG['recaptcha-incorrect-captcha-sol'] = "Les caractères saisis ne correspondent pas à la vérification des mots. Prière d'essayer à nouveau.";

# Product Bundles

$_LANG['bundledeal'] = "Ensembles de produits!";
$_LANG['bundlevaliddateserror'] = "Ensemble indisponible";
$_LANG['bundlevaliddateserrordesc'] = "Cet ensemble est soit inactif ou il est expiré. Si vous pensez qu'il y a erreur, veuillez s'il vous plaît contacter le support.";
$_LANG['bundlemaxusesreached'] = "Ensemble non disponible";
$_LANG['bundlemaxusesreacheddesc'] = "Cet ensemble d'offres a atteint le nombre maximum d'utilisations autorisées et n'est malheureusement plus disponible. Merci de nous contacter si vous êtes intéressé.";
$_LANG['bundlereqsnotmet'] = "Les exigences de l'ensemble ne sont pas satisfaites";
$_LANG['bundlewarningpromo'] = "L'ensemble sélectionné ne peut être utilisé en conjonction avec d'autres promotions ou offres";
$_LANG['bundlewarningproductcycle'] = "L'ensemble sélectionné requiert que vous choisissiez le cycle de facturation '%s' pour les produits %s afin d'être applicable";
$_LANG['bundlewarningproductconfopreq'] = "L'ensemble sélectionné requiert que vous sélectionniez '%s' pour '%s' afin d'être applicable";
$_LANG['bundlewarningproductconfopyesnoenable'] = "L'ensemble sélectionné requiert que vous activiez l'option '%s' afin d'être applicable";
$_LANG['bundlewarningproductconfopyesnodisable'] = "L'ensemble sélectionné requiert que vous désactiviez l'option '%s' afin d'être applicable";
$_LANG['bundlewarningproductconfopqtyreq'] = "L'ensemble sélectionné requiert que vous choisissiez une quantité de '%s' pour '%s' afin d'être applicable";
$_LANG['bundlewarningproductaddonreq'] = "L'ensemble sélectionné requiert que vous choisissiez l'ajout '%s' pour le produit %s afin d'être applicable";
$_LANG['bundlewarningdomainreq'] = "L'ensemble sélectionné requiert que vous enregistriez ou transfériez un nom de domaine avec le produit %s pour être applicable";
$_LANG['bundlewarningdomaintld'] = "L'ensemble sélectionné requiert que vous choisissiez un nom de domaine avec l'extension '%s' pour le nom de domaine %s afin d'être applicable";
$_LANG['bundlewarningdomainregperiod'] = "L'ensemble sélectionné requiert que vous choisissiez la période d'enregistrement '%s' du nom de domaine %s afin d'être applicable";
$_LANG['bundlewarningdomainaddon'] = "L'ensemble sélectionné requiert que vous choisissiez l'ajout '%s' pour le nom de domaine %s afin d'être applicable";

# New Client Area Template  Lines

$_LANG['navservices'] = "Mes services";
$_LANG['navservicesorder'] = "Commander un nouveau service";
$_LANG['navservicesplaceorder'] = "Passer une nouvelle commande";
$_LANG['navdomains'] = "Mes domaines";
$_LANG['navrenewdomains'] = "Renouveler un nom de domaine";
$_LANG['navregisterdomain'] = "Enregistrer un nom de domaine";
$_LANG['navtransferdomain'] = "Transférer un nom de domaine";
$_LANG['navdomainsearch'] = "Rechercher un nom de domaine";
$_LANG['navbilling'] = "Mes factures";
$_LANG['navinvoices'] = "Factures";
$_LANG['navsupport'] = "Support";
$_LANG['navtickets'] = "Mes demandes";
$_LANG['navopenticket'] = "Ouvrir une demande";
$_LANG['navmanagecc'] = "Gérer les cartes de crédit";
$_LANG['navemailssent'] = "Courriels reçus";

$_LANG['hello'] = "Bonjour";
$_LANG['helloname'] = "Bonjour, %s!";
$_LANG['account'] = "Espace client";
$_LANG['login'] = "Connexion";
$_LANG['register'] = "Inscription";
$_LANG['forgotpw'] = "Mot de passe oublié?";

$_LANG['clientareanavccdetails'] = "Détails de la carte de crédit";

$_LANG['manageyouraccount'] = "Gérer votre compte";
$_LANG['accountoverview'] = "Aperçu du compte";
$_LANG['paymentmethod'] = "Mode de paiement";
$_LANG['paymentmethoddefault'] = "Utiliser par défaut";
$_LANG['productmanagementactions'] = "Actions de gestion";
$_LANG['clientareanoaddons'] = "Aucun ajout pour ce compte";
$_LANG['downloadssearch'] = "Cherchez les téléchargements";
$_LANG['emailviewmessage'] = "Voir le Message";
$_LANG['resultsperpage'] = "Résultats par page";
$_LANG['accessdenied'] = "Accès refusé";
$_LANG['search'] = "Chercher";
$_LANG['cancel'] = "Annuler";
$_LANG['clientareabacklink'] = "&laquo; Retour";
$_LANG['backtoserviceslist'] = "&laquo; Retour à la liste des services";
$_LANG['backtodomainslist'] = "&laquo; Retour à la liste des domaines";
$_LANG['copy'] = "Copier";

$_LANG['clientareahomeorder'] = "Consultez le formulaire de commande pour parcourir nos produits et services. Les clients existants peuvent aussi acheter des options et des extras ici.";
$_LANG['clientareahomelogin'] = "Déjà enregistré chez nous? Si oui, cliquez sur le bouton ci-dessous pour vous connecter à votre espace client.";
$_LANG['clientareahomeorderbtn'] = "Aller au formulaire de commande";
$_LANG['clientareahomeloginbtn'] = "Connexion à l'espace client";

$_LANG['clientareaproductsintro'] = "Voici tous les services de ce compte.";
$_LANG['clientareaproductdetailsintro'] = "Voici un aperçu de tous les produits/services que vous avez avec nous.";
$_LANG['clientareadomainsintro'] = "Voici tous les domaines de ce compte.";
$_LANG['quotesintro'] = "Voici tous les devis que nous avons créés pour vous.";
$_LANG['emailstagline'] = "Voici une copie des récents courriels que nous vous avons envoyés.";
$_LANG['supportticketsintro'] = "Voici le suivi de toutes vos demandes de support.";
$_LANG['addfundsintro'] = "Déposez de l'argent";
$_LANG['registerintro'] = "Créez un compte chez nous.";
$_LANG['networkstatusintro'] = "Informations sur l'état du réseau";

$_LANG['creditcardyourinfo'] = "Votre mode de paiement";
$_LANG['ourlatestnews'] = "Nos dernières nouvelles";
$_LANG['ccexpiringsoon'] = "La carte de crédit expire bientôt";
$_LANG['ccexpiringsoondesc'] = "Votre carte de crédit expire bientôt. Merci de vous assurer de %s mettre à jour les détails de votre carte %s dès que possible";
$_LANG['availcreditbal'] = "Solde de crédit disponible";
$_LANG['availcreditbaldesc'] = "Vous avez un crédit de %s disponible sur votre compte qui sera automatiquement appliqué à toute nouvelle facture";
$_LANG['youhaveoverdueinvoices'] = "Vous avez %s facture(s) en retard";
$_LANG['overdueinvoicesdesc'] = "Pour éviter une interruption de service, merci de payer vos factures en suspens dès que possible. %s Payer maintenant &raquo;%s";
$_LANG['supportticketsnoneopen'] = "Il n'y a actuellement aucune demande de support ouvert";
$_LANG['invoicesnoneunpaid'] = "Il n'y a actuellement aucune facture impayée";

$_LANG['registerdisablednotice'] = "Pour vous inscrire merci de <strong><a href=\"cart.php\">commander</a></strong>";
$_LANG['registerCreateAccount'] = "Pour créer un compte, veuillez";
$_LANG['registerCreateAccountOrder'] = "placer une commande";

$_LANG['pwstrength'] = "Niveau du mot de passe";
$_LANG['pwstrengthenter'] = "Entrez un mot de passe";
$_LANG['pwstrengthweak'] = "Faible";
$_LANG['pwstrengthmoderate'] = "Moyen";
$_LANG['pwstrengthstrong'] = "Fort";
$_LANG['pwstrengthrating'] = "Force du nouveau mot de passe";

$_LANG['managing'] = "Gestion";
$_LANG['information'] = "Information";
$_LANG['withselected'] = "Avec la sélection";
$_LANG['managedomain'] = "Gérer le domaine";
$_LANG['changenameservers'] = "Changer les serveurs DNS";
$_LANG['clientareadomainmanagedns'] = "Gérer les DNS";
$_LANG['clientareadomainmanageemailfwds'] = "Gérer la redirection de courriels";
$_LANG['moduleactionsuccess'] = "Action effectuée avec succès!";
$_LANG['moduleactionfailed'] = "L'action a échouée";

$_LANG['domaininfoexp'] = "À droite vous trouverez les détails de votre nom de domaine. Vous pouvez gérer votre nom de domaine en utilisant les onglets ci-dessus.";
$_LANG['domainrenewexp'] = "Activer le renouvellement automatique nous permet de vous envoyer automatiquement une facture de renouvellement, avant que votre nom de domaine n'arrive à expiration.";
$_LANG['domainnsexp'] = "Vous pouvez modifier où pointe votre domaine. Notez que les changements peuvent mettre 24 heures à se propager.";
$_LANG['domainlockingexp'] = "Verrouillez votre domaine afin d'empêcher son transfert ailleurs sans votre autorisation.";
$_LANG['domaincurrentlyunlocked'] = "Domaine actuellement déverrouillé!";
$_LANG['domaincurrentlyunlockedexp'] = "Vous devriez verrouiller votre domaine à moins que vous ne souhaitiez le transférer.";
$_LANG['searchmultipletlds'] = "Rechercher plusieurs extensions";

$_LANG['networkstatustitle'] = "État du réseau";
$_LANG['networkstatusnone'] = "Il n'y a actuellement aucun problème de réseau";
$_LANG['serverstatusheadingtext'] = "Le tableau ci-dessous affiche l'état de nos serveurs. Vous pouvez consulter cette page pour vérifier l'état des services disponibles sur le serveur.";

$_LANG['clientareacancelreasonrequired'] = "Vous devez entrer une raison d'annulation";

$_LANG['addfundsdescription'] = "Vous pouvez ajouter des fonds de façon à ce que vos factures soient automatiquement payées lors de leur émission. Les dépôts sont non remboursables.";
$_LANG['addfundsnonrefundable'] = "* Aucun dépôt n'est remboursable.";

$_LANG['creditcardexpirydateinvalid'] = "La date d'expiration doit être rentrée au format MM/YY et ne doit pas être antérieure à la date courante";

$_LANG['domaincheckerchoosedomain'] = "Choisissez un nom de domaine...";
$_LANG['domaincheckerchecknewdomain'] = "Vérifier la disponibilité d'un autre nom de domaine";
$_LANG['domaincheckerdomainexample'] = " ex. example.com";
$_LANG['domaincheckerhostingonly'] = "Commander uniquement un hébergement";
$_LANG['domaincheckerenterdomain'] = "Démarrer votre expérience d'hébergement web chez nous en entrant le nom de domaine que vous souhaitez enregistrer, transférer ou simplement acheter un hébergement ci-dessous...";

$_LANG['kbquestionsearchere'] = "Vous avez une question? Commencez votre recherche ici.";
$_LANG['contactus'] = "Contactez-nous";

$_LANG['opennewticket'] = "Ouvrir une demande";
$_LANG['searchtickets'] = "Entrez le # de la demande de support ou le sujet";
$_LANG['supportticketspriority'] = "Priorité";
$_LANG['supportticketsubmitted'] = "Soumis";
$_LANG['supportticketscontact'] = "Contact";
$_LANG['supportticketsticketlastupdated'] = "Dernière mise à jour";

$_LANG['upgradedowngradepackage'] = "Augmenter/Diminuer votre plan d'hébergement";
$_LANG['upgradedowngradechooseproduct'] = "Choisir un produit";

$_LANG['jobtitlereqforcompany'] = "(Requis si vous avez entré un nom d'organisation)";

$_LANG['downloadproductrequired'] = "Le téléchargement de ce fichier requiert que vous ayez une commande active du produit/service suivant:";

$_LANG['affiliatesignuptitle'] = "Soyez payé pour nous référer des clients!";
$_LANG['affiliatesignupintro'] = "Activez votre compte dès maintenant et commencez à amasser de l'argent...";
$_LANG['affiliatesignupinfo1'] = "Nous payons des commissions pour chaque inscription via votre lien personnalisé.";
$_LANG['affiliatesignupinfo2'] = "Nous suivons les visiteurs référés à l'aide de cookies pour vous permettre d'obtenir votre commission même si le visiteur ne s'inscrit pas instantanément. Les cookies sont valides jusqu'à 90 jours après la visite initiale.";
$_LANG['affiliatesignupinfo3'] = "Si vous désirez en savoir plus, n'hésitez pas à nous contacter.";

# Version 5.1

$_LANG['copyright'] = "Copyright";
$_LANG['allrightsreserved'] = "Tous droits réservés";
$_LANG['supportticketsclose'] = "Fermer la demande";
$_LANG['affiliatesinitialthen'] = "initialement, puis";
$_LANG['invoicesoutstandingbalance'] = "Solde impayé";

$_LANG['cpanellogin'] = "Connexion à cPanel";
$_LANG['cpanelwhmlogin'] = "Connexion à WHM";
$_LANG['cpanelwebmaillogin'] = "Connexion au Webmail";
$_LANG['enkompasslogin'] = "Connexion à Enkompass";
$_LANG['plesklogin'] = "Connexion à Plesk Control Panel";
$_LANG['helmlogin'] = "Connexion à Helm Control Panel";
$_LANG['hypervmrestart'] = "Redémarrer le serveur VPS";
$_LANG['siteworxlogin'] = "Connexion au panneau de contrôle SiteWorx";
$_LANG['nodeworxlogin'] = "Connexion au panneau de contrôle NodeWorx";
$_LANG['veportallogin'] = "Connexion à vePortal";
$_LANG['virtualminlogin'] = "Connexion au panneau de contrôle";
$_LANG['websitepanellogin'] = "Connexion au panneau de contrôle";
$_LANG['whmsoniclogin'] = "Connexion au panneau de contrôle";
$_LANG['xpanelmaillogin'] = "Connexion au Webmail";
$_LANG['xpanellogin'] = "Connexion à XPanel";
$_LANG['heartinternetlogin'] = "Connexion au panneau de contrôle";
$_LANG['gamecplogin'] = "Connexion à GameCP";
$_LANG['fluidvmrestart'] = "Redémarrer le serveur VPS";
$_LANG['enomtrustedesc'] = "Le panneau de contrôle TrustE contient l'utilitaire de configuration pour votre politique de confidentialité.";
$_LANG['enomtrustelogin'] = "Connexion au panneau de contrôle TrustE";
$_LANG['directadminlogin'] = "Connexion à DirectAdmin";
$_LANG['centovacastlogin'] = "Connexion à Centova Cast";
$_LANG['castcontrollogin'] = "Connexion au panneau de contrôle";

$_LANG['sslconfigurenow'] = "Configurer maintenant";
$_LANG['sslprovisioningdate'] = "Date d'approvisionnement SSL";
$_LANG['globalsignvoucherscode'] = "Votre Code Promo OneClickSSL";
$_LANG['globalsignvouchersnotissued'] = "Pas encore émis";

$_LANG['domaintrffailreasonunavailable'] = "Raison de l'échec indisponible";

$_LANG['clientareaprojects'] = "Mes Projets";

$_LANG['clientgroupdiscount'] = "Remise client";
$_LANG['billableitemshours'] = "Heures";
$_LANG['billableitemshour'] = "Heure";
$_LANG['billableitemsquantity'] = "Qté";
$_LANG['billableitemseach'] = "Chaque";

$_LANG['invoicefilename'] = "Facture-";
$_LANG['quotefilename'] = "Devis-";

# Domain Addons

$_LANG['domainaddons'] = "Ajouts";
$_LANG['domainaddonsinfo'] = "Les ajouts suivants sont disponibles pour votre domaine...";
$_LANG['domainaddonsdnsmanagement'] = "Gestionnaire DNS";
$_LANG['domainaddonsidprotectioninfo'] = "Protégez vos renseignements personnels en activant la protection d'identité.";
$_LANG['domainaddonsdnsmanagementinfo'] = "L'hébergement DNS externe peut aider à accélérer votre site web et améliorer la disponibilité.";
$_LANG['domainaddonsemailforwardinginfo'] = "Ayez vos courriels transférés à une adresse de votre choix afin de pouvoir les gérer depuis un seul compte.";
$_LANG['domainaddonsbuynow'] = "Achetez maintenant pour";
$_LANG['domainaddonsperyear'] = "/ Année";
$_LANG['domainaddonscancelareyousure'] = "Êtes-vous certain de vouloir désactiver et annuler cette option de domaine?";
$_LANG['domainaddonsconfirm'] = "Confirmez l'annulation";
$_LANG['domainaddonscancelsuccess'] = "Ajout désactivé avec succès!";
$_LANG['domainaddonscancelfailed'] = "Échec lors de la désactivation de l'ajout. Veuillez SVP contacter le support technique.";

# Version 5.2

$_LANG['yourclientareahostingaddons'] = "Vous avez les ajouts suivants pour ce produit.";
$_LANG['loginrequired'] = "Connexion requise";
$_LANG['unsubscribe'] = "Se désabonner";
$_LANG['emailoptout'] = "Liste de diffusion";
$_LANG['emailoptoutdesc'] = "Cochez pour vous désabonner de notre liste de diffusion";
$_LANG['alreadyunsubscribed'] = "Vous êtes déjà désabonnés de notre liste de diffusion.";
$_LANG['newsletterresubscribe'] = "Si vous souhaitez vous réabonner vous pouvez le faire en visitant la section %sMes informations%s de votre espace client en tout temps.";
$_LANG['unsubscribehashinvalid'] = "Le désabonnement à échoué, veuillez contacter le service à la clientèle.";
$_LANG['unsubscribesuccess'] = "Désabonnement réussi";
$_LANG['newsletterremoved'] = "Merci, votre courriel a bien été supprimé de notre liste de diffusion.";
$_LANG['newslettersubscribed'] = "Vous avez été inscrit avec succès à notre liste de diffusion.";
$_LANG['emailMarketingAlreadyOptedIn'] = "Vous êtes déjà inscrit à notre liste de diffusion.";
$_LANG['emailMarketingAlreadyOptedOut'] = "Vous êtes déjà désinscrit de notre liste de diffusion.";
$_LANG['manageSubscription'] = "Gérer l'abonnement";

$_LANG['erroroccured'] = "Une erreur s'est produite";
$_LANG['pwresetsuccessdesc'] = "Votre mot de passe a été réinitialisé. %sCliquez ici%s pour continuer vers l'espace client...";
$_LANG['pwresetenternewpw'] = "Veuillez entrer votre nouveau mot de passe ci-dessous.";
$_LANG['ordererrorsbudomainbanned'] = "Le préfixe de sous-domaine que vous avez entré n'est pas accepté, veuillez SVP en essayer un autre.";

$_LANG['ticketfeedbacktitle'] = "Demande de commentaires sur votre demande de support";

$_LANG['nosupportdepartments'] = "Aucun département de support trouvé. Veuillez essayer de nouveau plus tard.";

$_LANG['feedbackclosed'] = "Il est impossible de fournir vos commentaires avant que la demande de support soit fermée";
$_LANG['feedbackprovided'] = "Vous avez déjà fourni vos commentaires sur cette demande de support.";
$_LANG['feedbackthankyou'] = "Nous vous remercions de prendre le temps de nous fournir vos commentaires.";
$_LANG['feedbackreceived'] = "Nous avons bien reçu vos commentaires";
$_LANG['feedbackdesc'] = "S'il vous plaît pouvons-nous vous demander de prendre quelques minutes de votre temps pour remplir le formulaire ci-dessous à propos de la qualité de votre expérience avec notre équipe de support.";
$_LANG['feedbackclickreview'] = "Cliquez ici pour nous fournir vos commentaires";
$_LANG['feedbackopenedat'] = "Ouvert le";
$_LANG['feedbacklastreplied'] = "Dernière réponse le";
$_LANG['feedbackstaffinvolved'] = "Membre(s) d'équipe impliqué(s)";
$_LANG['feedbacktotalduration'] = "Durée totale";
$_LANG['feedbackpleaserate1'] = "Veuillez noter sur une échelle de 1 à 10 comment ";
$_LANG['feedbackpleasecomment1'] = "Veuillez commenter comment";
$_LANG['feedbackhandled'] = "a traité cette demande de soutien";
$_LANG['feedbackworst'] = "Pire";
$_LANG['feedbackbest'] = "Meilleur";
$_LANG['feedbackimprove'] = "Comment pouvons nous rendre votre expérience encore meilleure dans le futur?";
$_LANG['pleaserate2'] = "a traité cette demande de soutien";
$_LANG['feedbacksupplyrating'] = "Veuillez fournir au moins une note pour :staffname (les commentaires sont facultatifs)";

$_LANG['returnclient'] = "Retour à l'espace client";

$_LANG['clientareanavsecurity'] = "Paramètres de sécurité";
$_LANG['twofactorauth'] = "Authentification à deux facteurs";
$_LANG['twofaenable'] = "Activer l'authentification à deux facteurs";
$_LANG['twofadisable'] = "Désactiver l'authentification à deux facteurs";
$_LANG['twofaenableclickhere'] = "Cliquez ici pour activer";
$_LANG['twofadisableclickhere'] = "Cliquez ici pour désactiver";
$_LANG['twofaenforced'] = "L'administrateur système a imposé l'authentification à deux facteurs avant de pouvoir continuer vers votre espace client. Cette page vous guidera à travers le processus de sa mise en place.";

$_LANG['twofasetupgetstarted'] = "Commencer";
$_LANG['twofaactivationintro'] = "L'authentification à deux facteurs ajoute une couche supplémentaire de protection lors des connexions. Une fois activée et configurée, chaque fois que vous vous connectez vous serez invité à saisir votre identifiant et mot de passe ainsi qu'un second facteur d'identification comme code de sécurité.";
$_LANG['twofaactivationmultichoice'] = "Afin de poursuivre veuillez sélectionner votre méthode d'authentification à deux facteurs ci-dessous.";
$_LANG['twofadisableintro'] = "Pour désactiver l'authentification à deux facteurs veuillez s'il vous plaît confirmer votre mot de passe dans le champ ci-dessous.";
$_LANG['twofaactivationerror'] = "Une erreur s'est produite lors de la tentative d'activation de l'authentification à deux facteurs pour votre compte. Veuillez s'il vous plaît essayer à nouveau.";
$_LANG['twofamoduleerror'] = "Une erreur s'est produite pendant le chargement du module. Veuillez s'il vous plaît essayer de nouveau.";
$_LANG['twofadisableconfirmation'] = "L'authentification à deux facteurs est maintenant désactivée pour votre compte.";
$_LANG['twofabackupcode'] = "Code de récupération";
$_LANG['twofabackupcodeintro'] = "Le code de récupération est nécessaire pour accéder à votre compte au cas où vous ne pourriez pas utiliser l'authentification à deux facteurs.";
$_LANG['twofabackupcodeis'] = "Votre code de récupération est";
$_LANG['twofanewbackupcodeis'] = "Votre nouveau code de récupération est";
$_LANG['twofabackupcodelogin'] = "Entrez votre code de récupération ci-dessous pour vous connecter";
$_LANG['twofabackupcodeexpl'] = "Écrivez-le sur un papier et conservez-le en sécurité.<br />Il vous sera nécessaire si jamais vous perdez votre second facteur de sécurité ou s'il n'est pas disponible.";
$_LANG['twofaconfirmpw'] = "Entrez votre mot de passe";
$_LANG['twofa2ndfactorreq'] = "Votre deuxième facteur est requis pour compléter la connexion.";
$_LANG['twofa2ndfactorincorrect'] = "Le deuxième facteur saisi est incorrect. Veuillez essayer à nouveau. Vous avez encore :attempts tentatives.";
$_LANG['twofabackupcodereset'] = "Connexion avec votre code de récupération réussie. Le code de récupération n'est valide qu'une seule fois, il sera maintenant réinitialisé.";
$_LANG['twofacantaccess2ndfactor'] = "Impossible d'avoir accès à votre périphérique de deuxième facteur?";
$_LANG['twofaloginusingbackupcode'] = "Connexion avec votre code de récupération";
$_LANG['twofageneralerror'] = "Une erreur est survenue lors du chargement du module. Veuillez essayer de nouveau.";

$_LANG['continue'] = "Continuer";
$_LANG['disable'] = "Désactiver";
$_LANG['manage'] = "Gérer";

# Version 5.3
$_LANG['quoteacceptancetitle'] = "Approbation du devis";
$_LANG['quoteacceptancehowto'] = "Pour accepter le devis, veuillez confirmer que vous acceptez nos termes de services.";
$_LANG['quoteacceptancewarning'] = "Veuillez être conscient que l'acceptation d'un devis est considéré comme un contrat et que vous ne serez pas en mesure d'annuler une fois que vous avez accepté.";

$_LANG['contactform'] = "Formulaire de contact";

$_LANG['twoipconnect'] = "Connectez votre application";
$_LANG['twoipinstruct'] = "En utilisant une application d'authentification comme %s ou %s, scannez le code QR ci-dessous. Vous avez du mal à scanner le code? Entrez le code manuellement:";
$_LANG['twoipverificationstepmsg'] = "Entrez le code à 6 chiffres que l'application génère pour vérifier et terminer la configuration.";
$_LANG['twoipenterauth'] = "Entrez le code d'authentification";
$_LANG['twoipgoogleauth'] = "Google Authenticator";
$_LANG['twoipduo'] = "Duo";
$_LANG['twoipcodemissmatch'] = "Le code que vous avez entré ne correspond pas à celui attendu. Veuillez réessayer.";
$_LANG['twoipgdmissing'] = "GD est manquant depuis la configuration PHP sur votre serveur, il est ainsi impossible de générer l'image";

$_LANG['domaincontactdetails']['First Name'] = "Prénom";
$_LANG['domaincontactdetails']['Last Name'] = "Nom de famille";
$_LANG['domaincontactdetails']['Full Name'] = "Nom complet";
$_LANG['domaincontactdetails']['Contact Name'] = "Nom du contact";
$_LANG['domaincontactdetails']['Email'] = "Courriel";
$_LANG['domaincontactdetails']['Email Address'] = "Adresse Courriel";
$_LANG['domaincontactdetails']['Job Title'] = "Poste";
$_LANG['domaincontactdetails']['Company Name'] = "Nom de l'entreprise";
$_LANG['domaincontactdetails']['Organisation Name'] = "Nom de l'organisation";
$_LANG['domaincontactdetails']['Address'] = "Adresse";
$_LANG['domaincontactdetails']['Street'] = "Rue";
$_LANG['domaincontactdetails']['Address 1'] = "Addresse 1";
$_LANG['domaincontactdetails']['Address 2'] = "Addresse 2";
$_LANG['domaincontactdetails']['Address 3'] = "Addresse 3";
$_LANG['domaincontactdetails']['City'] = "Ville";
$_LANG['domaincontactdetails']['State'] = "État ou Province";
$_LANG['domaincontactdetails']['County'] = "Pays";
$_LANG['domaincontactdetails']['Region'] = "Région";
$_LANG['domaincontactdetails']['Postcode'] = "Code postal";
$_LANG['domaincontactdetails']['ZIP Code'] = "Code postal";
$_LANG['domaincontactdetails']['ZIP'] = "Code postal";
$_LANG['domaincontactdetails']['Country'] = "Pays";
$_LANG['domaincontactdetails']['Phone'] = "Téléphone";
$_LANG['domaincontactdetails']['Phone Number'] = "Numéro de téléphone";
$_LANG['domaincontactdetails']['Fax'] = "Télécopieur";
$_LANG['domaincontactdetails']['Phone Country Code'] = "Code pays du téléphone";

$_LANG['serverhostnameexample'] = "ex. serveur1(.example.com)";
$_LANG['serverns1prefixexample'] = "ex. ns1(.votredomaine.com)";
$_LANG['serverns2prefixexample'] = "ex. ns2(.votredomaine.com)";

$_LANG['hosting'] = "Hébergement";

$_LANG['enomfrregistration']['Heading'] = "Les domaines .fr ont des valeurs différentes requises en fonction de votre nationalité et le type d'enregistrement:";
$_LANG['enomfrregistration']['French Individuals']['Name'] = "Personnes françaises";
$_LANG['enomfrregistration']['French Individuals']['Requirements'] = "Veuillez fournir votre \"Date de naissance\", \"Ville de naissance\", et \"Code postal du lieu de naissance\".";
$_LANG['enomfrregistration']['EU Non-French Individuals']['Name'] = "Personnes non françaises EU";
$_LANG['enomfrregistration']['EU Non-French Individuals']['Requirements'] = "Veuillez fournir votre \"Date de naissance\".";
$_LANG['enomfrregistration']['French Companies']['Name'] = "Sociétés françaises";
$_LANG['enomfrregistration']['French Companies']['Requirements'] = "Veuillez fournir la \"Date de naissance\", \"Ville de naissance\", et le \"Code postal du lieu de naissance\" pour le propriétaire du contact, avec votre numéro de SIRET.";
$_LANG['enomfrregistration']['EU Non-French Companies']['Name'] = "Personnes non françaises EU";
$_LANG['enomfrregistration']['EU Non-French Companies']['Requirements'] = "Veuillez fournir le \"Numéro DUNS\", et la \"Date de naissance\" du propriétaire du contact.";
$_LANG['enomfrregistration']['Non-EU Warning'] = "Les informations de contact du client doivent être au sein de l'UE sinon les autres enregistrements échoueront.";

$_LANG['confirm'] = "Confirmer";

$_LANG['maxmind_checkconfiguration'] = "Une erreur s'est produite lors de la vérification de fraude. Veuillez contacter le support.";
$_LANG['maxmind_addressinvalid'] = "Votre adresse n'est pas reconnue. Veuillez vérifier et entrer de nouveau votre adresse.";
$_LANG['maxmind_invalidip'] = "Adresse IP invalide ou adresse locale détectée. Veuillez contacter l'assistance technique.";

$_LANG['ssounabletologin'] = "Impossible d'utiliser la connexion automatique. Veuillez contacter le support.";
$_LANG['ssofatalerror'] = "Une erreur fatale est survenue. Veuillez contacter le support.";

$_LANG['customActionGenericError'] = "Unable to perform action. Please contact support.";
$_LANG['customActionException'] = "An exception has occurred. Please contact support.";

# Version 6.0

$_LANG['announcementschoosemonth'] = "Choisir le mois";
$_LANG['announcementsbymonth'] = "Par mois";
$_LANG['announcementsolder'] = "Anciennes annonces";
$_LANG['createnewcontact'] = "Nouveau contact...";
$_LANG['due'] = "Dû";
$_LANG['affiliatessignups'] = "Nombre d'inscriptions";
$_LANG['affiliatesconversionrate'] = "Taux de conversion";
$_LANG['affiliatesclicks'] = "Clics";
$_LANG['contacts'] = "Contacts";
$_LANG['backtoservicedetails'] = "Retour aux détails du service";
$_LANG['invoicesintro'] = "Vous pouvez consulter ici votre historique de facturation.";

$_LANG['sidebars']['viewAccount']['yourAccount'] = "Votre Compte";
$_LANG['sidebars']['viewAccount']['myDetails'] = "Mes coordonnées";
$_LANG['sidebars']['viewAccount']['billingInformation'] = "Information de facturation";
$_LANG['sidebars']['viewAccount']['contacts/subAccounts'] = "Contacts/Sous-comptes";
$_LANG['sidebars']['viewAccount']['changePassword'] = "Modifier mon mot de passe";
$_LANG['sidebars']['viewAccount']['securitySettings'] = "Réglages de sécurité";
$_LANG['sidebars']['viewAccount']['emailHistory'] = "Historique des courriels";

$_LANG['aboutsecurityquestions'] = "Pourquoi des questions de sécurité?";
$_LANG['registersecurityquestionblurb'] = "Les questions de sécurité permettent de sécuriser d'avantage votre compte. Elles seront demandées pour chaque modification de votre compte.";

$_LANG['update'] = "Mettre à jour";
$_LANG['yourinfo'] = "Vos informations";
$_LANG['shortcuts'] = "Raccourcis";

$_LANG['yourservices'] = "Vos Services";
$_LANG['yourdomains'] = "Vos Domaines";
$_LANG['yourtickets'] = "Vos Tickets";
$_LANG['managecontacts'] = "Gestion des Contacts";
$_LANG['billingdetails'] = "Details de facturation";
$_LANG['homechooseproductservice'] = "Choisissez un produit/service à gérer:";

$_LANG['invoicesdue'] = "Facture(s) en attente";
$_LANG['invoicesduemsg'] = "Vous avez actuellement %s factures impayées pour un total de %s";
$_LANG['noinvoicesduemsg'] = "Vous n'avez actuellement aucune facture impayée";

$_LANG['expiringsoon'] = "Expire bientôt";

$_LANG['notice'] = "Avis";
$_LANG['networkstatussubtitle'] = "Nouveautés & Informations";

$_LANG['myaccount'] = "Mon Compte";

$_LANG['manageproduct'] = "Gestion du produit";
$_LANG['overview'] = "Aperçu";
$_LANG['servername'] = "Serveur";
$_LANG['visitwebsite'] = "Visiter le site";
$_LANG['whoisinfo'] = "Informations WHOIS";

$_LANG['tableshowing'] = "_START_ de _END_ / _TOTAL_";
$_LANG['tableempty'] = "0 de 0 / 0";
$_LANG['tablefiltered'] = "(filtré de _MAX_ résultats)";
$_LANG['tablelength'] = "Afficher _MENU_";
$_LANG['tableloading'] = "Chargement...";
$_LANG['tableprocessing'] = "Traitement...";
$_LANG['tablepagesfirst'] = "Premier";
$_LANG['tablepageslast'] = "Dernier";
$_LANG['tablepagesnext'] = "Suivant";
$_LANG['tablepagesprevious'] = "Précédent";
$_LANG['tableviewall'] = "Tous";
$_LANG['tableentersearchterm'] = "Entrez un mot-clé...";

$_LANG['actions'] = "Actions";

$_LANG['upgradedowngradeshort'] = "Passer à une version inférieure/supérieure";

$_LANG['masspayintro'] = "Payez plusieurs factures d'un coup";
$_LANG['masspaymentselectgateway'] = "Sélectionnez le mode de paiement";

$_LANG['ticketfeedbackrequest'] = "Évaluation";
$_LANG['ticketfeedbackforticket'] = "pour demande #";

$_LANG['notifications'] = "Notifications";
$_LANG['notificationsnone'] = "Vous n'avez pas de notification";

$_LANG['creditcardnonestored'] = "Il n'y a pas de carte enregistrée";

$_LANG['kbviewingarticlestagged'] = "Voir les articles sélectionnés";

$_LANG['domainprivatenameservers'] = "Serveurs DNS privés";

$_LANG['transferinadomain'] = "Transférer un nom de domaine";

$_LANG['nodomainextensions'] = "Il n'y a actuellement pas d'extensions configurées pour l'achat.";

$_LANG['homebegin'] = "Vérifiez la disponibilité d'un nom de domaine";
$_LANG['howcanwehelp'] = "Que voulez-vous faire?";
$_LANG['exampledomain'] = "exemple: example.com";
$_LANG['buyadomain'] = "Acheter un domaine?";
$_LANG['orderhosting'] = "Un hébergement?";
$_LANG['makepayment'] = "Régler une facture?";
$_LANG['getsupport'] = "Nous contacter?";

$_LANG['news'] = "Actualités";
$_LANG['allthelatest'] = "Toutes les actualités de";
$_LANG['readmore'] = "En savoir plus";
$_LANG['noannouncements'] = "Pas d'annonce à afficher";

$_LANG['kbsearchexplain'] = "Vous avez une question?";
$_LANG['readyforquestions'] = "Nous attendons vos questions";

$_LANG['restrictedpage'] = "Accès restreint";
$_LANG['enteremail'] = "Adresse courriel";
$_LANG['restricted'] = "Limité";

$_LANG['passwordtips'] = "<strong>Conseils pour un mot de passe sécurisé</strong><br />Utilisez des minuscules et des majuscules<br />Utilisez un/des symboles de ce type: # $ ! % &amp; ...<br />N'utilisez pas de mot du dictionnaire";

$_LANG['regdate'] = "Enregistrement";
$_LANG['nextdue'] = "Échéance";

$_LANG['findyourdomain'] = "Trouvez un nom de domaine!";
$_LANG['searchtermrequired'] = "Vous devez entrer un nom de domaine ou un mot-clé pour lancer la recherche";
$_LANG['unabletolookup'] = "Désolé, impossible de rechercher ce mot-clé";
$_LANG['invalidchars'] = "le mot clé ne doit pas contenir d'espace ou de caractères spéciaux";
$_LANG['bulkoptions'] = "Options de masse";
$_LANG['checkingdomain'] = "Nous vérifions si le nom de domaine est disponible...";
$_LANG['domainsgotocheckout'] = "Régler ma commande";
$_LANG['domainssearchresults'] = "Résultats de la recherche";
$_LANG['domainssuggestions'] = "Suggestions";
$_LANG['domainsothersuggestions'] = "Vous serez peut-être intéressé par les noms de domaine suivant:";
$_LANG['domainsmoresuggestions'] = "Donnez-moi plus de suggestions!";
$_LANG['domainssuggestionswarnings'] = "Les suggestions de nom de domaine peuvent ne pas toujours être disponibles. La disponibilité est vérifiée en temps réel au moment de l'ajout à votre panier.";
$_LANG['disclaimers'] = "Avertissements";
$_LANG['tldpricing'] = "- tarifs";
$_LANG['alltldpricing'] = "Tous les prix";

$_LANG['quotesdesc'] = "Devis généré";
$_LANG['quotesrejected'] = "Rejeté";

$_LANG['ticketsyourhistory'] = "Votre historique de demandes";

$_LANG['clientareaemaildesc'] = "Historique des courriels que nous vous avons envoyés";

$_LANG['sslconfssl'] = "Configurer SSL";
$_LANG['sslnoconfigurationpossible'] = "La configuration a été effectuée. Si vous rencontrez des problèmes, veuillez contacter le support.";

$_LANG['adminloggedin'] = "Vous êtes connecté comme administrateur";
$_LANG['returntoadminarea'] = "Retourner à l'administration";
$_LANG['adminmasqueradingasclient'] = "Vous êtes connecté comme client.";
$_LANG['logoutandreturntoadminarea'] = "Déconnexion & retour à l'administration";

$_LANG['supportAndUpdatesExpired'] = "Le support et les mises à jour ont expiré";
$_LANG['supportAndUpdatesExpiredLicense'] = "Le support et les mises à jour de cette licence ont expiré";
$_LANG['supportAndUpdatesRenewalRequired'] = "Le support et les mises à jour doivent être renouvelés afin d'accéder à ce téléchargement.";
$_LANG['supportAndUpdatesClickHereToRenew'] = "Veuillez cliquer ici pour renouveler";

$_LANG['pwresetemailneeded'] = "Vous avez oublié votre mot de passe? Veuillez entrer votre adresse courriel pour initier la réinitialisation.";

$_LANG['quotestageexpired'] = "Expiré";

$_LANG['ticketinfo'] = "Information de la demande";
$_LANG['customfield'] = "Champs personnalisés";

$_LANG['domainsActive'] = "Actif";
$_LANG['domainsExpired'] = "Expiré";
$_LANG['domainsCancelled'] = "Annulé";
$_LANG['domainsFraud'] = "Fraude";
$_LANG['domainsPending'] = "En attente";
$_LANG['domainsPendingRegistration'] = "Eregistrement en cours";
$_LANG['domainsPendingTransfer'] = "En attente de transfert";
$_LANG['domainsTransferredAway'] = "Transféré ailleurs";

$_LANG['kbtagcloud'] = "Nuage de tags";

$_LANG['cancellationrequestedexplanation'] = "Il y a une annulation en cours pour ce produit/service";
$_LANG['cancellationrequested'] = "Annulation demandée";

$_LANG['yourrecenttickets'] = "Vos dernières demandes";

$_LANG['domains']['deTermsDescription1'] = "Pour enregister ou transférer un nom de domaine ou uniquement changer les informations de contact du propriétaire, vous devez accepter les CGU de l'extension .DE";
$_LANG['domains']['deTermsDescription2'] = "(Conditions Générales d'Utilisation de l'extension .DE: http://www.denic.de/en/bedingungen.html.)";
$_LANG['directDebitPageTitle'] = "Paiement par prélèvement automatique";
$_LANG['directDebitHeader'] = "Paiement par prélèvement automatique";
$_LANG['directDebitErrorNoBankName'] = "Vous devez entrer le nom de votre banque";
$_LANG['directDebitErrorAccountType'] = "Vous devez choisir le type de compte de banque";
$_LANG['directDebitErrorNoABA'] = "Vous devez entrer le code ABA de votre banque";
$_LANG['directDebitErrorAccNumber'] = "Vous devez entrer le numéro de votre compte";
$_LANG['directDebitErrorConfirmAccNumber'] = "Vous devez confirmer le numéro de votre compte";
$_LANG['directDebitErrorAccNumberMismatch'] = "Votre numéro de compte &amp; sa confirmation ne correspondent pas";
$_LANG['directDebitThanks'] = "Merci de nous avoir transmis vos informations. Nous allons tenter de procéder votre paiement dans les prochains jours. Nous vous contacterons en cas de problèmes.";
$_LANG['directDebitPleaseSubmit'] = "Veuillez soumettre vos détails bancaires ci-dessous afin de procéder au prélèvement automatique.";
$_LANG['directDebitBankName'] = "Nom de la banque";
$_LANG['directDebitAccountType'] = "Type de compte";
$_LANG['directDebitABA'] = "Code ABA de la banque";
$_LANG['directDebitAccNumber'] = "Numéro du compte";
$_LANG['directDebitConfirmAccNumber'] = "Confirmer le numéro du compte";
$_LANG['directDebitSubmit'] = "Envoyer";
$_LANG['directDebitChecking'] = "Chèques";
$_LANG['directDebitSavings'] = "Épargnes";

$_LANG['outOfStockProductRemoved'] = "Un produit non disponible a été retiré automatiquement de votre panier";

$_LANG['subaccountpermsquotes'] = "Aperçu/Acceptation des devis";

$_LANG['chooselanguage'] = "Choisir la langue";

$_LANG['success'] = "Succès";
$_LANG['error'] = "Erreur";
$_LANG['print'] = "Imprimer";
$_LANG['invoicelineitems'] = "Items de la facture";

$_LANG['quotelineitems'] = "Items du devis";

$_LANG['quoteproposal'] = "Proposition";
$_LANG['quoteacceptagreetos'] = "Veuillez accepter les Conditions Générales d'Utilisation.";
$_LANG['quoteacceptcontractwarning'] = "En acceptant ce devis, vous vous engagez à contracter le produit. Ce contrat ne peut être annulé.";

// Client alerts
$_LANG['clientAlerts']['creditCardExpiring'] = "Votre carte de crédit :creditCardType-:creditCardLastFourDigits expire dans :days jours. Veuillez mettre à jour ces informations dès que possible.";
$_LANG['clientAlerts']['domainsExpiringSoon'] = "Vous avez :numberOfDomains domaine(s) qui expirent ces :days prochains jours.";
$_LANG['clientAlerts']['invoicesUnpaid'] = "Vous avez :numberOfInvoices facture(s) impayée(s).";
$_LANG['clientAlerts']['invoicesOverdue'] = "Vous avez :numberOfInvoices paiement(s) en retard pour un total de :balanceDue. Veuillez régulariser rapidement la situation pour éviter une interruption de service.";
$_LANG['clientAlerts']['creditBalance'] = "Vous avez un crédit disponible de :creditBalance.";

// Client homepage panels
$_LANG['clientHomePanels']['unpaidInvoices'] = "Factures impayées";
$_LANG['clientHomePanels']['unpaidInvoicesMsg'] = "Vous avez :numberOfInvoices facture(s) impayée(s) pour un total de :balanceDue.";
$_LANG['clientHomePanels']['overdueInvoices'] = "Paiements en retard";
$_LANG['clientHomePanels']['overdueInvoicesMsg'] = "Vous avez :numberOfInvoices paiement(s) en retard pour un total de :balanceDue. Veuillez régulariser rapidement la situation pour éviter une interruption de service.";
$_LANG['clientHomePanels']['domainsExpiringSoon'] = "Domaines qui expirent bientôt";
$_LANG['clientHomePanels']['domainsExpiringSoonMsg'] = "Vous avez :numberOfDomains domaine(s) qui expirent ces :days prochains jours. Vous pouvez les renouveler.";
$_LANG['clientHomePanels']['activeProductsServices'] = "Vos produits/services actifs";
$_LANG['clientHomePanels']['activeProductsServicesNone'] = "Vous n'avez aucun produit/service. <a href=\"cart.php\">Passer une commande</a>.";
$_LANG['clientHomePanels']['recentNews'] = "Actualités récentes";
$_LANG['clientHomePanels']['affiliateProgram'] = "Programme d'affiliation";
$_LANG['clientHomePanels']['recentSupportTickets'] = "Dernières demandes";
$_LANG['clientHomePanels']['recentSupportTicketsNone'] = "Aucune demande. Si vous avez besoin d'aide, vous pouvez <a href=\"submitticket.php\">ouvrir une demande</a>.";
$_LANG['clientHomePanels']['affiliateSummary'] = "Votre commission actuelle est de :commissionBalance. Vous devez encore gagner :amountUntilWithdrawalLevel avant de pouvoir retirer vos gains.";
$_LANG['clientHomePanels']['affiliateSummaryWithdrawalReady'] = "Votre balance actuelle de commission est de :commissionBalance. Vous pouvez retirer vos gains maintenant.";
$_LANG['clientHomePanels']['productsAndServices'] = "Browse our Products/Services";

$_LANG['upgradeNotPossible'] = "Version supérieure indisponible. Si vous pensez que ceci est une erreur, contactez-nous.";
$_LANG['upgradeSameProductMustExtendCycle'] = "Pour mettre à niveau votre cycle de facturation, veuillez choisir un cycle supérieur à votre cycle de facturation actuel.";

$_LANG['hostingInfo'] = "Informations concernant l'hébergement";
$_LANG['additionalInfo'] = "Informations supplémentaires";
$_LANG['resourceUsage'] = "Utilisation des ressources";
$_LANG['primaryIP'] = "IPs primaires";
$_LANG['assignedIPs'] = "IPs assignées";
$_LANG['diskSpace'] = "Espace disque";
$_LANG['bandwidth'] = "Bande passante";
$_LANG['registered'] = "Enregistré";
$_LANG['upgrade'] = "Mise à niveau";

$_LANG['downdoadsdesc'] = "Documentation, logiciels, et autres fichiers";

$_LANG['doToday'] = "Qu'est ce que vous voulez faire aujourd'hui?";
$_LANG['changeDomainNS'] = "Modifier les DNS";
$_LANG['updateWhoisContact'] = "Mettre à jours les informations WHOIS de votre domaine";
$_LANG['changeRegLock'] = "Modifier le verrouillage de votre domaine";
$_LANG['renewYourDomain'] = "Renouveler le domaine";

$_LANG['oops'] = "Oups";
$_LANG['goback'] = "Retour";
$_LANG['returnhome'] = "Retour à l'accueil";
$_LANG['blankCustomField'] = "(pas de valeur)";

$_LANG['viewAll'] = "Afficher tout";
$_LANG['moreDetails'] = "Plus de détails";

$_LANG['clientHomeSearchKb'] = "Interrogez notre base de connaissances...";

$_LANG['whoisContactWarning'] = "Il est important de conserver vos informations WHOIS à jour afin d'éviter de perdre le contrôle de votre nom de domaine.";

$_LANG['paymentstodate'] = "Paiements à date";
$_LANG['balancedue'] = "Total à payer";
$_LANG['submitpayment'] = "Effectuer un paiement";

$_LANG['domaincheckeravailable'] = "Disponible";
$_LANG['domaincheckertransferable'] = "Transférable";
$_LANG['domaincheckertaken'] = "Non disponible";
$_LANG['domaincheckeradding'] = "Ajout en cours";
$_LANG['domaincheckeradded'] = "Ajouté";
$_LANG['domaincheckernomoresuggestions'] = "C'est tout ce que nous avons trouvé, veuillez entrer un autre mot-clé.";
$_LANG['domaincheckerunabletooffertld'] = "Malheureusement nous ne pouvons pas enregistrer ce domaine en ce moment.";
$_LANG['domaincheckerbulkplaceholder'] = "Entrez jusqu'à 20 noms de domaine.\nUn seul nom de domaine par ligne.\n\nExemple:\nexample.com\nexample.net";

$_LANG['domainchecker']['suggestiontakentitle'] = "Domaine non disponible";
$_LANG['domainchecker']['suggestiontakenmsg'] = "Malheureusement le nom de domaine que vous avez choisi n'est pas disponible. Cela peut arriver lorsque le domaine vient juste d'être enregistré. Veuillez retourner en arrière et choisir un autre nom de domaine.";
$_LANG['domainchecker']['suggestiontakenchooseanother'] = "Veuillez choisir un autre nom de domaine";

$_LANG['domainchecker']['alreadyincarttitle'] = "Déjà dans le panier";
$_LANG['domainchecker']['alreadyincartmsg'] = "Ce nom de domaine est déjà dans votre panier. Veuillez aller à la caisse afin de compléter votre achat.";
$_LANG['domainchecker']['alreadyincartcheckoutnow'] = "Aller à la caisse";

$_LANG['genericerror']['title'] = "Oups, il y a eu une erreur!";
$_LANG['genericerror']['msg'] = "Veuillez réessayer plus tard et si le problème persiste, veuillez contacter notre support.";

# Licensing Addon

$_LANG['licensingaddon']['mylicenses'] = "Mes licences";
$_LANG['licensingaddon']['latestdownload'] = "Dernier Téléchargement";
$_LANG['licensingaddon']['downloadnow'] = "Télécharger maintenant";
$_LANG['licensingaddon']['licensekey'] = "Clé de licence";
$_LANG['licensingaddon']['validdomains'] = "Domaines valides";
$_LANG['licensingaddon']['validips'] = "IPs valides";
$_LANG['licensingaddon']['validdirectory'] = "Répertoire valide";
$_LANG['licensingaddon']['status'] = "Statut de la licence";
$_LANG['licensingaddon']['reissue'] = "Réémettre la licence";
$_LANG['licensingaddon']['reissuestatusmsg'] = "Le domaine est valide, l'IP et le répertoire seront détectés et enregistrés la prochaine fois que la licence sera utilisée.";
$_LANG['licensingaddon']['manageLicense'] = "Gérer la licence";

$_LANG['affiliateWithdrawalSummary'] = "Vous pourrez effectuer un retrait dès que vous aurez atteint un minimum de :amountForWithdrawal.";

$_LANG['projectManagement']['activeProjects'] = "Vos projets actifs";

# cPanel Module

$_LANG['packageDomain'] = "Forfait/Domaine";
$_LANG['addonsExtras'] = "Ajouts";
$_LANG['purchaseActivate'] = "Acheter et activer";

$_LANG['usageStats'] = "Statistiques d'utilisation";
$_LANG['diskUsage'] = "Espace disque";
$_LANG['bandwidthUsage'] = "Bande passante";
$_LANG['usageStatsBwLimitNear'] = "Vous êtes proche de la limite de bande passante.";
$_LANG['usageStatsDiskLimitNear'] = "Vous êtes proche de la limite de l'espace disque";
$_LANG['usageUpgradeNow'] = "Mettre à niveau maintenant";
$_LANG['usageLastUpdated'] = "Dernières mises à jour";

$_LANG['quickShortcuts'] = "Raccourcis";
$_LANG['cPanel']['emailAccounts'] = "Comptes courriels";
$_LANG['cPanel']['forwarders'] = "Redirection courriels";
$_LANG['cPanel']['autoresponders'] = "Réponses automatiques";
$_LANG['fileManager'] = "Gestinonnaire de fichiers";
$_LANG['cPanel']['backup'] = "Sauvegarde";
$_LANG['cPanel']['subdomains'] = "Sous-domaines";
$_LANG['cPanel']['addonDomains'] = "Domaines supplémentaires";
$_LANG['cPanel']['cronJobs'] = "Tâches Cron";
$_LANG['mysqlDatabases'] = "Bases de données MySQL";
$_LANG['cPanel']['phpMyAdmin'] = "phpMyAdmin";
$_LANG['cPanel']['awstats'] = "Awstats";

$_LANG['cPanel']['createEmailAccount'] = "Créer rapidement une adresse courriel";
$_LANG['cPanel']['usernamePlaceholder'] = "Votre nom";
$_LANG['cPanel']['passwordPlaceholder'] = "Votre mot de passe";
$_LANG['cPanel']['create'] = "Créer";
$_LANG['cPanel']['emailAccountCreateSuccess'] = "Compte courriel créé avec succès!";
$_LANG['cPanel']['emailAccountCreateFailed'] = "La création de votre compte courriel a échoué: ";

$_LANG['cPanel']['packageNotActive'] = "Ce forfait d'hébergement est actuellement non disponible";
$_LANG['cPanel']['statusPendingNotice'] = "Vous ne pouvez pas utiliser cet hébergement parce qu'il n'est pas actif.";
$_LANG['cPanel']['statusSuspendedNotice'] = "Vous ne pouvez plus utiliser cet hébergement jusqu'a ce qu'il soit à nouveau activé.";

$_LANG['wordpress']['invalidPath'] = "The supplied path is invalid.";

$_LANG['billingOverview'] = "Aperçu de la facturation";

$_LANG['liveHelp']['chatNow'] = "Nous contacter en ligne";

$_LANG['quotes'] = "Devis";

$_LANG['productMustBeActiveForModuleCmds'] = "Le produit doit être actif pour effectuer cette action.";
$_LANG['domainCannotBeManagedUnlessActive'] = "Ce nom de domaine n'est pas actif, vous ne pouvez pas le gérer.";

$_LANG['actionRequiresAtLeastOneDomainSelected'] = "Veuillez sélectionner au moins un domaine pour effectuer les actions choisies.";

$_LANG['clientAreaProductDownloadsAvailable'] = "Les téléchargements suivants sont disponibles pour vos produits/services";
$_LANG['clientAreaProductAddonsAvailable'] = "Des ajouts sont disponibles pour vos produits/services. <a href=\"cart.php?gid=addons\">Cliquez ici pour voir &amp; commander &raquo;</a>";
$_LANG['clientAreaSecurityTwoFactorAuthRecommendation'] = "Nous vous recommandons d'activer l'authentification à deux facteurs pour une sécurité renforcée.";
$_LANG['clientAreaSecurityNoSecurityQuestions'] = "Définir une question de sécurité aide à protéger votre compte d'une rinitialisation non autorisée de votre mot de passe et nous permet de vérifier votre identité lors de la modification des informations sur votre compte.";
$_LANG['clientAreaSecuritySecurityQuestionOtherError'] = "Une question de sécurité aide à protéger votre compte d'une réinitialisation non autorisée de votre mot de passe et nous permet de vérifier votre identité lors de la modification des informations sur votre compte.";

$_LANG['billingAddress'] = "Adresse de facturation";

$_LANG['noPasswordResetWhenLoggedIn'] = "Vous ne pouvez pas demander à réinitialiser votre mot de passe lorsque vous êtes connectés. Veuillez d'abord vous déconnecter.";

$_LANG['unableToLoadShoppingCart'] = "Impossible de charger votre panier. Veuillez contacter le support.";

$_LANG['showMenu'] = "Afficher le Menu";
$_LANG['hideMenu'] = "Cacher le Menu";

$_LANG['from'] = "À partir de";
$_LANG['featuredProduct'] = "Plus populaires";
$_LANG['shoppingCartProductPerMonth'] = "<span>:price</span>/:countmo";
$_LANG['shoppingCartProductPerYear'] = "<span>:price</span>/:countan";

$_LANG['orderForm']['findNewDomain'] = "Trouvez votre nouveau nom de domaine. Entrez votre nom ou mot clé ci-dessous pour vérifier la disponibilité.";
$_LANG['orderForm']['transferExistingDomain'] = "Transférez votre domaine chez nous et économisez.";
$_LANG['orderForm']['www'] = "www.";
$_LANG['orderForm']['returnToClientArea'] = "Retourner à l'espace client";
$_LANG['orderForm']['checkout'] = "Passer la commande";
$_LANG['orderForm']['alreadyRegistered'] = "Déjà enregistré?";
$_LANG['orderForm']['createAccount'] = "Créer un compte";
$_LANG['orderForm']['enterPersonalDetails'] = "Veuillez renseigner vos informations personnelles et votre adresse de facturation.";
$_LANG['orderForm']['correctErrors'] = "Veuillez corriger l'erreur suivante pour continuer";
$_LANG['orderForm']['existingCustomerLogin'] = "Connexion";
$_LANG['orderForm']['emailAddress'] = "Adresse courriel";
$_LANG['orderForm']['personalInformation'] = "Informations personnelles";
$_LANG['orderForm']['firstName'] = "Prénom";
$_LANG['orderForm']['lastName'] = "Nom";
$_LANG['orderForm']['phoneNumber'] = "Téléphone";
$_LANG['orderForm']['billingAddress'] = "Adresse de facturation";
$_LANG['orderForm']['companyName'] = "Nom de l'entreprise";
$_LANG['orderForm']['optional'] = "Optionnel";
$_LANG['orderForm']['streetAddress'] = "Adresse";
$_LANG['orderForm']['streetAddress2'] = "Adresse 2";
$_LANG['orderForm']['city'] = "Ville";
$_LANG['orderForm']['state'] = "Province";
$_LANG['orderForm']['country'] = "Pays";
$_LANG['orderForm']['postcode'] = "Code postal";
$_LANG['orderForm']['domainAlternativeContact'] = "Vous pouvez spécifier des informations de contact différentes pour l'enregistrement du nom de domaine si vous placez une commande pour une autre personne ou entité. Si ce n'est pas le cas, vous pouvez sauter cette section.";
$_LANG['orderForm']['accountSecurity'] = "Sécurité du compte";
$_LANG['orderForm']['mediumStrength'] = "Force moyenne";
$_LANG['orderForm']['paymentDetails'] = "Détails du paiement";
$_LANG['orderForm']['preferredPaymentMethod'] = "Veuillez choisir votre mode de paiement.";
$_LANG['orderForm']['cardNumber'] = "Numéro de la carte";
$_LANG['orderForm']['cvv'] = "Code de sécurité CVV";
$_LANG['orderForm']['additionalNotes'] = "Informations additionnelles";
$_LANG['orderForm']['continueToClientArea'] = "Continuer vers l'espace client";
$_LANG['orderForm']['reviewDomainAndAddons'] = "Veuillez vérifier votre sélection de noms de domaine ainsi que les ajouts qui sont disponibles.";
$_LANG['orderForm']['addToCart'] = "Ajouter au panier";
$_LANG['orderForm']['addedToCartRemove'] = "Retirer du panier";
$_LANG['orderForm']['configureDesiredOptions'] = "Configurez les options et procéder à la commande.";
$_LANG['orderForm']['haveQuestionsContact'] = "Si vous avez des questions, contactez-nous :";
$_LANG['orderForm']['haveQuestionsClickHere'] = "en cliquant ici";
$_LANG['orderForm']['use'] = "Utiliser";
$_LANG['orderForm']['check'] = "Vérifier";
$_LANG['orderForm']['transfer'] = "Transférer";
$_LANG['orderForm']['domainAddedToCart'] = "Le domaine à été ajouté à votre panier.";
$_LANG['orderForm']['registerLongerAndSave'] = "Enregistrez pour plus longtemps et économisez!";
$_LANG['orderForm']['tryRegisteringInstead'] = "Essayez d'enregistrer ce domaine à la place.";
$_LANG['orderForm']['domainAvailabilityCached'] = "Les disponibilités des domaines sont mises en cache, ce qui pourrait faire en sorte qu'un domaine récemment enregistré pourrait s'afficher comme disponible.";
$_LANG['orderForm']['submitTicket'] = "Soumettre une demande";
$_LANG['orderForm']['promotionAccepted'] = "Code promotionnel accepté ! Le total de votre commande a été mis à jour.";
$_LANG['orderForm']['promoCycles'] = "Expire après :cycles périodes de facturation";
$_LANG['orderForm']['productOptions'] = "Produits/Options";
$_LANG['orderForm']['qty'] = "Qté";
$_LANG['orderForm']['priceCycle'] = "Prix/Cycle";
$_LANG['orderForm']['edit'] = "Modifier";
$_LANG['orderForm']['update'] = "Mettre à jour";
$_LANG['orderForm']['remove'] = "Enlever";
$_LANG['orderForm']['applyPromoCode'] = "Appliquer le code promotionnel";
$_LANG['orderForm']['estimateTaxes'] = "Estimation des taxes";
$_LANG['orderForm']['removePromotionCode'] = "Enlever le code promotionnel";
$_LANG['orderForm']['updateTotals'] = "Mettre à jour le total";
$_LANG['orderForm']['continueShopping'] = "Ajouter d'autres produits";
$_LANG['orderForm']['removeItem'] = "Suppression d'un article";
$_LANG['orderForm']['yes'] = "Oui";
$_LANG['orderForm']['cancel'] = "Annuler";
$_LANG['orderForm']['close'] = "Fermer";
$_LANG['orderForm']['totals'] = "Total";
$_LANG['orderForm']['includedWithPlans'] = "Inclus avec tous les forfaits";
$_LANG['orderForm']['whatIsIncluded'] = "Qu'est-ce qui est inclus?";
$_LANG['orderForm']['errorNoProductGroup'] = "Impossible de charger les groupes de produits.";
$_LANG['orderForm']['errorNoProducts'] = "Le groupe de produits ne contient pas de produits visibles";
$_LANG['orderForm']['errorNoGateways'] = "Aucune méthode de paiement disponible, impossible de traiter la commande.";
$_LANG['orderForm']['errorUnavailableGateway'] = "La méthode sélectionnée n'est pas disponible. Merci de choisir une option dans la section Détails du paiment.";
$_LANG['orderForm']['requiredField'] = "(les champs requis sont indiqués par un *)";

$_LANG['cloudSlider']['feature01Title'] = "Disponibilité maximale des serveurs";
$_LANG['cloudSlider']['feature01Description'] = "La disponibilité du serveur est critique pour toutes les entreprises - considérer le comme le battement de cœur de votre entreprise d'hébergement. Les serveurs de fichiers, de bases de données, de messagerie et Web sont des éléments indispensables de la plupart des processus d'affaires, et les temps d'arrêt ont des effets négatifs directs sur la productivité, les ventes, les employés et la satisfaction de la clientèle. Voilà pourquoi assurer la disponibilité maximale des serveurs est si important pour nous - nous voulons vous assurer que vos processus d'affaires en cours d'exécution sont en bonne santé afin que vos clients soient heureux.";
$_LANG['cloudSlider']['feature01DescriptionTwo'] = "En nous faisant confiance pour vos besoins d'affaires, nous vous promettons une disponibilité de 99,9% sur les services que nous offrons, en dehors de toute maintenance standard.";
$_LANG['cloudSlider']['feature02Title'] = "Livraison des données dans le monde entier";
$_LANG['cloudSlider']['feature02Description'] = "Nos services sont alimentés par des centaines de serveurs et centres de données situés partout dans le monde, afin que vous puissiez dormir tranquille en sachant que les clients peuvent accéder à votre site à partir de n'importe où. En outre, nous fournissons des outils de surveillance pour vous fournir des analyses d'experts - le trafic de votre site Web est une étape importante dans l'amélioration de l'efficacité et de la popularité de votre site, ainsi que de garder la trace de l'endroit d'où vos visiteurs viennent, le moment de la journée où ils vous rendent visite et combien de temps ils restent. Notre dévouement à un marché mondial s'étend aux enregistrements de domaine, nous offrons les TLD les plus populaires pour l'enregistrement.";
$_LANG['cloudSlider']['feature02DescriptionTwo'] = "Notre dévouement au support client est à travers le monde aussi. Nous sommes ici pour vous aider avec votre hébergement de toute manière possible, et vous pouvez nous joindre par téléphone, courriel ou clavardage en direct.";
$_LANG['cloudSlider']['feature03Title'] = "Sécurité à la fine pointe";
$_LANG['cloudSlider']['feature03Description'] = "Rester serein en sachant que nous fournissons un service 24/7 de surveillance de la sécurité et de protection DDoS. Vous prenez la protection des données de vos clients au sérieux, et nous aussi. Notre équipe et les garanties de sécurité sont au travail toute la journée, tous les jours pour fournir le niveau de sécurité nécessaire dans l'ère du numérique.";
$_LANG['cloudSlider']['feature03DescriptionTwo'] = "Une large gamme d'outils de sécurité sont à votre disposition, y compris les certificats SSL, la configuration de pare-feu, les services de surveillance de la sécurité, l'accès VPN, et plus.";
$_LANG['cloudSlider']['selectProductLevel'] = "Sélectionnez le niveau parfait pour vous!";

$_LANG['domainChecker.additionalPricingOptions'] = "Options supplémentaires de tarification pour :domain";

$_LANG['orderpaymenttermfree'] = "Gratuit";

$_LANG['usageStatsBwOverLimit'] = "Vous avez dépassé votre limite de bande passante.";
$_LANG['usageStatsDiskOverLimit'] = "Vous avez dépassé votre limite d'espace disque.";
$_LANG['insufficientstockmessage'] = "Nous sommes actuellement en rupture de stock sur certains items, donc les quantités dans votre panier ont étés ajustées. Pour plus d'informations, contactez notre équipe de vente.";

$_LANG['only'] = "Seulement";
$_LANG['startingat'] = "À partir de";

$_LANG['yourdomainplaceholder'] = "votredomaine";
$_LANG['yourtldplaceholder'] = "com";

$_LANG['subaccountpermsproductsso'] = "Effectuer la connexion unique";

$_LANG['sso']['title'] = "Connexion unique";
$_LANG['sso']['summary'] = "Des applications tierces tirent parti de la fonctionnalité de connexion unique pour vous fournir un accès direct à votre compte de facturation sans avoir à vous réauthentifier.";
$_LANG['sso']['disablenotice'] = "Vous pouvez désactiver cette fonctionnalité si vous fournissez l'accès à l'une de vos applications tierces pour les utilisateurs à qui vous ne souhaitez pas permettre d'accéder à votre compte de facturation.";
$_LANG['sso']['enabled'] = "La connexion unique est actuellement activée pour votre compte.";
$_LANG['sso']['disabled'] = "La connexion unique est actuellement désactivée pour votre compte.";
$_LANG['sso']['redirectafterlogin'] = "Vous serez redirigé après la connexion";

$_LANG['oauth']['badTwoFactorAuthModule'] = "Mauvais module d'authentification à deux facteurs. Veuillez contacter le support.";
$_LANG['oauth']['permAccessNameAndEmail'] = "Accéder à votre nom et adresse courriel";

$_LANG['errorButTryAgain'] = "Une erreur est survenue. Veuillez essayer de nouveau.";
$_LANG['emailSent'] = "Courriel envoyé";
$_LANG['resendEmail'] = "Renvoyer le courriel de vérification";

// Markdown Editor Help
$_LANG['markdown']['title'] = "Guide de mise en forme";
$_LANG['markdown']['emphasis'] = "Accentuation du texte";
$_LANG['markdown']['bold'] = "gras";
$_LANG['markdown']['italics'] = "italique";
$_LANG['markdown']['strikeThrough'] = "barré";
$_LANG['markdown']['headers'] = "Entête";
$_LANG['markdown']['bigHeader'] = "Grande entête";
$_LANG['markdown']['mediumHeader'] = "Moyenne entête";
$_LANG['markdown']['smallHeader'] = "Petite entête";
$_LANG['markdown']['tinyHeader'] = "Minuscule entête";
$_LANG['markdown']['lists'] = "Listes";
$_LANG['markdown']['genericListItem'] = "Elément de liste générique";
$_LANG['markdown']['numberedListItem'] = "Elément de liste numéroté";
$_LANG['markdown']['links'] = "Liens";
$_LANG['markdown']['textToDisplay'] = "Texte à afficher";
$_LANG['markdown']['exampleLink'] = "http://www.example.com";
$_LANG['markdown']['quotes'] = "Citations";
$_LANG['markdown']['thisIsAQuote'] = "Ceci est une citation.";
$_LANG['markdown']['quoteMultipleLines'] = "Elle peut s'étendre sur plusieurs lignes!";
$_LANG['markdown']['tables'] = "Tables";
$_LANG['markdown']['columnOne'] = "Colonne1";
$_LANG['markdown']['columnTwo'] = "Colonne2";
$_LANG['markdown']['columnThree'] = "Colonne3";
$_LANG['markdown']['withoutAligning'] = "Ou sans aligner les colonnes...";
$_LANG['markdown']['john'] = "Jean";
$_LANG['markdown']['doe'] = "Luc";
$_LANG['markdown']['male'] = "Mâle";
$_LANG['markdown']['mary'] = "Anne";
$_LANG['markdown']['smith'] = "Marie";
$_LANG['markdown']['female'] = "Femmes";
$_LANG['markdown']['displayingCode'] = "Afficher du code";
$_LANG['markdown']['spanningMultipleLines'] = "Où l'étendre sur plusieurs lignes...";
$_LANG['markdown']['saved'] = "enregistré";
$_LANG['markdown']['saving'] = "enregistrement automatique";

$_LANG['oauth']['authoriseAppToAccess'] = "Autoriser :appName<br /> à accéder à votre compte ?";
$_LANG['oauth']['willBeAbleTo'] = "Cette application pourra";
$_LANG['oauth']['authorise'] = "Autoriser";
$_LANG['oauth']['currentlyLoggedInAs'] = "Vous êtes actuellement connecté comme :firstName :lastName";
$_LANG['oauth']['notYou'] = "Pas vous?";
$_LANG['oauth']['returnToApp'] = "Revenir à :appName";
$_LANG['oauth']['copyrightFooter'] = "Copyright &copy; :dateYear :companyName. Tous droits réservés.";
$_LANG['oauth']['loginToGrantApp'] = "Connectez vous pour autoriser :appName<br />à accéder à votre compte";
$_LANG['oauth']['redirectDescriptionOne'] = "Nous vous redirigeons vers l'application. Cela peu prendre un petit moment.";
$_LANG['oauth']['redirectDescriptionTwo'] = "Si votre navigateur ne vous redirige pas, merci de";
$_LANG['oauth']['redirectDescriptionThree'] = "cliquer ici pour continuer";
$_LANG['downloadLoginRequiredTagline'] = "Merci de vous connecter pour accéder au téléchargement de ce fichier";

$_LANG['orderForm']['year'] = "An";
$_LANG['orderForm']['years'] = "Ans";
$_LANG['orderForm']['domainOrKeyword'] = "Entrez un domaine ou un mot-clé";
$_LANG['orderForm']['searching'] = "Recherche";
$_LANG['orderForm']['domainIsUnavailable'] = "<strong>:domain</strong> n'est pas disponible";
$_LANG['orderForm']['add'] = "Ajouter";
$_LANG['orderForm']['suggestedDomains'] = "Domaines suggérés";
$_LANG['orderForm']['generatingSuggestions'] = "Génération de suggestions";
$_LANG['orderForm']['addHosting'] = "Ajoutez un hébergement";
$_LANG['orderForm']['chooseFromRange'] = "Profitez d'un vaste choix d'hébergements web";
$_LANG['orderForm']['packagesForBudget'] = "Nous avons des offres pour chaque budget";
$_LANG['orderForm']['exploreNow'] = "Parcourez les offres";
$_LANG['orderForm']['transferToUs'] = "Transférez votre domaine";
$_LANG['orderForm']['transferExtend'] = "Renouvelez ainsi d'un an votre domaine!";
$_LANG['orderForm']['transferDomain'] = "Transférez votre domaine";
$_LANG['orderForm']['extendExclusions'] = "Excepté certains TLDs et renouvellements récents";
$_LANG['orderForm']['singleTransfer'] = "Transfert d'un domaine";
$_LANG['orderForm']['enterDomain'] = "Merci de renseigner votre domaine";
$_LANG['orderForm']['authCode'] = "Code de transfert";
$_LANG['orderForm']['authCodePlaceholder'] = "EPP Code / Auth Code";
$_LANG['orderForm']['authCodeTooltip'] = "Pour initier ce transfert, vous avez besoin d'un code que vous pouvez obtenir gratuitement auprès de votre bureau d'enregistrement actuel. Ce code est communément désigné comme EPP code ou Auth code. Il agit comme un mot de passe et est unique à chaque nom de domaine.";
$_LANG['orderForm']['help'] = "Aide";
$_LANG['orderForm']['required'] = "Requis";

$_LANG['orderForm']['checkingAvailability'] = "Vérification de la disponibilité";
$_LANG['orderForm']['verifyingTransferEligibility'] = "Vérification de l'éligibilité du transfert";
$_LANG['orderForm']['verifyingDomain'] = "Vérification de votre domaine";
$_LANG['orderForm']['transferEligible'] = "Votre domaine est éligible au transfert";
$_LANG['orderForm']['transferUnlockBeforeContinuing'] = "Merci de vous assurer que vous avez déverrouillé votre domaine auprès de votre registraire actuel avant de continuer.";
$_LANG['orderForm']['transferNotEligible'] = "Non éligible au transfert";
$_LANG['orderForm']['transferNotRegistered'] = "Le domaine que vous avez renseigné ne semble pas être enregistré.";
$_LANG['orderForm']['trasnferRecentlyRegistered'] = "Si le domaine a été enregistré récemment, vous pourrez réessayer plus tard.";
$_LANG['orderForm']['transferAlternativelyRegister'] = "Autrement vous pouvez effectuer une recherche pour enregistrer ce domaine.";
$_LANG['orderForm']['domainInvalid'] = "Le nom de domaine fourni n'est pas valide";
$_LANG['orderForm']['domainInvalidCheckEntry'] = "Merci de vérifier et d'essayer à nouveau.";
$_LANG['orderForm']['domainPriceRegisterLabel'] = "Continuez pour enregistrer ce domaine pour";
$_LANG['orderForm']['domainPriceTransferLabel'] = "Transférez chez nous et renouveler pour 1 an*";

$_LANG['change'] = "Changer";

$_LANG['filemanagement']['nofileuploaded'] = "Aucun fichier téléversé.";
$_LANG['filemanagement']['invalidname'] = "Les noms de fichiers valides ne contiennent que des caractères alphanumériques, des points, des traits d'union et de soulignement.";
$_LANG['filemanagement']['couldNotSaveFile'] = "Impossible d'enregistrer le fichier téléversé.";
$_LANG['filemanagement']['checkPermissions'] = "Vérifiez les autorisations.";
$_LANG['filemanagement']['checkAvailableDiskSpace'] = "Vérifiez l'espace disque disponible.";
$_LANG['filemanagement']['fileAlreadyExists'] = "Le fichier existe déjà.";
$_LANG['filemanagement']['noUniqueName'] = "Impossible de trouver un nom de fichier unique.";

$_LANG['cartSimpleCaptcha'] = "Veuillez entrer le code ci-dessous";

$_LANG['clientHomePanels']['showingRecent100'] = "Afficher les 100 enregistrements les plus récents";
$_LANG['orderForm']['domainLetterOrNumber'] = "Les domaines doivent commencer par une lettre ou un nombre";
$_LANG['orderForm']['domainLengthRequirements'] = " et être entre <span class=\"min-length\"></span> et <span class=\"max-length\"></span> caractères de long";

$_LANG['clientareatransferredaway'] = "Transféré ailleurs";
$_LANG['clientareacompleted'] = "Complété";
$_LANG['domainContactUs'] = "Contactez-nous";

$_LANG['orderForm']['shortPerYear'] = "/:yearsan";
$_LANG['orderForm']['shortPerYears'] = "/:yearsans";

$_LANG['domainCheckerSalesGroup']['sale'] = "En vente";
$_LANG['domainCheckerSalesGroup']['hot'] = "Populaire";
$_LANG['domainCheckerSalesGroup']['new'] = "Nouveau";

$_LANG['pricing']['browseExtByCategory'] = "Parcourir les extensions par catégorie";
$_LANG['pricing']['register'] = "Enregistrement";
$_LANG['pricing']['transfer'] = "Transfert";
$_LANG['pricing']['renewal'] = "Renouvellement";
$_LANG['pricing']['selectExtCategory'] = "Choisissez une catégorie ci-dessus.";
$_LANG['pricing']['noExtensionsDefined'] = "Aucune extension disponible";

$_LANG['navStore'] = "Magasin";
$_LANG['navBrowseProductsServices'] = "Tout parcourir";

$_LANG['navWebsiteSecurity'] = "Site et sécurité";
$_LANG['navMarketConnectService']['symantec'] = "Certificats SSL";
$_LANG['navMarketConnectService']['weebly'] = "Constructeur de sites Web";
$_LANG['navMarketConnectService']['spamexperts'] = "Services de courrier électronique";

$_LANG['store']['emailServices']['title'] = "Services de courrier électronique";
$_LANG['store']['ssl']['title'] = "Certificats SSL";
$_LANG['store']['ssl']['dv']['title'] = "SSL validé par domaine";
$_LANG['store']['ssl']['ov']['title'] = "SSL validé par organisation";
$_LANG['store']['ssl']['ev']['title'] = "SSL à validation étendue";
$_LANG['store']['ssl']['wildcard']['title'] = "SSL WildCard";
$_LANG['store']['websiteBuilder']['title'] = "Constructeur de sites Web";
$_LANG['store']['configure']['configureProduct'] = "Configurer le produit";

$_LANG['store']['ssl']['dv']['tagline'] = "Sécurisez votre site en quelques minutes!";
$_LANG['store']['ssl']['dv']['descriptionTitle'] = "Qu'est-ce qu'un SSL standard validé par domaine?";
$_LANG['store']['ssl']['dv']['descriptionContent'] = "<p>Les certificats de validation de domaine offrent un moyen économique et rapide d'implémenter un SSL sur votre site. Les certificats validés par domaine vérifient que vous possédezle domaine, mais n'effectuent pas de validation supplémentaire au niveau de l'organisation.</p><p>Les certificats validés par domaine sont idéaux pour les sites Web personnels, les blogues et les médias sociaux, ou les sites qui netransmettent pas d'informations confidentielles et privées. Un certificat validé par le domaine active le cadenas du navigateur et permet l'utilisation de HTTPS pour garantir aux visiteurs et aux clients de votre site web que vous prenez leur vie privée au sérieux.</p>";

$_LANG['store']['ssl']['ov']['tagline'] = "Un SSL de haute assurance montre aux visiteurs du site votre identité authentifiée";
$_LANG['store']['ssl']['ov']['descriptionTitle'] = "Qu'est-ce qu'un SSL validé par organisation?";
$_LANG['store']['ssl']['ov']['descriptionContent'] = "<p>Les certificats SSL validés par l'organisation fournissent une confirmation d'identité instantanée et une protection SSL forte pour votre site Web et votre entreprise.</p><p>Le SSL OV est un certificat validé par organisation qui augmente la crédibilité de votre site Web par rapport aux certificats SSL validés par domaine. Il active le cadenas du navigateur et HTTPS, il montre votre identité d'entreprise et assure à vos clients que vous prenez la sécurité très au sérieux. Les visiteurs du site peuvent vérifier que le site Web est exploité par une entreprise légitime et n'est pas un site imposteur.</p>";

$_LANG['store']['ssl']['ev']['tagline'] = "Activez la barre d'adresse verte pour une confiance optimale et des conversions plus élevées.";
$_LANG['store']['ssl']['ev']['descriptionTitle'] = "Qu'est-ce qu'un SSL à validation étendue?";
$_LANG['store']['ssl']['ev']['descriptionContent'] = "<p>EV SSL est un certificat de validation étendu, la plus haute classe de SSL disponible aujourd'hui et donne plus de crédibilité et de confiance à votre site Web par rapport à l'utilisation d'une organisation ou d'un certificat SSL validé par domaine. </p><p>Un certificat SSL à validation étendue affiche dans la plupart des cas le nom de votre entreprise ou site en vert. Cette vérification visuelle proéminente donne aux visiteurs une assurance supplémentaire que des mesures ont été prises pour confirmer l'identité du site Web et de l'entreprise qu'ils visitent, augmentant la confiance des utilisateurs dans votre site Web et sa crédibilité - c'est pourquoi la plupart des grandes entreprises et organisations choisissent les certificats EV</p>";

$_LANG['store']['ssl']['wildcard']['tagline'] = "Sécuriser des sous-domaines illimités sur un certificat unique.";
$_LANG['store']['ssl']['wildcard']['descriptionTitle'] = "Qu'est-ce qu'un certificat SSL Wildcard?";
$_LANG['store']['ssl']['wildcard']['descriptionContent'] = "<p>Le SSL Wildcard permet de sécuriser un nombre illimité de sous-domaines sur un seul certificat. C'est une excellente solution pour quiconque héberge ou gère plusieurs sites ou pages qui existent sur le même domaine. Le coût ponctuel du certificat couvre les sous-domaines supplémentaires que vous pourriez éventuellement ajouter.</p><p>Contrairement à un certificat SSL standard délivré à un seul nom de domaine entièrement qualifié, par exemple: Www.votredomaine.com, ce qui signifie qu'il ne peut être utilisé que pour sécuriser le domaine exact auquel il a été délivré, un certificat SSL Wildcard est délivré à *.votredomaine.com, où l'astérisque représente tous les sous-domaines possibles.</p><p>Le SSL Wildcard est une option disponible pour les certificats de type DV et OV.</p>";

$_LANG['store']['websiteBuilder']['headline'] = "La construction d'un site Web n'a jamais été plus simple";
$_LANG['store']['websiteBuilder']['tagline'] = "Créez le site parfait avec de puissants outils de glisser-déplacer";
$_LANG['store']['websiteBuilder']['introduction'] = "Le générateur de sites en glisser-déposer de Weebly facilite la création d'un site Web puissant et professionnel sans aucune compétence technique. Plus de 40 millions d'entrepreneurs et de petites entreprises ont déjà utilisé Weebly pour créer leur présence en ligne avec un site Web, un blogue ou un magasin.";

$_LANG['store']['emailServices']['headline'] = "Sécurité de courrier électronique, construite pour vous";
$_LANG['store']['emailServices']['tagline'] = "Récupérer le contrôle de votre boîte de réception";
$_LANG['store']['emailServices']['blockSpamHeadline'] = "Bloquez près de 100% des virus, des logiciels malveillants et des pourriels avant qu'ils n'atteignent votre boîte de réception";

$_LANG['store']['sitelock']['features']['malwareScanning'] = "Scan journalier de Malware";
$_LANG['store']['sitelock']['features']['numberOfPages'] = "Nombre de pages";
$_LANG['store']['sitelock']['features']['dailyBlacklistMonitoring'] = "Monitoring journalier de Blacklist";
$_LANG['store']['sitelock']['features']['sitelockRiskScore'] = "SiteLock Risk Score";
$_LANG['store']['sitelock']['features']['websiteAppScan'] = "Website Application Scan";
$_LANG['store']['sitelock']['features']['sqlInjectionScan'] = "Scan d'injections SQL";
$_LANG['store']['sitelock']['features']['xssScan'] = "Cross Site (XSS) Scan";
$_LANG['store']['sitelock']['features']['trustSeal'] = "Sitelock&trade; Trust Seal";
$_LANG['store']['sitelock']['features']['dailySmartScans'] = "Daily SMART Scans";
$_LANG['store']['sitelock']['features']['autoMalwareRemoval'] = "Automatic Malware Removal";
$_LANG['store']['sitelock']['features']['trueshieldProtection'] = "TrueShield Protection";
$_LANG['store']['sitelock']['features']['wordPressScan'] = "WordPress Scan";
$_LANG['store']['sitelock']['features']['spamBlacklistMonitoring'] = "Spam Blacklist Monitoring";
$_LANG['store']['sitelock']['features']['waf'] = "Web Application Firewall";
$_LANG['store']['sitelock']['features']['globalCdn'] = "Global CDN";
$_LANG['store']['sitelock']['features']['contentAcceleration'] = "Content Acceleration";

$_LANG['pricingCycleShort']['monthly'] = "m";
$_LANG['pricingCycleShort']['quarterly'] = "3m";
$_LANG['pricingCycleShort']['semiannually'] = "6m";
$_LANG['pricingCycleShort']['annually'] = "an";
$_LANG['pricingCycleShort']['biennially'] = "2ans";
$_LANG['pricingCycleShort']['triennially'] = "3ans";
$_LANG['pricingCycleLong']['monthly'] = "1 Mois";
$_LANG['pricingCycleLong']['quarterly'] = "3 Mois";
$_LANG['pricingCycleLong']['semiannually'] = "6 Mois";
$_LANG['pricingCycleLong']['annually'] = "1 An";
$_LANG['pricingCycleLong']['biennially'] = "2 Ans";
$_LANG['pricingCycleLong']['triennially'] = "3 Ans";

$_LANG['navManageSsl'] = "Gérer les certificats SSL";
$_LANG['almostDone'] = "Almost Done";

$_LANG['invoicesPaymentPending'] = "Paiement en attente";

$_LANG['ssl']['changeApproverEmail'] = "Changer l'adresse courriel de l'approbateur";
$_LANG['ssl']['reissueCertificate'] = "Réémettre le certificat";
$_LANG['ssl']['retrieveCertificate'] = "Récupérer un certificat";
$_LANG['ssl']['selectValidation'] = "Select a Validation Method";
$_LANG['ssl']['dnsMethod'] = "DNS";
$_LANG['ssl']['emailMethod'] = "Email";
$_LANG['ssl']['fileMethod'] = "HTTP File";
$_LANG['ssl']['emailMethodDescription'] = "Validation will be performed by the Certificate Authority, sending an email with further instructions to the address chosen below.";
$_LANG['ssl']['dnsMethodDescription'] = "The Certificate Authority will inspect the DNS records of the domain, looking for a specific record with a unique value. Make certain you have access to administer DNS settings for the domain to complete this setup. DNS record information will be provided upon successful configuration.";
$_LANG['ssl']['fileMethodDescription'] = "The Certificate Authority will make an HTTP request to a path hosted within the domain, expecting the response to contain a unique value. The path and value will be provided upon successful configuration.";
$_LANG['ssl']['selectEmail'] = "Select an Email Address";
$_LANG['ssl']['nextSteps'] = "What's Next";
$_LANG['ssl']['emailSteps'] = "The Certificate Authority will send an email to the email address chosen. It will contain further instructions needed to validate domain ownership. Once those steps are complete, the Certificate will be issued.";
$_LANG['ssl']['fileSteps'] = "The Certificate Authority will now begin making requests to the URL below to validate the response is the value provided. Once a response with the specified value is detected, the Certificate will be issued.";
$_LANG['ssl']['dnsSteps'] = "The Certificate Authority will now begin querying the domain's DNS records for a record matching the information below. Access your domain's DNS settings and create the record. Once the record is discovered, the Certificate will be issued.";
$_LANG['ssl']['url'] = "URL";
$_LANG['ssl']['value'] = "Value";
$_LANG['ssl']['type'] = "Type";
$_LANG['ssl']['host'] = "Host";
$_LANG['ssl']['dnsRecordInformation'] = "DNS Record Information";
$_LANG['ssl']['fileInformation'] = "File Information";
$_LANG['ssl']['emailInformation'] = "Email Information";
$_LANG['ssl']['dcv'] = "Domain Control Validation";
$_LANG['ssl']['defaultcontacts'] = "Default Domain Contacts";

$_LANG['upgradeCredit'] = "Mettre à niveau le crédit";
$_LANG['upgradeCreditDescription'] = "Calcul basé sur :daysRemaining jours inutilisés sur :totalDays jours totaux dans le cycle de facturation actuel.";

$_LANG['orderForm']['domainExtensionTransferNotSupported'] = "Votre domaine n'est pas pris en charge pour nous être transféré en ce moment. Essayez un autre domaine.";
$_LANG['orderForm']['domainExtensionTransferPricingNotConfigured'] = "Votre domaine ne peut être transféré. Essayez un autre domaine.";

$_LANG['remoteAuthn']['success'] = "Succès!";
$_LANG['remoteAuthn']['errorExclamation'] = "Erreur!";
$_LANG['remoteAuthn']['error'] = "Erreur";
$_LANG['remoteAuthn']['linkInitiated'] = "Lien initié!";
$_LANG['remoteAuthn']['areYouSure'] = "Êtes-vous sûr?";
$_LANG['remoteAuthn']['yesUnlinkIt'] = "Oui, retirer le lien!";
$_LANG['remoteAuthn']['unlinked'] = "Lien retiré!";
$_LANG['remoteAuthn']['unavailable'] = "est innacessible pour le moment. Merci d'essayer ultérieurement.";
$_LANG['remoteAuthn']['connectError'] = "Nous n'avons pas été en mesure de connecter votre compte. Merci de contacter votre administrateur système.";
$_LANG['remoteAuthn']['completeSignIn'] = "Merci de finaliser la connexion en selectionnant un fournisseur d'accès.";
$_LANG['remoteAuthn']['redirecting'] = "Connexion automatique effectuée avec succès ! Redirection...";
$_LANG['remoteAuthn']['accountNowLinked'] = "Votre compte est maintenant lié avec votre compte :displayName.";
$_LANG['remoteAuthn']['oneTimeAuthRequired'] = "La connexion est requise pour associer votre compte existant.";
$_LANG['remoteAuthn']['completeRegistrationForm'] = "Merci de compléter le formulaire suivant.";
$_LANG['remoteAuthn']['completeNewAccountForm'] = "Merci de compléter les informations de votre nouveau compte.";
$_LANG['remoteAuthn']['linkedToAnotherClient'] = "Ce compte est déjà connecté avec un compte existant chez nous. Veuillez choisir un compte différent auprès d'un fournisseur d'authentification tiers.";
$_LANG['remoteAuthn']['alreadyLinkedToYou'] = "Ce compte est déjà connecté à votre compte chez nous. Veuillez choisir un compte différent auprès d'un fournisseur d'authentification tiers.";
$_LANG['remoteAuthn']['saveTimeByLinking'] = "Gagnez du temps en vous inscrivant à l'aide d'un compte existant avec l'un des services ci-dessous.";
$_LANG['remoteAuthn']['unlinkDesc'] = "Cela déconnecte définitivement le compte autorisé.";
$_LANG['remoteAuthn']['mayHaveMultipleLinks'] = "Connectez votre compte à l'un des services ci-dessous pour simplifier votre expérience de connexion. Nous n'utilisons ces informations que pour vérifier votre compte et nous ne publierons jamais en votre nom.";
$_LANG['remoteAuthn']['titleSignUpVerb'] = "Enregistrement";
$_LANG['remoteAuthn']['titleOr'] = "Ou";
$_LANG['remoteAuthn']['titleLinkedAccounts'] = "Comptes liés";
$_LANG['remoteAuthn']['provider'] = "Fournisseur";
$_LANG['remoteAuthn']['name'] = "Nom";
$_LANG['remoteAuthn']['emailAddress'] = "Adresse Courriel";
$_LANG['remoteAuthn']['actions'] = "Actions";
$_LANG['remoteAuthn']['noLinkedAccounts'] = "Aucun compte lié trouvé";
$_LANG['remoteAuthn']['signInWith'] = "Connexion avec :provider";
$_LANG['remoteAuthn']['connectWith'] = "Connecter avec :provider";
$_LANG['remoteAuthn']['signUpWith'] = "S'inscrire avec :provider";

$_LANG['unlink'] = "Délier";

$_LANG['invoicePaymentSuccessAwaitingNotify'] = "Merci d'avoir complété le processus de paiement. Nous attendons une notification pour confirmer le paiement que vous venez de faire. Nous vous enverrons un courriel de confirmation dès que celui-ci aura été reçu.";

$_LANG['errorPage']['404']['title'] = "Oops!";
$_LANG['errorPage']['404']['subtitle'] = "Nous n'avons pas pu trouver cette page";
$_LANG['errorPage']['404']['description'] = "Merci de naviguer en essayant les options ci-dessous.";
$_LANG['errorPage']['404']['home'] = "Page d'accueil";
$_LANG['errorPage']['404']['submitTicket'] = "Contacter l'assistance";

$_LANG['creditCard']['removeDescription'] = "Êtes-vous sûr de vouloir supprimer les détails de votre carte de crédit?";

$_LANG['marketConnect']['websiteBuilder']['ftpHost'] = "Hôte FTP";
$_LANG['marketConnect']['websiteBuilder']['ftpUsername'] = "Utilisateur FTP";
$_LANG['marketConnect']['websiteBuilder']['ftpPassword'] = "Mot de passe FTP";
$_LANG['marketConnect']['websiteBuilder']['ftpPath'] = "Chemin FTP";
$_LANG['marketConnect']['websiteBuilder']['updateFtp'] = "Mettre à jour les informations d'identification FTP";
$_LANG['marketConnect']['websiteBuilder']['manage'] = "Connectez-vous à Weebly";

$_LANG['domainChecker']['contactSupport'] = "Contacter l'assistance pour l'achat";

$_LANG['cart']['availableCreditBalance'] = "Votre solde créditeur disponible est :amount.";
$_LANG['cart']['applyCreditAmount'] = "Appliquer <span>:amount</span> de mon solde créditeur à cette commande et je paierai le montant restant via la méthode de paiement sélectionnée ci-dessous.";
$_LANG['cart']['applyCreditAmountNoFurtherPayment'] = "Appliquer <span>:amount</span> de mon solde créditeur à cette commande. Aucun autre paiement ne sera dû.";
$_LANG['cart']['applyCreditSkip'] = "N'appliquez aucun crédit de mon solde créditeur à cette commande. Je vais payer pour cela en utilisant la méthode de paiement sélectionnée ci-dessous.";

$_LANG['dateTime']['monday'] = "lundi";
$_LANG['dateTime']['tuesday'] = "mardi";
$_LANG['dateTime']['wednesday'] = "mercredi";
$_LANG['dateTime']['thursday'] = "jeudi";
$_LANG['dateTime']['friday'] = "vendredi";
$_LANG['dateTime']['saturday'] = "samedi";
$_LANG['dateTime']['sunday'] = "dimanche";
$_LANG['dateTime']['mon'] = "lun";
$_LANG['dateTime']['tue'] = "mar";
$_LANG['dateTime']['wed'] = "mer";
$_LANG['dateTime']['thu'] = "jeu";
$_LANG['dateTime']['fri'] = "ven";
$_LANG['dateTime']['sat'] = "sam";
$_LANG['dateTime']['sun'] = "dim";
$_LANG['dateTime']['th'] = "";
$_LANG['dateTime']['nd'] = "";
$_LANG['dateTime']['rd'] = "";
$_LANG['dateTime']['st'] = "er";
$_LANG['dateTime']['january'] = "janvier";
$_LANG['dateTime']['february'] = "février";
$_LANG['dateTime']['march'] = "mars";
$_LANG['dateTime']['april'] = "avril";
$_LANG['dateTime']['may'] = "mai";
$_LANG['dateTime']['june'] = "juin";
$_LANG['dateTime']['july'] = "juillet";
$_LANG['dateTime']['august'] = "août";
$_LANG['dateTime']['september'] = "septembre";
$_LANG['dateTime']['october'] = "octobre";
$_LANG['dateTime']['november'] = "novembre";
$_LANG['dateTime']['december'] = "décembre";
$_LANG['dateTime']['jan'] = "janv";
$_LANG['dateTime']['feb'] = "févr";
$_LANG['dateTime']['mar'] = "mars";
$_LANG['dateTime']['apr'] = "avril";
$_LANG['dateTime']['jun'] = "juin";
$_LANG['dateTime']['jul'] = "juil";
$_LANG['dateTime']['aug'] = "août";
$_LANG['dateTime']['sep'] = "sept";
$_LANG['dateTime']['oct'] = "oct";
$_LANG['dateTime']['nov'] = "nov";
$_LANG['dateTime']['dec'] = "déc";
$_LANG['dateTime']['AM'] = "";
$_LANG['dateTime']['PM'] = "";
$_LANG['dateTime']['am'] = "";
$_LANG['dateTime']['pm'] = "";
$_LANG['dateTime']['day'] = "Jour";
$_LANG['dateTime']['days'] = "Jours";
$_LANG['dateTime']['hour'] = "Heure";
$_LANG['dateTime']['hours'] = "Heures";
$_LANG['dateTime']['minute'] = "Minute";
$_LANG['dateTime']['minutes'] = "Minutes";

$_LANG['emailMarketing']['joinOurMailingList'] = "Joignez-vous à notre liste d'envoi";

$_LANG['edit'] = "Éditer";
$_LANG['thankYou'] = "Merci";
$_LANG['na'] = "N/A";

$_LANG['domainGracePeriodFeeInvoiceItem'] = "Frais de renouvellement de domaine en période de grâce :domainName";
$_LANG['domainRedemptionPeriodFeeInvoiceItem'] = "Frais de renouvellement de domaine en période de rédemption :domainName";
$_LANG['gracePeriod'] = "Période de grâce";
$_LANG['redemptionPeriod'] = "Période de rédemption";
$_LANG['domainsExpiringSoon'] = "Expire bientôt";
$_LANG['expiresToday'] = "Expire aujourd'hui";
$_LANG['clientareagrace'] = "Période de grâce (Expiré)";
$_LANG['clientarearedemption'] = "Période de rédemption (Expiré)";
$_LANG['domainRenewal']['availablePeriods'] = "Périodes de renouvellement disponibles";
$_LANG['domainRenewal']['unavailable'] = "Renouvellement de domaine indisponible";
$_LANG['domainRenewal']['renewingDomains'] = "Renouvelez vos domaines";
$_LANG['domainRenewal']['graceFee'] = "Frais de période de grâce";
$_LANG['domainRenewal']['redemptionFee'] = "Frais de période de rédemption";
$_LANG['domainRenewal']['graceRenewalPeriodDescription'] = "Les domaines entrent dans la période de grâce à l'expiration. Une fois dans ce statut, le domaine peut uniquement être renouvelé pour un maximum de la durée minimale d'enregistrement.";
$_LANG['domainRenewal']['hasExpired'] = "Ce domaine a expiré.";
$_LANG['domainRenewal']['expiringIn'] = "Expire dans :days jour(s)";
$_LANG['domainRenewal']['expiredDaysAgo'] = "A expiré il y a :days jour(s)";
$_LANG['domainRenewal']['noDomains'] = "Vous n'avez actuellement aucun domaine éligible au renouvellement";
$_LANG['domainRenewal']['showingDomains'] = "Affichage de :showing sur :totalCount domaine(s)";
$_LANG['domainRenewal']['showAll'] = "Afficher tout";
$_LANG['domainRenewal']['maximumAdvanceRenewal'] = "Le renouvellement anticipé maximal est de :days jour(s)";

$_LANG['navMarketConnectService']['sitelock'] = "Sécurité de site Web";
$_LANG['store']['sitelock']['title'] = "Sécurité de site SiteLock";
$_LANG['store']['sitelock']['tagline'] = "Analyser automatiquement votre site Web pour les logiciels malveillants et protéger sa réputation en ligne";
$_LANG['store']['sitelock']['manageService'] = "Gérer votre service SiteLock";
$_LANG['store']['sitelock']['cartShortDescription'] = "SiteLock fournit une gamme de fonctionnalités conçues pour protéger à la fois votre site Web et la réputation de votre entreprise.";
$_LANG['store']['sitelock']['plansAndPricing'] = "Plans et prix";
$_LANG['store']['sitelock']['featuresLink'] = "Fonctionnalités";
$_LANG['store']['sitelock']['websiteHacked'] = "Site Web piraté?";
$_LANG['store']['sitelock']['faq'] = "FAQ";
$_LANG['store']['sitelock']['contentHeadline'] = "Sécurité du site Web et protection contre les logiciels malveillants pour votre site Web";
$_LANG['store']['sitelock']['contentBodyParagraph1'] = "SiteLock&trade;, le leader mondial de la sécurité de site Web, protège votre site Web pour vous donner la tranquillité d'esprit.";
$_LANG['store']['sitelock']['contentBodyParagraph2'] = "L'analyse quotidienne des logiciels malveillants de SiteLock identifie les vulnérabilités et les codes malveillants connus et les supprime automatiquement de votre site Web pour protéger votre site Web et vos visiteurs contre les menaces.";
$_LANG['store']['sitelock']['contentBodyParagraph3'] = "De plus, vous obtenez le sceau de confiance SiteLock qui renforce la confiance des clients et qui augmente les ventes et le taux de conversion.";
$_LANG['store']['sitelock']['comparePlans'] = "Comparer les plans SiteLock";
$_LANG['store']['sitelock']['comparePlansSubtitle'] = "Fonctions de sécurité professionnelles pour votre site Web";
$_LANG['store']['sitelock']['featuresTitle'] = "Fonctionnalités de SiteLock";
$_LANG['store']['sitelock']['featuresHeadline'] = "Fournit une gamme de fonctionnalités conçues pour protéger à la fois votre site Web et la réputation de votre entreprise :";
$_LANG['store']['sitelock']['featuresMalwareTitle'] = "Analyse des logiciels malveillants";
$_LANG['store']['sitelock']['featuresMalwareContent'] = "Surveille et vous alerte de manière proactive pour tout logiciel malveillant détecté sur votre site Web.";
$_LANG['store']['sitelock']['featuresMalwareRemovalTitle'] = "Suppression automatique des logiciels malveillants";
$_LANG['store']['sitelock']['featuresMalwareRemovalContent'] = "Si une analyse trouve quelque chose, SiteLock supprimera automatiquement en toute sécurité tout logiciel malveillant connu.";
$_LANG['store']['sitelock']['featuresVulnerabilityTitle'] = "Analyse de vulnérabilité";
$_LANG['store']['sitelock']['featuresVulnerabilityContent'] = "Vérifie automatiquement vos applications pour s'assurer qu'elles sont à jour et protégées contre les vulnérabilités connues.";
$_LANG['store']['sitelock']['featuresOWASPTitle'] = "Protection OWASP";
$_LANG['store']['sitelock']['featuresOWASPContent'] = "Bénéficiez d'une protection contre les 10 principales failles de sécurité des applications Web reconnues par OWASP, l'Open Web Application Security Project.";
$_LANG['store']['sitelock']['featuresTrustSealTitle'] = "Sceau de confiance SiteLock&trade;";
$_LANG['store']['sitelock']['featuresTrustSealContent'] = "Donnez à vos visiteurs une confiance accrue en montrant que votre site Web est protégé par SiteLock.";
$_LANG['store']['sitelock']['featuresFirewallTitle'] = "Pare-feu";
$_LANG['store']['sitelock']['featuresFirewallContent'] = "Le pare-feu d'application Web TrueShield&trade; protège votre site Web contre les pirates et les attaques.";
$_LANG['store']['sitelock']['featuresReputationTitle'] = "Protégez votre réputation";
$_LANG['store']['sitelock']['featuresReputationContent'] = "Les analyses quotidiennes aident à détecter les logiciels malveillants avant que les moteurs de recherche aient une chance de les trouver et de mettre votre site sur liste noire.";
$_LANG['store']['sitelock']['featuresSetupTitle'] = "Configuration automatisée rapide";
$_LANG['store']['sitelock']['featuresSetupContent'] = "La configuration instantanée et entièrement automatisée vous offre une protection immédiate sans rien à installer.";
$_LANG['store']['sitelock']['featuresCDNTitle'] = "Réseau de diffusion de contenu (CDN)";
$_LANG['store']['sitelock']['featuresCDNContent'] = "Accélérez votre site Web en le distribuant dans le monde entier et en le servant à vos visiteurs à partir de l'emplacement le plus proche pour des vitesses de chargement de page plus rapides où qu'ils soient.";
$_LANG['store']['sitelock']['emergencyPlanTitle'] = "Site Web piraté?";
$_LANG['store']['sitelock']['emergencyPlanHeadline'] = "Corrigez-le maintenant avec SiteLock Emergency Response";
$_LANG['store']['sitelock']['emergencyPlanBody'] = "Si votre site Web a été attaqué et compromis, obtenez une assistance d'urgence immédiate pour récupérer rapidement votre site. Voici comment l'intervention d'urgence de SiteLock aide :";
$_LANG['store']['sitelock']['emergencyPlanResponseTitle'] = "Réponse immédiate";
$_LANG['store']['sitelock']['emergencyPlanResponseContent'] = "Bénéficiez du temps de réponse le plus rapide avec une analyse et les travaux de récupération de votre site dans un délai de 30 minutes";
$_LANG['store']['sitelock']['emergencyPlanMalwareTitle'] = "Suppression complète des logiciels malveillants";
$_LANG['store']['sitelock']['emergencyPlanMalwareContent'] = "Si notre technologie automatique ne parvient pas à supprimer le contenu malveillant, nous effectuerons un nettoyage manuel.";
$_LANG['store']['sitelock']['emergencyPlanPriorityTitle'] = "Traitement prioritaire";
$_LANG['store']['sitelock']['emergencyPlanPriorityContent'] = "Avec le package d'urgence, vous êtes rapidement dirigé vers le haut de la file d'attente.";
$_LANG['store']['sitelock']['emergencyPlanAftercareTitle'] = "Suivi 7 jours";
$_LANG['store']['sitelock']['emergencyPlanAftercareContent'] = "Suivez les progrès avec nos mises à jour en temps réel tout au long du processus de nettoyage et de récupération de votre site.";
$_LANG['store']['sitelock']['emergencyPlanUpdatesTitle'] = "Mises à jour en temps réel";
$_LANG['store']['sitelock']['emergencyPlanUpdatesContent'] = "Suivez les progrès avec nos mises à jour en temps réel tout au long du processus de nettoyage et de récupération de votre site";
$_LANG['store']['sitelock']['emergencyPlanPaymentTitle'] = "Paiement unique";
$_LANG['store']['sitelock']['emergencyPlanPaymentContent'] = "Le service d'urgence est disponible pour un prix unique, il n'y a pas de frais récurrents ni d'abonnement.";
$_LANG['store']['sitelock']['emergencyPlanOnlyCost'] = "Seulement :price pour 7 jours de protection";
$_LANG['store']['sitelock']['buyNow'] = "Acheter maintenant";
$_LANG['store']['sitelock']['faqTitle'] = "Questions fréquemment posées";
$_LANG['store']['sitelock']['faqOneTitle'] = "Qu'est-ce que SiteLock?";
$_LANG['store']['sitelock']['faqOneBody'] = "SiteLock offre une sécurité de site Web simple, rapide et abordable aux sites Web de toutes tailles. Fondée en 2008, la société protège plus de 12 millions de sites Web dans le monde. La suite de produits basée sur le cloud SiteLock offre une détection automatisée des vulnérabilités de sites Web et la suppression des logiciels malveillants, une protection DDoS, une accélération de sites Web, des évaluations des risques de sites Web et la conformité PCI.";
$_LANG['store']['sitelock']['faqOneBodyLearnMore'] = "Pour en savoir plus sur SiteLock, :learnMoreLink";
$_LANG['store']['sitelock']['faqOneBodyLearnLinkText'] = "regardez la vidéo 'Comment SiteLock fonctionne' en cliquant ici";
$_LANG['store']['sitelock']['faqTwoTitle'] = "Que fait SiteLock?";
$_LANG['store']['sitelock']['faqTwoBody'] = "SiteLock offre une sécurité complète du site Web. Il effectue des analyses quotidiennes du site Web pour identifier les vulnérabilités ou les logiciels malveillants. Lorsque des vulnérabilités ou des logiciels malveillants sont détectés, vous êtes immédiatement alerté. En fonction de votre scanner SiteLock, il supprime automatiquement tout logiciel malveillant sur votre site Web. Pour système de gestion de contenu (CMS), SiteLock peut automatiquement corriger les vulnérabilités trouvées.";
$_LANG['store']['sitelock']['faqThreeTitle'] = "Quels types de problèmes sont recherchés par SiteLock?";
$_LANG['store']['sitelock']['faqThreeBody'] = "SiteLock dispose de la technologie pour effectuer une analyse complète du site Web qui comprend :";
$_LANG['store']['sitelock']['faqThreeBodyList1Title'] = "Analyse et suppression des programmes malveillants basés sur les fichiers";
$_LANG['store']['sitelock']['faqThreeBodyList1'] = "SiteLock effectue des analyses quotidiennes des fichiers d'un site Web à la recherche de logiciels malveillants. Si un logiciel malveillant est détecté, le propriétaire du site Web est immédiatement alerté. SiteLock propose également des analyses complètes pour supprimer automatiquement le malware.";
$_LANG['store']['sitelock']['faqThreeBodyList2Title'] = "Analyse des vulnérabilités";
$_LANG['store']['sitelock']['faqThreeBodyList2'] = "SiteLock effectue des analyses des applications de site Web pour les vulnérabilités courantes qui pourraient conduire à un compromis.";
$_LANG['store']['sitelock']['faqThreeBodyList3Title'] = "Sécurité des applications et correction des vulnérabilités";
$_LANG['store']['sitelock']['faqThreeBodyList3'] = "SiteLock dispose de la technologie pour corriger automatiquement les vulnérabilités des systèmes de gestion de contenu (CMS).";
$_LANG['store']['sitelock']['faqFourTitle'] = "Que sont les vulnérabilités et les logiciels malveillants?";
$_LANG['store']['sitelock']['faqFourBodyParagraph1'] = "Une :vulnerabilityStrong est une faiblesse ou une mauvaise configuration dans le code d'un site Web ou d'une application Web qui permet à un attaquant d'obtenir un certain niveau de contrôle du site, et éventuellement du serveur d'hébergement. La plupart des vulnérabilités sont exploitées par des moyens automatisés, tels que des scanners de vulnérabilité et des botnets.";
$_LANG['store']['sitelock']['websiteVulnerability'] = "vulnérabilité du site Web";
$_LANG['store']['sitelock']['faqFourBodyParagraph2'] = ":malwareStrong. abréviation de logiciel malveillant, est utilisé pour collecter des données sensibles, obtenir un accès non autorisé aux sites Web et même détourner des ordinateurs.";
$_LANG['store']['sitelock']['malware'] = "Malware";
$_LANG['store']['sitelock']['faqFiveTitle'] = "SiteLock aura-t-il un impact sur les performances du site Web?";
$_LANG['store']['sitelock']['faqFiveBody'] = "Non. Lors d'une analyse de site Web, SiteLock télécharge les fichiers pertinents sur un serveur sécurisé et y effectue des analyses. Il n'y a aucun impact sur le contenu du site Web, le code, la bande passante ou les ressources du serveur hébergeant le site Web.";
$_LANG['store']['sitelock']['faqSixTitle'] = "Qu'est-ce que le sceau de confiance SiteLock?";
$_LANG['store']['sitelock']['faqSixBody'] = "Le sceau de confiance SiteLock est un badge de sécurité largement reconnu que vous pouvez afficher sur votre site Web. Cela indique clairement que votre site Web est sécurisé et exempt de logiciels malveillants. Pour ajouter le sceau à votre site Web, incluez simplement l'extrait de code fourni par SiteLock dans la zone de pied de page de votre site Web.";

$_LANG['learnmore'] = "En apprendre plus";
$_LANG['category'] = "Catégorie";
$_LANG['changeCurrency'] = "Changer la devise";

$_LANG['store']['ssl']['competitiveUpgrade'] = "Mise à niveau compétitive";
$_LANG['store']['ssl']['competitiveUpgradeBannerMsg'] = "Votre domaine <em>:domain</em> a été validé avec succès. Veuillez choisir un type de certificat pour continuer et terminer le processus de paiement.";
$_LANG['store']['ssl']['competitiveUpgradeQualified'] = "Qualifié pour la mise à niveau compétitive";

$_LANG['dismiss'] = "Rejeter";

$_LANG['store']['emailServices']['manageService'] = "Connectez-vous au panneau de configuration de SpamExperts";

$_LANG['noDomain'] = "Aucun domaine";

$_LANG['upgradeService']['serviceBeingUpgraded'] = "Service en cours de mise à niveau";
$_LANG['upgradeService']['chooseNew'] = "Choisissez un nouveau produit / plan";
$_LANG['upgradeService']['currentProduct'] = "Votre produit actuel";
$_LANG['upgradeService']['recommended'] = "Recommander";
$_LANG['upgradeService']['select'] = "Sélectionner";

$_LANG['feeds']['itemsInBasket'] = "Vous avez <b>:count</b> items dans votre panier";

$_LANG['validation']['accepted'] = "Le :attribute doit être accepté..";
$_LANG['validation']['active_url'] = "Le :attribute n'est pas une URL valide.";
$_LANG['validation']['after'] = "Le :attribute doit être une date après :date.";
$_LANG['validation']['alpha'] = "Le :attribute ne peut contenir que des lettres.";
$_LANG['validation']['alpha_dash'] = "Le :attribute ne peut contenir que des lettres, des chiffres et des tirets.";
$_LANG['validation']['alpha_num'] = "Le :attribute ne peut contenir que des lettres et des chiffres.";
$_LANG['validation']['array'] = "Le :attribute doit être un tableau.";
$_LANG['validation']['before'] = "Le :attribute doit être une date avant :date.";
$_LANG['validation']['between']['numeric'] = "Le :attribute doit être entre :min et :max.";
$_LANG['validation']['between']['file'] = "Le :attribute doit être entre :min et :max kilo-octets.";
$_LANG['validation']['between']['string'] = "Le :attribute doit être entre :min et :max caractères.";
$_LANG['validation']['between']['array'] = "Le :attribute doit être entre :min et :max items.";
$_LANG['validation']['boolean'] = "Le champs :attribute doit être vrai ou faux.";
$_LANG['validation']['confirmed'] = "La confirmation :attribute ne correspond pas..";
$_LANG['validation']['date'] = "Le :attribute n'est pas une date valide.";
$_LANG['validation']['date_format'] = "Le :attribute ne correspond pas au format :format.";
$_LANG['validation']['different'] = "Le :attribute et :other doit être différent.";
$_LANG['validation']['digits'] = "Le :attribute doit être de :digits chiffres.";
$_LANG['validation']['digits_between'] = "Le :attribute doit être entre :min et :max chiffres.";
$_LANG['validation']['email'] = "Le :attribute doit être une adresse courriel valide.";
$_LANG['validation']['exists'] = "Le :attribute sélectionné est valide.";
$_LANG['validation']['filled'] = "Le champs :attribute est requis.";
$_LANG['validation']['image'] = "Le :attribute doit être une image.";
$_LANG['validation']['in'] = "Le :attribute sélectionné est invalide.";
$_LANG['validation']['integer'] = "Le :attribute doit être un entier.";
$_LANG['validation']['ip'] = "Le :attribute doit être une adresse IP valide.";
$_LANG['validation']['json'] = "Le :attribute doit être une chaîne JSON valide.";
$_LANG['validation']['max']['numeric'] = "Le :attribute ne peut pas être supérieur à :max.";
$_LANG['validation']['max']['file'] = "Le :attribute ne peut pas être supérieur à :max kilo-octets.";
$_LANG['validation']['max']['string'] = "Le :attribute ne peut pas être supérieur à :max caractères.";
$_LANG['validation']['max']['array'] = "Le :attribute ne peut pas avoir plus de :max items.";
$_LANG['validation']['mimes'] = "Le :attribute doit être un fichier de type: :values.";
$_LANG['validation']['min']['numeric'] = "Le :attribute doit être au moins :min.";
$_LANG['validation']['min']['file'] = "Le :attribute doit être au moins :min kilo-octets.";
$_LANG['validation']['min']['string'] = "Le :attribute doit être au moins :min caractères.";
$_LANG['validation']['min']['array'] = "Le :attribute doit avoir au moins :min items.";
$_LANG['validation']['not_in'] = "Le :attribute sélectionné est invalide.";
$_LANG['validation']['numeric'] = "Le :attribute doit être un nombre.";
$_LANG['validation']['present'] = "Le champs :attribute doit être présent.";
$_LANG['validation']['regex'] = "Le format :attribute est invalide.";
$_LANG['validation']['required'] = "Le champs :attribute est requis.";
$_LANG['validation']['required_if'] = "Le champs :attribute est requis lorsque :other est :value.";
$_LANG['validation']['required_unless'] = "Le champs :attribute est requis à moins que :other soit dans :values.";
$_LANG['validation']['required_with'] = "Le champs :attribute est requis quand :values est présent.";
$_LANG['validation']['required_with_all'] = "Le champs :attribute est requis quand :values est présent.";
$_LANG['validation']['required_without'] = "Le champs :attribute est requis quand :values n'est pas présent.";
$_LANG['validation']['required_without_all'] = "Le champs :attribute est requis lorsque aucun :values n'est présent.";
$_LANG['validation']['same'] = "Le :attribute et :other doit correspondre.";
$_LANG['validation']['size']['numeric'] = "Le :attribute doit être :size.";
$_LANG['validation']['size']['file'] = "Le :attribute doit être :size kilo-octets.";
$_LANG['validation']['size']['string'] = "Le :attribute doit être :size caractères.";
$_LANG['validation']['size']['array'] = "Le :attribute doit contenir :size items.";
$_LANG['validation']['string'] = "Le :attribute doit être une chaîne.";
$_LANG['validation']['timezone'] = "Le :attribute doit être une zone valide.";
$_LANG['validation']['unique'] = "Le :attribute a déjà été pris.";
$_LANG['validation']['url'] = "Le format :attribute est invalide.";

$_LANG['orderErrorServerHostnameInvalid'] = "Le nom d'hôte de votre serveur n'est pas valide.";
$_LANG['orderErrorServerNameserversInvalid'] = "Le préfixe du serveur de noms n'est pas valide.";

$_LANG['toggleNav'] = "Basculer la navigation";
$_LANG['checkAll'] = "Cocher tout";
$_LANG['uncheckAll'] = "Décocher tout";

$_LANG['maxmind']['manualReview'] = "Votre commande a été retenue pour une vérification manuelle. <br /> <br /> Si vous pensez avoir reçu ce message par erreur, veuillez accepter nos excuses et <a href=\"submitticket.php\"> soumettre un billet d'assistance </a> à notre équipe du service à la clientèle.";

$_LANG['nodomain'] = "Aucun domaine spécifié";

$_LANG['store']['symantec']['cartTitle'] = "Protégez votre site avec un SSL";
$_LANG['store']['symantec']['cartShortDescription'] = "Ajoutez un SSL à votre hébergement Web pour donner aux visiteurs l'assurance que votre site Web est sûr et sécurisé et contribuez à renforcer la confiance.";

$_LANG['store']['weebly']['cartTitle'] = "Puissant constructeur de sites Web";
$_LANG['store']['weebly']['cartShortDescription'] = "Ajoutez le générateur de sites Web de Weebly par glisser-déposer à votre hébergement pour vous permettre de créer un site Web, un magasin ou un blog impressionnant.";

$_LANG['store']['spamexperts']['cartTitle'] = "Sécurité pour courriel SpamExperts";
$_LANG['store']['spamexperts']['cartShortDescription'] = "Ajoutez une sécurité de messagerie professionnelle et un archivage à votre domaine pour protéger et sécuriser votre messagerie contre les attaques et les logiciels malveillants.";

$_LANG['store']['sitelock']['cartTitle'] = "Sécurité pour site Web SiteLock";

$_LANG['store']['symantec']['promo']['sidebar']['title'] = "Ajouter un SSL à votre site web";
$_LANG['store']['symantec']['promo']['sidebar']['body'] = "Activez l'icône cadenas et protégez la vie privée de vos utilisateurs";

$_LANG['store']['weebly']['promo']['sidebar']['title'] = "Puissant constructeur de sites";
$_LANG['store']['weebly']['promo']['sidebar']['body'] = "Créez un site Web magnifique plus rapidement que jamais avec Weebly";

$_LANG['store']['spamexperts']['promo']['sidebar']['title'] = "Obtenez une protection anti-spam";
$_LANG['store']['spamexperts']['promo']['sidebar']['body'] = "Arrêtez le spam grâce au filtrage de spam professionnel";

$_LANG['store']['sitelock']['promo']['sidebar']['title'] = "Protection Maliciels";
$_LANG['store']['sitelock']['promo']['sidebar']['body'] = "Rechercher automatiquement les logiciels malveillants et protéger votre réputation en ligne";

$_LANG['store']['recommendedForYou'] = "Recommandé pour vous";
$_LANG['store']['lastChance'] = "Dernière chance";

$_LANG['domains']['importantReminder'] = "Rappel important";
$_LANG['domains']['irtpNotice'] = "Les modifications que vous avez effectuées activeront le verrouillage de transfert IRTP pour ce domaine.";
$_LANG['domains']['optOut'] = "Désactivation du verrouillage de transfert (si disponible)";
$_LANG['domains']['optOutReason'] = "Raison de l'exclusion (facultatif)";
$_LANG['domains']['contactChangePending'] = "Changement du contact en attente";
$_LANG['domains']['verificationRequired'] = "Verification requise";
$_LANG['domains']['contactsChanged'] = "Une demande de modification des informations WHOIS a déclenché le processus de vérification des contacts. Un courriel a été envoyé au propriétaire du domaine enregistré pour approuver les modifications.";
$_LANG['domains']['contactsChangedDate'] = "Une demande de modification des informations WHOIS a déclenché le processus de vérification des contacts. Un courriel a été envoyé au propriétaire du domaine enregistré pour approuver les modifications. Cette action doit être complétée avant le :date.";
$_LANG['domains']['newRegistration'] = "Un courriel a été envoyé au propriétaire du domaine enregistré. La vérification doit être complétée pour éviter la suspension.";
$_LANG['domains']['newRegistrationDate'] = "Un courriel a été envoyé au propriétaire du domaine enregistré. La vérification doit être complétée avant le :date pour éviter la suspension.";
$_LANG['domains']['irtpLockEnabled'] = "Verrouillage de transfert IRTP activé";
$_LANG['domains']['irtpLockDescription'] = "Ce domaine est actuellement bloqué pour un transfert en raison d'un changement de contact ou d'une nouvelle inscription.";
$_LANG['domains']['irtpLockDescriptionDate'] = "Ce domaine est actuellement bloqué pour un transfert en raison d'un changement de contact ou d'une nouvelle inscription. Le bloquage expirera le :date.";
$_LANG['domains']['resendNotification'] = "Renvoyer le courriel de vérification";
$_LANG['domains']['resendNotificationQuestion'] = "Êtes-vous sûr de vouloir renvoyer le courriel?";
$_LANG['domains']['resendNotificationSuccess'] = "Le courriel de vérification a été renvoyé.";
$_LANG['domains']['modifyPending'] = "Verification requise";
$_LANG['domains']['changePending'] = "Votre demande de modification a déclenché le processus de vérification des contacts. Un courriel de vérification de propriété a été envoyé à :email. Cliquez sur le lien dans le courriel pour appliquer les changements.";
$_LANG['domains']['changePendingDate'] = "Votre demande de modification a déclenché le processus de vérification des contacts. Un courriel de vérification de propriété a été envoyé à :email. Cliquez sur le lien dans le courriel d'ici :days jours pour appliquer les changements.";
$_LANG['domains']['changePendingFormRequired'] = "Votre changement des informations de contact du titulaire a été soumis avec succès. Pour mener à bien ce processus, vous devez remplir le formulaire <strong>Changement du titulaire</strong>. S'il vous plaît visitez :form, remplissez le formulaire en suivant les instructions et nous le renvoyer pour finaliser le processus.";

$_LANG['getStartedNow'] = "Commencez maintenant";
$_LANG['notificationsnew'] = "NOUVEAU";

$_LANG['store']['websiteBuilder']['tab']['overview'] = "Vue d'ensemble";
$_LANG['store']['websiteBuilder']['tab']['features'] = "Caractéristiques";
$_LANG['store']['websiteBuilder']['tab']['pricing'] = "Prix";
$_LANG['store']['websiteBuilder']['tab']['faq'] = "FAQ";
$_LANG['store']['websiteBuilder']['ddEditor'] = "Constructeur glisser & déposer";
$_LANG['store']['websiteBuilder']['ddEditorDescription'] = "Le constructeur glisser-déposer facile vous permet de créer un site Web professionnel sans aucune compétence technique préalable. Choisissez différents éléments pour ajouter des photos, des cartes ou des vidéos en les faisant simplement glisser et en les déposant directement dans votre navigateur Web.";
$_LANG['store']['websiteBuilder']['features']['builder'] = "Constructeur";
$_LANG['store']['websiteBuilder']['features']['builderDescription'] = "Créez le site Web parfait avec de puissants outils de glisser-déposer";
$_LANG['store']['websiteBuilder']['features']['ecommerce'] = "Commerce Électronique";
$_LANG['store']['websiteBuilder']['features']['ecommerceDescription'] = "Solution complète de commerce électronique pour développer votre activité en ligne";
$_LANG['store']['websiteBuilder']['features']['forms'] = "Formulaires";
$_LANG['store']['websiteBuilder']['features']['formsDescription'] = "Créer des formulaires de contact personnalisés, des listes de réponses et des sondages";
$_LANG['store']['websiteBuilder']['features']['templates'] = "Modèles";
$_LANG['store']['websiteBuilder']['features']['templatesDescription'] = "Modèles de sites Web conçus par des professionnels avec une personnalisation complète";
$_LANG['store']['websiteBuilder']['features']['gallery'] = "Photos";
$_LANG['store']['websiteBuilder']['features']['galleryDescription'] = "Créer des galeries, des diaporamas et des arrière-plans personnalisés";
$_LANG['store']['websiteBuilder']['features']['blogging'] = "Blogue";
$_LANG['store']['websiteBuilder']['features']['bloggingDescription'] = "Faites un blogue incroyable en quelques minutes";
$_LANG['store']['websiteBuilder']['features']['video'] = "Vidéo";
$_LANG['store']['websiteBuilder']['features']['videoDescription'] = "Intégrez une vidéo provenant de services populaires ou hébergez vos propres vidéos";
$_LANG['store']['websiteBuilder']['features']['seo'] = "Référencement";
$_LANG['store']['websiteBuilder']['features']['seoDescription'] = "De puissants outils de référencement pour aider les moteurs de recherche à vous trouver";
$_LANG['store']['websiteBuilder']['pricing']['free']['headline'] = "Essayez Weebly";
$_LANG['store']['websiteBuilder']['pricing']['free']['tagline'] = "Tout ce dont vous avez besoin pour créer un site Web";
$_LANG['store']['websiteBuilder']['pricing']['idealFor'] = "Idéal pour :for";
$_LANG['store']['websiteBuilder']['pricing']['siteFeatures'] = "Caractéristiques du site";
$_LANG['store']['websiteBuilder']['pricing']['eCommerceFeatures'] = "Caractéristiques du commerce électronique";
$_LANG['store']['websiteBuilder']['pricing']['features']['ddBuilder'] = "Constructeur glisser & déposer";
$_LANG['store']['websiteBuilder']['pricing']['features']['pages'] = "Pages illimitées";
$_LANG['store']['websiteBuilder']['pricing']['features']['noAds'] = "Pas d'annonces Weebly";
$_LANG['store']['websiteBuilder']['pricing']['features']['search'] = "Recherche dans le site";
$_LANG['store']['websiteBuilder']['pricing']['features']['passwords'] = "Mot de passe de protection";
$_LANG['store']['websiteBuilder']['pricing']['features']['backgrounds'] = "Arrière-plans vidéo";
$_LANG['store']['websiteBuilder']['pricing']['features']['hdVideo'] = "Vidéo HD et audio";
$_LANG['store']['websiteBuilder']['pricing']['features']['memberCount'] = "Jusqu'à 100 membres";
$_LANG['store']['websiteBuilder']['pricing']['features']['registration'] = "Inscription des membres";
$_LANG['store']['websiteBuilder']['pricing']['features']['emailCampaigns'] = "Campagnes courriel";
$_LANG['store']['websiteBuilder']['pricing']['features']['3pcFee'] = "Frais de transaction Weebly de 3%";
$_LANG['store']['websiteBuilder']['pricing']['features']['tenProducts'] = "Jusqu'à 10 produits";
$_LANG['store']['websiteBuilder']['pricing']['features']['checkoutOnWeebly'] = "Commander sur Weebly.com";
$_LANG['store']['websiteBuilder']['pricing']['features']['twentyFiveProducts'] = "Jusqu'à 25 produits";
$_LANG['store']['websiteBuilder']['pricing']['features']['0pcFee'] = "Frais de transaction Weebly de 0%";
$_LANG['store']['websiteBuilder']['pricing']['features']['unlimitedProducts'] = "Produits illimités";
$_LANG['store']['websiteBuilder']['pricing']['features']['checkoutDomain'] = "Commander sur votre domaine";
$_LANG['store']['websiteBuilder']['pricing']['features']['inventory'] = "Gestion de l'inventaire";
$_LANG['store']['websiteBuilder']['pricing']['features']['coupons'] = "Coupons";
$_LANG['store']['websiteBuilder']['pricing']['features']['tax'] = "Calculateur de taxe";
$_LANG['store']['websiteBuilder']['pricing']['features']['shipping'] = "Taux d'expédition en temps réel";
$_LANG['store']['websiteBuilder']['pricing']['features']['abandonedCart'] = "Courriel pour panier d'achat abandonné";
$_LANG['store']['websiteBuilder']['pricing']['features']['giftCards'] = "Cartes cadeaux";
$_LANG['store']['websiteBuilder']['adminPreview'] = "Les plans Weebly que vous activez seront affichés ici";
$_LANG['store']['websiteBuilder']['faq']['title'] = "Questions fréquemment posées";
$_LANG['store']['websiteBuilder']['faq']['q1'] = "Puis-je créer un blog?";
$_LANG['store']['websiteBuilder']['faq']['q2'] = "Mon site sera-t-il compatible avec les mobiles?";
$_LANG['store']['websiteBuilder']['faq']['q3'] = "Puis-je ajouter des photos sur mon site Web?";
$_LANG['store']['websiteBuilder']['faq']['q4'] = "Puis-je vendre des produits sur mon site?";
$_LANG['store']['websiteBuilder']['faq']['q5'] = "Puis-je ajouter des formulaires à mon site?";
$_LANG['store']['websiteBuilder']['faq']['q6'] = "Comment puis-je importer mon site dans les moteurs de recherche?";
$_LANG['store']['websiteBuilder']['faq']['q7'] = "Y a-t-il plusieurs styles à choisir?";
$_LANG['store']['websiteBuilder']['faq']['q8'] = "Puis-je mettre à jour?";
$_LANG['store']['websiteBuilder']['faq']['a1'] = "Oui, le constructeur de site Web vous permet d'inclure la fonctionnalité de blog.";
$_LANG['store']['websiteBuilder']['faq']['a2'] = "Oui, tous les sites Web créés avec le générateur de sites Weebly sont optimisés pour les mobiles.";
$_LANG['store']['websiteBuilder']['faq']['a3'] = "Oui, vous pouvez ajouter des photos à votre site, mais la vidéo HD et l'audio ne sont disponibles que sur les plans Pro & Business.";
$_LANG['store']['websiteBuilder']['faq']['a4'] = "Oui, la fonctionnalité de commerce électronique est incluse dans tous les plans, mais le nombre de produits que vous pouvez offrir varie.";
$_LANG['store']['websiteBuilder']['faq']['a5'] = "Oui, le constructeur du site Weebly facilite la création de formulaires de contact, de listes de réponse, de sondages, etc.";
$_LANG['store']['websiteBuilder']['faq']['a6'] = "Tous les sites Web alimentés par Weebly incluent de puissants outils de référencement pour optimiser votre classement dans les moteurs de recherche.";
$_LANG['store']['websiteBuilder']['faq']['a7'] = "Oui, vous avez le choix entre plusieurs modèles prédéfinis.";
$_LANG['store']['websiteBuilder']['faq']['a8'] = "Oui, vous pouvez mettre à jour à tout moment. Connectez-vous simplement à votre compte et choisissez l'option de mise à niveau.";
$_LANG['store']['websiteBuilder']['trust'] = "Reconnu par plus de 40 millions de personnes dans le monde entier";
$_LANG['store']['websiteBuilder']['upgrade']['title'] = "Mise à niveau Weebly";
$_LANG['store']['websiteBuilder']['upgrade']['required'] = "Mise à niveau requise";
$_LANG['store']['websiteBuilder']['upgrade']['requiredDescription'] = "Pour accéder aux fonctionnalités que vous avez demandées, vous devez mettre à niveau votre plan de constructeur de sites Weebly.";
$_LANG['store']['websiteBuilder']['upgrade']['recommended'] = "Le plan recommandé est affiché.";
$_LANG['store']['websiteBuilder']['upgrade']['login'] = "Pour afficher les options disponibles, veuillez vous connecter.";
$_LANG['store']['websiteBuilder']['upgrade']['no'] = "Aucune mise à niveau disponible";
$_LANG['store']['websiteBuilder']['upgrade']['noUpgrade'] = "Il n'y a pas de mise à niveau disponible pour le moment.";
$_LANG['store']['websiteBuilder']['upgrade']['submitTicket'] = "Contactez l'assistance technique";
$_LANG['store']['websiteBuilder']['upgrade']['to'] = "Mise à niveau vers :product pour :amount";
$_LANG['store']['websiteBuilder']['upgrade']['noPlans'] = "Aucun plan Weebly actif trouvé";
$_LANG['store']['websiteBuilder']['upgrade']['loggedInAs'] = "Vous êtes actuellement connecté en tant que :email";
$_LANG['store']['websiteBuilder']['upgrade']['switchUser'] = "Déconnexion / changement d'utilisateur";

$_LANG['tax']['taxLabel'] = "Numéros de taxes";
$_LANG['tax']['vatLabel'] = "Numéro TVA";
$_LANG['tax']['errorInvalid'] = "Le numéro :taxLabel n'est pas valide";
$_LANG['tax']['errorService'] = "The :taxLabel verification service is not available. Try again later.";

$_LANG['fraud']['checkConfiguration'] = "Une erreur s'est produite lors de la vérification pour fraude. S'il vous plaît contacter l'assistance technique.";
$_LANG['fraud']['title'] = "Contrôle de fraude";
$_LANG['fraud']['error'] = "Erreur";
$_LANG['fraud']['manualReview'] = "Votre commande a été retenue pour vérification manuelle.<br /><br />Si vous croyez avoir reçu ce message par erreur, veuillez accepter nos excuses et soumettre un <a href=\"submitticket.php\">ticket d'assistance technique</a> à notre équipe du service clientèle. Merci.";
$_LANG['fraud']['highFraudRiskScore'] = "Votre commande a été signalée comme présentant un risque potentiellement élevé et a donc été retenue pour vérification manuelle.<br /><br />Si vous croyez avoir reu ce message par erreur, veuillez accepter nos excuses et soumettre un <a href=\"submitticket.php\">ticket d'assistance technique</a> à notre équipe du service clientèle. Merci.";
$_LANG['fraud']['countryMismatch'] = "Le pays de votre adresse IP ne correspond pas à celui de l'adresse de facturation que vous avez entré. Nous ne pouvons donc pas accepter votre commande.";
$_LANG['fraud']['highRiskCountry'] = "Malheureusement, nous ne sommes pas en mesure d'accepter votre commande car de nombreuses activités frauduleuses ont eu lieu dans votre pays. Si vous souhaitez organiser un autre moyen de paiement, veuillez nous contacter.";
$_LANG['fraud']['anonymousProxy'] = "Nous n'autorisons pas les commandes passées via un proxy anonyme.";

$_LANG['fraud']['userVerification'] = "Vérification utilisateur";
$_LANG['fraud']['furtherVal'] = "De plus amples vérifications sont nécessaires pour traiter votre commande. Cliquez le bouton et suivez les indications pour le processus de soumission sécurisée. Vous aurez terminé dans moins d'une minute.";
$_LANG['fraud']['furtherValShort'] = "De plus amples vérifications sont nécessaires. Cliquez le bouton et suivez les indications.";
$_LANG['fraud']['submitDocs'] = "Soumettre les documents";
$_LANG['fraud']['submitSuccessMsg'] = "Merci! Les documents ont été fourni et vont être manuellement contrôlé par notre équipe.";
$_LANG['fraud']['status']['notRequested'] = "Non requis";
$_LANG['fraud']['status']['notReviewed'] = "Demandé";
$_LANG['fraud']['status']['reviewRequested'] = "Soumis";
$_LANG['fraud']['status']['failed'] = "Echec";
$_LANG['fraud']['status']['validated'] = "Validé";

$_LANG['navMarketConnectService']['codeguard'] = "Sauvegarde de site Web";
$_LANG['store']['codeguard']['cartTitle'] = "Sauvegarde CodeGuard";
$_LANG['store']['codeguard']['cartShortDescription'] = "Le service de sauvegarde de site Web le plus rapide et le plus fiable, qui suit quotidiennement toutes vos modifications.";
$_LANG['store']['codeGuard']['title'] = "Sauvegarde CodeGuard";
$_LANG['store']['codeGuard']['headline'] = "Protégez <span>votre site Web</span> avec des sauvegardes automatisées quotidiennes";
$_LANG['store']['codeGuard']['tagline'] = "Protégez-vous contre les virus, les pirates informatiques et même votre propre code qui pourrait détruire accidentellement votre site. Utilisez les sauvegardes de site Web CodeGuard.";
$_LANG['store']['codeGuard']['tab']['overview'] = "Vue d'ensemble";
$_LANG['store']['codeGuard']['tab']['pricing'] = "Prix";
$_LANG['store']['codeGuard']['tab']['features'] = "Caractéristiques";
$_LANG['store']['codeGuard']['tab']['faq'] = "FAQ";
$_LANG['store']['codeGuard']['leadTitle'] = "<strong><em>Toutes les 0.65 secondes</em></strong>, une nouvelle page Web est infectée par un logiciel malveillant.";
$_LANG['store']['codeGuard']['leadText1'] = "Protégez votre site contre les <strong>pertes de données et la corruption</strong>, ainsi que contre les menaces provenant des <strong>virus, pirates informatiques et logiciels malveillants</strong>, grâce aux sauvegardes quotidiennes automatisées de sites Web de CodeGuard.";
$_LANG['store']['codeGuard']['leadText2'] = "Avec les sauvegardes de site Web CodeGuard, votre site Web est sauvegardé tous les jours et en cas de sinistre, vous pouvez restaurer votre site à un point antérieur dans le temps en un clic de souris.";
$_LANG['store']['codeGuard']['dailyBackup'] = "Sauvegardes quotidiennes automatiques";
$_LANG['store']['codeGuard']['malwareProtection'] = "Détection de programmes malveillants et restauration";
$_LANG['store']['codeGuard']['timeMachine'] = "Espace temporel de site Web";
$_LANG['store']['codeGuard']['wpPlugin'] = "Mises à jour des plugins WordPress";
$_LANG['store']['codeGuard']['changeAlerts'] = "Surveillance et alertes de changement de fichier";
$_LANG['store']['codeGuard']['features']['dailyBackup'] = "Sauvegardes automatiques quotidiennes du site";
$_LANG['store']['codeGuard']['features']['dailyBackupDescription'] = "Sécurisez votre site Web avec des sauvegardes quotidiennes automatisées stockées hors site avec une redondance intégrée.";
$_LANG['store']['codeGuard']['features']['unlimitedFiles'] = "Fichiers et bases de données illimités";
$_LANG['store']['codeGuard']['features']['unlimitedFilesDescription'] = "Sauvegardez un nombre illimité de fichiers et de bases de données - vous n'êtes limité que par l'espace de stockage que vous utilisez.";
$_LANG['store']['codeGuard']['features']['oneClickRestore'] = "Restaurations en un clic";
$_LANG['store']['codeGuard']['features']['oneClickRestoreDescription'] = "Un processus de restauration simple facilite la restauration d'un fichier unique ou de l'ensemble de votre site Web vers une version précédente.";
$_LANG['store']['codeGuard']['features']['malwareMonitoring'] = "Surveillance des programmes malveillants";
$_LANG['store']['codeGuard']['features']['malwareMonitoringDescription'] = "Restez tranquille en sachant que CodeGuard vérifie chaque jour votre site pour y détecter des modifications.";
$_LANG['store']['codeGuard']['features']['wp'] = "Mises à jour automatiques de WordPress";
$_LANG['store']['codeGuard']['features']['wpDescription'] = "Mettez automatiquement à jour WordPress et ses extensions pour le garder en sécurité avec la récupération automatique en cas de problème.";
$_LANG['store']['codeGuard']['features']['fileMonitoring'] = "Surveillance des modifications de fichiers";
$_LANG['store']['codeGuard']['features']['fileMonitoringDescription'] = "Recevez une notification par courriel chaque fois que quelque chose change dans le code source de votre site.";
$_LANG['store']['codeGuard']['features']['servers'] = "Préparation des restaurations";
$_LANG['store']['codeGuard']['features']['serversDescription'] = "Testez rapidement tout site sauvegardé avec un transfert simple et automatisé avant la restauration.";
$_LANG['store']['codeGuard']['features']['email'] = "Sauvegarde courriel";
$_LANG['store']['codeGuard']['features']['emailDescription'] = "Protégez également vos courriel, puisqu'ils sont sauvegardés dans les fichiers de votre site Web.";
$_LANG['store']['codeGuard']['features']['api'] = "Automatisation complète";
$_LANG['store']['codeGuard']['features']['apiDescription'] = "Une configuration entièrement mains libres et des sauvegardes continues avec notifications automatiques en cas de problème.";
$_LANG['store']['codeGuard']['chooseBackupPlan'] = "Choisissez l'espace de stockage pour sauvegarde";
$_LANG['store']['codeGuard']['faq']['title'] = "Questions fréquemment posées";
$_LANG['store']['codeGuard']['faq']['q1'] = "Qu'est-ce que CodeGuard?";
$_LANG['store']['codeGuard']['faq']['a1'] = "CodeGuard est un service de sauvegarde de site Web entièrement automatisé qui vous offre une protection complète contre la perte de données et les logiciels malveillants.";
$_LANG['store']['codeGuard']['faq']['q2'] = "Pourquoi ai-je besoin de CodeGuard?";
$_LANG['store']['codeGuard']['faq']['a2'] = "CodeGuard fournit une solution de sauvegarde indépendante hors site pour votre site Web ainsi qu'une surveillance quotidienne pour vous assurer que votre site Web est exempt de logiciels malveillants et est en ligne.";
$_LANG['store']['codeGuard']['faq']['q3'] = "Comment ça marche?";
$_LANG['store']['codeGuard']['faq']['a3'] = "CodeGuard prend quotidiennement des clichés instantanés automatisés de votre site Web. À l'aide de ces clichés instantanés, vous pouvez restaurer votre site entier ou un fichier spécifique vers une version antérieure à tout moment.";
$_LANG['store']['codeGuard']['faq']['q4'] = "Et si je manque d'espace de stockage?";
$_LANG['store']['codeGuard']['faq']['a4'] = "Changer de plan est facile! Vous pouvez mettre à niveau et augmenter votre capacité de stockage sur disque en seulement quelques clics via notre espace client.";
$_LANG['store']['codeGuard']['faq']['q5'] = "Où sont stockées les sauvegardes?";
$_LANG['store']['codeGuard']['faq']['a5'] = "Les sauvegardes sont stockées sur le système de stockage Amazon S3, qui offre une résilience et une redondance de pointe pour vos sauvegardes.";
$_LANG['store']['codeGuard']['faq']['q6'] = "Les sauvegardes sont-elles cryptées?";
$_LANG['store']['codeGuard']['faq']['a6'] = "Oui, les sauvegardes stockées sont cryptées à l'aide de la norme de cryptage AES-256.";
$_LANG['store']['codeGuard']['faq']['q7'] = "Est-ce que vous sauvegardez des bases de données?";
$_LANG['store']['codeGuard']['faq']['a7'] = "Oui, les bases de données peuvent également être sauvegardées. Les sauvegardes de bases de données sont prises en charge pour les bases de données MySQL et MSSQL.";
$_LANG['store']['codeGuard']['faq']['q8'] = "Qu'est-ce que la surveillance des alertes de changement de fichier?";
$_LANG['store']['codeGuard']['faq']['a8'] = "CodeGuard peut surveiller et vous avertir par courrier électronique de nouvelles menaces et de nouveaux logiciels malveillants lorsque votre site Web est modifié.";
$_LANG['store']['codeGuard']['faq']['q9'] = "Que se passe-t-il si mon site est infecté?";
$_LANG['store']['codeGuard']['faq']['a9'] = "Avec les clichés instantanés quotidiens de CodeGuard, si votre site Web est attaqué, vous pouvez restaurer une version précédente non infectée à tout moment.";
$_LANG['store']['codeGuard']['adminPreview'] = "Les plans CodeGuard que vous activez seront affichés ici";

$_LANG['store']['codeguard']['promo']['sidebar']['title'] = "Ajouter la sauvegarde de site Web";
$_LANG['store']['codeguard']['promo']['sidebar']['body'] = "Protégez votre site Web avec des sauvegardes automatisées quotidiennes";

$_LANG['marketConnect']['codeGuard']['manage'] = "Connexion au panneau de configuration de CodeGuard";

$_LANG['sslState']['sslInactive'] = "Aucun SSL détecté. Cliquez ici pour parcourir les options SSL";
$_LANG['sslState']['sslActive'] = "SSL valide détecté. Expire le :expiry";
$_LANG['sslState']['sslUnknown'] = "Impossible de valider le statut SSL";
$_LANG['sslState']['validSsl'] = "SSL valide détecté";
$_LANG['sslState']['noSsl'] = "Aucun SSL détecté";
$_LANG['sslState']['sslInactiveService'] = "Service inactif";
$_LANG['sslState']['sslInactiveDomain'] = "Domaine inactif";
$_LANG['sslState']['startDate'] = "Date de début SSL";
$_LANG['sslState']['expiryDate'] = "Date d'expiration SSL";
$_LANG['sslState']['issuerName'] = "Nom de l'émetteur SSL";
$_LANG['sslState']['sslStatus'] = "Statut SSL";

$_LANG['generatePassword']['btnLabel'] = "Générer un mot de passe";
$_LANG['generatePassword']['btnShort'] = "Générer";
$_LANG['generatePassword']['title'] = "Générer un mot de passe";
$_LANG['generatePassword']['lengthValidationError'] = "Veuillez entrer un nombre entre 8 et 64 pour la longueur du mot de passe";
$_LANG['generatePassword']['pwLength'] = "Longueur du mot de passe";
$_LANG['generatePassword']['generatedPw'] = "Mot de passe généré";
$_LANG['generatePassword']['generateNew'] = "Générer un nouveau mot de passe";
$_LANG['generatePassword']['copyAndInsert'] = "Copier dans le presse-papiers et insérer";

$_LANG['setupMandate'] = "Configurer le mandat de paiement";

$_LANG['invoicePaymentPendingCleared'] = "Votre paiement est en cours de traitement et s'appliquera automatiquement une fois traité.";
$_LANG['invoicePaymentAutoWhenDue'] = "Votre paiement vous sera demandé automatiquement à l'échéance.";

$_LANG['support']['attachmentsRemoved'] = "Supprimé en raison de l'inactivité du ticket";
$_LANG['unpaidInvoiceAlert'] = "Vous avez une facture impayée. Payez-la maintenant pour éviter une interruption de service.";
$_LANG['overdueInvoiceAlert'] = "Vous avez une facture impayée.";
$_LANG['payInvoice'] = "Payer la facture";

$_LANG['close'] = "Fermer";
$_LANG['submit'] = "Envoyer";
$_LANG['finish'] = "Terminer";

$_LANG['twofanowenabled'] = "L'authentification à deux facteurs est désormais activée";
$_LANG['twofacurrently'] = "L'authentification à deux facteurs est actuellement";
$_LANG['enabled'] = "Activé";
$_LANG['disabled'] = "Désactivé";

$_LANG['copyrightFooterNotice'] = "Copyright &copy; :year :company. Tous droits réservés.";

$_LANG['paymentMethods']['title'] = "Mode de paiement";
$_LANG['paymentMethods']['intro'] = "Un aperçu de vos mode et paramètres de paiement.";
$_LANG['paymentMethods']['description'] = "Description";
$_LANG['paymentMethods']['cardDescription'] = "Description de la carte";
$_LANG['paymentMethods']['descriptionInput'] = "Entrez un nom pour cette carte";
$_LANG['paymentMethods']['fieldRequired'] = "Ce champ est requis.";
$_LANG['paymentMethods']['close'] = "Fermer";
$_LANG['paymentMethods']['saveChanges'] = "Sauvegarder les modifications";

$_LANG['paymentMethods']['addedSuccess'] = "Mode de paiement ajoutée avec succès";
$_LANG['paymentMethods']['addFailed'] = "Impossible de créer le mode de paiement. Veuillez réessayer.";
$_LANG['paymentMethods']['updateSuccess'] = "Mode de paiement mis à jour avec succès";
$_LANG['paymentMethods']['saveFailed'] = "Impossible de mettre à jour le mode de paiement. Veuillez réessayer.";
$_LANG['paymentMethods']['defaultUpdateSuccess'] = "Mode de paiement par défaut mis à jour avec succès";
$_LANG['paymentMethods']['defaultUpdateFailed'] = "Impossible de mettre à jour le mode de paiement par défaut. Veuillez réessayer.";
$_LANG['paymentMethods']['deleteSuccess'] = "Mode de paiement supprimé avec succès";
$_LANG['paymentMethods']['deleteFailed'] = "Impossible de supprimer le mode de paiement. Veuillez réessayer.";
$_LANG['paymentMethods']['addNewCC'] = "Ajouter une nouvelle carte de crédit";
$_LANG['paymentMethods']['addNewBank'] = "Ajouter un nouveau compte bancaire";
$_LANG['paymentMethods']['name'] = "Nom";
$_LANG['paymentMethods']['status'] = "Statut";
$_LANG['paymentMethods']['actions'] = "Actions";
$_LANG['paymentMethods']['default'] = "Par défaut";
$_LANG['paymentMethods']['setAsDefault'] = "Définir par défaut";
$_LANG['paymentMethods']['edit'] = "Modifier";
$_LANG['paymentMethods']['delete'] = "Supprimer";
$_LANG['paymentMethods']['noPaymentMethodsCreated'] = "Aucun moyen de paiement n'a encore été créé";
$_LANG['paymentMethods']['areYouSure'] = "Êtes-vous sûr?";
$_LANG['paymentMethods']['deletePaymentMethodConfirm'] = "Voulez-vous vraiment supprimer ce mode de paiement? Cette action ne peut pas être annulée.";
$_LANG['paymentMethods']['type'] = "Type";
$_LANG['paymentMethods']['requestCancelled'] = "Demande de mode de paiement annulée";
$_LANG['paymentMethods']['retry'] = "Réessayez";
$_LANG['paymentMethods']['creditCardChangesWontBeReflected'] = "Les modifications que vous effectuez ici seront enregistrées, mais toutes les modifications ne seront pas reflétées lors de l'affichage du mode de paiement dans notre espace client.";

$_LANG['paymentMethodsManage']['editPaymentMethod'] = "Modifier les modes de paiement";
$_LANG['paymentMethodsManage']['addPaymentMethod'] = "Ajouter une nouveau mode de paiement";
$_LANG['paymentMethodsManage']['invalidCardDetails'] = "Le numéro de carte que vous avez entré semble invalide. Veuillez réessayer.";
$_LANG['paymentMethodsManage']['creditCard'] = "Carte de crédit";
$_LANG['paymentMethodsManage']['bankAccount'] = "Compte bancaire";
$_LANG['paymentMethodsManage']['optional'] = "(Optionnel)";
$_LANG['paymentMethodsManage']['cardNumberNotValid'] = "Le numéro de carte que vous avez entré ne semble pas être valide.";
$_LANG['paymentMethodsManage']['expiryDateNotValid'] = "La date d'expiration que vous avez entrée ne semble pas être valide.";
$_LANG['paymentMethodsManage']['cvcNumberNotValid'] = "Le code CVC que vous avez saisi ne semble pas être valide.";
$_LANG['paymentMethodsManage']['accountType'] = "Type de compte";
$_LANG['paymentMethodsManage']['checking'] = "Chèque";
$_LANG['paymentMethodsManage']['savings'] = "Épargnes";
$_LANG['paymentMethodsManage']['accountHolderName'] = "Nom du titulaire du compte";
$_LANG['paymentMethodsManage']['bankName'] = "Nom de la banque";
$_LANG['paymentMethodsManage']['sortCodeRoutingNumber'] = "Code de tri / Numéro de routage";
$_LANG['paymentMethodsManage']['routingNumberNotValid'] = "Le numéro de routage que vous avez entré ne semble pas être valide.";
$_LANG['paymentMethodsManage']['accountNumber'] = "Numéro de compte";
$_LANG['paymentMethodsManage']['accountNumberNotValid'] = "Le numéro de compte bancaire que vous avez entré ne semble pas être valide.";
$_LANG['paymentMethodsManage']['addNewAddress'] = "Ajouter une nouvelle adresse";
$_LANG['paymentMethodsManage']['addNewBillingAddress'] = "Ajouter une nouvelle adresse de facturation";
$_LANG['paymentMethodsManage']['unsupportedCardType'] = "Nous ne pouvons pas accepter le type de carte que vous avez entré. Veuillez utiliser une autre carte.";

$_LANG['store']['ssl']['shared']['pricing'] = "Prix des certificats";
$_LANG['store']['ssl']['shared']['encryption256'] = "Cryptage 256 bits";
$_LANG['store']['ssl']['shared']['issuanceTime'] = "Délais d'émission";
$_LANG['store']['ssl']['shared']['greatFor'] = "Idéal pour";
$_LANG['store']['ssl']['shared']['warrantyValue'] = "Valeur de garantie";
$_LANG['store']['ssl']['shared']['freeReissues'] = "Rééditions gratuites";
$_LANG['store']['ssl']['shared']['browserSupport'] = "Support du navigateur";
$_LANG['store']['ssl']['shared']['price'] = "Prix";
$_LANG['store']['ssl']['shared']['noProducts'] = "Les produits de certificat SSL que vous activez seront affichés ici";
$_LANG['store']['ssl']['shared']['helpMeChoose'] = "Vous ne savez pas lequel choisir? Laissez-nous vous aider à décider";
$_LANG['store']['ssl']['shared']['ev']['visualVerification'] = "Identité visuelle proéminente";
$_LANG['store']['ssl']['shared']['ev']['visualVerificationDescription'] = "Augmentez la confiance dans votre site Web grâce à une vérification complète de l'identité et des fonctionnalités visuelles importantes.";
$_LANG['store']['ssl']['shared']['ev']['warranty'] = "Garantie de 1,5 M $";
$_LANG['store']['ssl']['shared']['ev']['warrantyDescription'] = "Les certificats EV sont livrés avec une garantie de 1,5 million de dollars qui couvre les violations de données causées par une faille de certificat.";
$_LANG['store']['ssl']['shared']['ev']['issuance'] = "Émis en 2-3 jours";
$_LANG['store']['ssl']['shared']['ov']['ov'] = "Validation de l'organisation";
$_LANG['store']['ssl']['shared']['ov']['ovDescription'] = "Avec un certificat SSL OV, l'identité de la société ou de l'organisation qui détient le certificat est validée, offrant plus de confiance aux utilisateurs finaux.";
$_LANG['store']['ssl']['shared']['ov']['warranty'] = "Garantie de 1,25 M $";
$_LANG['store']['ssl']['shared']['ov']['warrantyDescription'] = "Les certificats OV sont livrés avec une garantie de 1,25 million de dollars qui couvre les violations de données causées par une faille de certificat.";
$_LANG['store']['ssl']['shared']['ov']['issuance'] = "Émis en 1-2 jours";
$_LANG['store']['ssl']['shared']['delivery'] = "Émis en quelques minutes pour une protection instantanée";
$_LANG['store']['ssl']['shared']['deliveryDescription'] = "Le moyen le plus rapide et le plus abordable d'activer la protection SSL pour votre site Web, l'émission est rapide et souvent entièrement automatisée.";
$_LANG['store']['ssl']['shared']['siteSeal'] = "Sceau de confiance du site";
$_LANG['store']['ssl']['shared']['siteSealDescription'] = "Nos certificats SSL sont livrés avec un sceau de confiance qui s'est avéré augmenter la confiance des visiteurs et les conversions de clients.";
$_LANG['store']['ssl']['shared']['googleRanking'] = "Boostez votre classement Google";
$_LANG['store']['ssl']['shared']['googleRankingDescription'] = "Google utilise SSL / HTTPS comme facteur pour déterminer le classement des moteurs de recherche. Ajoutez SSL aujourd'hui pour améliorer votre classement Google!";
$_LANG['store']['ssl']['shared']['features'] = "Caractéristiques du certificat";
$_LANG['store']['ssl']['shared']['encryptData'] = "Chiffrer les données sensibles";
$_LANG['store']['ssl']['shared']['secureTransactions'] = "Sécuriser les transactions en ligne";
$_LANG['store']['ssl']['shared']['legitimacy'] = "Prouver la légitimité";
$_LANG['store']['ssl']['shared']['fastestSsl'] = "SSL le plus fort et le plus rapide";
$_LANG['store']['ssl']['shared']['browserCompatability'] = "Compatibilité du navigateur à 99,9%";
$_LANG['store']['ssl']['shared']['seoRank'] = "Augmentez le classement SEO";
$_LANG['store']['ssl']['shared']['issuance'] = "Émission instantanée";
$_LANG['store']['ssl']['shared']['trusted'] = "Nos certificats SSL proviennent de certaines des marques les plus fiables en matière de sécurité en ligne.";
$_LANG['store']['ssl']['shared']['dvSsl'] = "Validation Domaine (DV)";
$_LANG['store']['ssl']['shared']['ovSsl'] = "Validation Organisation (OV)";
$_LANG['store']['ssl']['shared']['evSsl'] = "Validation Étendue (EV)";
$_LANG['store']['ssl']['shared']['wildcardSsl'] = "Wildcard";
$_LANG['store']['ssl']['shared']['switch'] = "Passez chez nous";
$_LANG['store']['ssl']['competitiveUpgrades']['switch'] = "Passer à DigiCert SSL";
$_LANG['store']['ssl']['competitiveUpgrades']['replace'] = "Remplacez votre certificat SSL actuel sans perdre de temps ni d'argent";
$_LANG['store']['ssl']['competitiveUpgrades']['buyWithTime'] = "Achetez un nouveau certificat SSL chez nous et nous ajouterons tout le temps restant sur votre certificat SSL actuel jusqu'à un maximum de 12 mois supplémentaires";
$_LANG['store']['ssl']['competitiveUpgrades']['foc'] = "sans frais";
$_LANG['store']['ssl']['competitiveUpgrades']['exampleScenario'] = "Exemple de scénario";
$_LANG['store']['ssl']['competitiveUpgrades']['example']['line1'] = "Il vous reste 11 mois sur votre certificat actuel de 2 ans.";
$_LANG['store']['ssl']['competitiveUpgrades']['example']['line2'] = "Vous effectuez le changement et votre nouveau certificat sera valide pour <strong> 1 an ET 11 mois </strong>.";
$_LANG['store']['ssl']['competitiveUpgrades']['example']['line3'] = "Les frais pour le nouveau certificat seront <strong> UNIQUEMENT </strong> pour un an.";
$_LANG['store']['ssl']['competitiveUpgrades']['eligibilityCheck'] = "Cette offre de mise à niveau spéciale est disponible pour les certificats SSL émis par l'un des fournisseurs SSL concurrents pris en charge *. Saisissez votre nom de domaine ci-dessous pour valider votre éligibilité et voir combien vous pourriez économiser.";
$_LANG['store']['ssl']['competitiveUpgrades']['checkFailed'] = "Impossible de se connecter à l'API de validation. Veuillez réessayer plus tard ou contacter le support.";
$_LANG['store']['ssl']['competitiveUpgrades']['eligible'] = "Toutes nos félicitations! Votre domaine est éligible à l'offre de mise à niveau compétitive DigiCert.";
$_LANG['store']['ssl']['competitiveUpgrades']['expirationDate'] = "Date d'expiration actuelle";
$_LANG['store']['ssl']['competitiveUpgrades']['monthsRemaining'] = "Mois restants";
$_LANG['store']['ssl']['competitiveUpgrades']['months'] = ":months Mois";
$_LANG['store']['ssl']['competitiveUpgrades']['maxMonths'] = "Maximum de 12 mois offerts";
$_LANG['store']['ssl']['competitiveUpgrades']['freeExtension'] = "Admissibilité à l'extension gratuite";
$_LANG['store']['ssl']['competitiveUpgrades']['saving'] = "Économies potentielles";
$_LANG['store']['ssl']['competitiveUpgrades']['savingInfomation'] = "Économisez jusqu'à <strong>: saveAmount </strong> sur un nouveau certificat!";
$_LANG['store']['ssl']['competitiveUpgrades']['continue'] = "Continuez à choisir un certificat SSL";
$_LANG['store']['ssl']['competitiveUpgrades']['ineligible'] = "Malheureusement, le domaine que vous avez saisi n'est pas éligible à l'offre de mise à niveau compétitive DigiCert. Veuillez vérifier que le domaine est entré correctement et possède un certificat SSL actif et actuel de l'un des fournisseurs pris en charge";
$_LANG['store']['ssl']['competitiveUpgrades']['validate'] = "Valider";
$_LANG['store']['ssl']['competitiveUpgrades']['competitors'] = "Offre valable pour les certificats SSL Comodo, GlobalSign, Entrust et GoDaddy.";
$_LANG['store']['ssl']['competitiveUpgrades']['enterDomain'] = "Entrez votre domaine ici";
$_LANG['store']['ssl']['useCases']['title'] = "Cas d'utilisation recommandés";
$_LANG['store']['ssl']['useCases']['blogs'] = "Blogs";
$_LANG['store']['ssl']['useCases']['infoPages'] = "Page<br>d'information";
$_LANG['store']['ssl']['useCases']['serverComms'] = "Communication<br>entre serveurs";
$_LANG['store']['ssl']['useCases']['criticalDomains'] = "Domaines <br> critiques pour l'entreprise";
$_LANG['store']['ssl']['useCases']['ecommerce'] = "eCommerce";
$_LANG['store']['ssl']['useCases']['signupPages'] = "Page d'inscription<br>nouveau compte";
$_LANG['store']['ssl']['useCases']['loginPages'] = "Page de connexion";
$_LANG['store']['ssl']['useCases']['intranetSites'] = "Sites intranet";
$_LANG['store']['ssl']['useCases']['webmail'] = "Courriel web";
$_LANG['store']['ssl']['ov']['orgInfo'] = "Contient les détails de votre organisation authentifiée";
$_LANG['store']['ssl']['ov']['orgInfoDescription'] = "Les détails du certificat indiquent que votre site Web utilise un certificat SSL validé par l'organisation et incluent l'autorité de certification émettrice, l'état de validité et la date d'expiration.";
$_LANG['store']['ssl']['ev']['orgInfo'] = "Contient les détails de votre organisation authentifiée EV";
$_LANG['store']['ssl']['ev']['orgInfoDescription'] = "Les détails du certificat indiquent que votre site Web utilise un certificat SSL à validation étendue et incluent l'autorité de certification émettrice, l'état de validité et la date d'expiration.";
$_LANG['store']['ssl']['landingPage']['title'] = "Certificats SSL";
$_LANG['store']['ssl']['landingPage']['tagline1'] = "Sécurisez votre site et ajoutez de la confiance pour vos visiteurs.";
$_LANG['store']['ssl']['landingPage']['tagline2'] = "Avec une gamme de marques, nous avons le bon certificat pour tous les besoins de sécurité de votre site";
$_LANG['store']['ssl']['landingPage']['chooseLevel'] = "Choisissez votre niveau de validation";
$_LANG['store']['ssl']['landingPage']['dv'] = "Validation du domaine (DV)";
$_LANG['store']['ssl']['landingPage']['dvSubtitle'] = "Sécurité de base";
$_LANG['store']['ssl']['landingPage']['dvInformation'] = "Validation de domaine uniquement. Publié en quelques minutes. Idéal pour les blogs, les médias sociaux et les sites Web personnels.";
$_LANG['store']['ssl']['landingPage']['ov'] = "Validation de l'organisation (OV)";
$_LANG['store']['ssl']['landingPage']['ovSubtitle'] = "SSL de niveau professionnel solide";
$_LANG['store']['ssl']['landingPage']['ovInformation'] = "Vérification d'identité de base. Idéal pour les sites Web et les pages de petites entreprises acceptant des informations sensibles.";
$_LANG['store']['ssl']['landingPage']['ev'] = "Validation étendue (EV)";
$_LANG['store']['ssl']['landingPage']['evSubtitle'] = "Protection et confiance maximales";
$_LANG['store']['ssl']['landingPage']['evInformation'] = "Vérification complète de l'identité. Idéal pour les sites commerciaux et de commerce électronique qui cherchent à offrir un maximum de confiance aux visiteurs.";
$_LANG['store']['ssl']['landingPage']['buy'] = "Acheter";
$_LANG['store']['ssl']['landingPage']['what'] = "Qu'est-ce que SSL?";
$_LANG['store']['ssl']['landingPage']['whatInfo'] = "Les certificats SSL sont fondamentaux pour la sécurité Internet. Ils sont utilisés pour établir une connexion cryptée et permettre la transmission sécurisée des données entre un navigateur ou l'ordinateur d'un utilisateur et un serveur ou un site Web.";
$_LANG['store']['ssl']['landingPage']['secureConnection'] = "Établit une connexion sécurisée entre un navigateur et un serveur";
$_LANG['store']['ssl']['landingPage']['encrypts'] = "Crypte la communication pour protéger les informations sensibles fournies";
$_LANG['store']['ssl']['landingPage']['padlock'] = "Place un cadenas à côté de votre adresse Web dans le navigateur";
$_LANG['store']['ssl']['landingPage']['authenticates'] = "Authentifie l'identité d'une organisation";
$_LANG['store']['ssl']['landingPage']['certTypeInfo'] = "Les certificats <a href=\":dvLink\">SSL Standard (Domain Validated)</a> sont le type le plus simple et le plus commun de certificat SSL. Les <a href=\":ovLink\">certificats OV</a> et <a href=\":evLink\">EV</a> identifie également l'identité de la compagnie ou de l'organisation qui détient le certificat fournissant une plus grande confiance aux utilisateurs finaux. <br><br>Avec notre service certificats SSL *, vous n'avez plus besoin d'effectuer des étapes manuelles pour configurer et déployer les certificats chaque année. Nous générons un ordre automatique de renouvellement quand le certificat arrive près de son échéance de validité. Après paiement, nous configurerons, validerons et prosionnerons automatiquement le nouveau certificat pour vous.<br><br><small>* Le domaine doit être hébergé chez le même hébergeur qui vous a vendu le certificat SSL, et le serveur doit utilisé cPanel, Plesk ou DirectAdmin.</small>";
$_LANG['store']['ssl']['landingPage']['benefits']['title'] = "Améliorez votre classement dans les moteurs de recherche";
$_LANG['store']['ssl']['landingPage']['benefits']['subtitle'] = "Instaurez la confiance et la sécurité en ligne pour les visiteurs de votre site Web et votre entreprise.";
$_LANG['store']['ssl']['landingPage']['benefits']['higherResults'] = "Google veut rendre le Web plus sûr et une grande partie de cela implique de s'assurer que les sites auxquels les gens accèdent via Google sont sécurisés. C'est pourquoi il a été démontré que les sites Web utilisant SSL bénéficient d'un meilleur classement dans les résultats de recherche.";
$_LANG['store']['ssl']['landingPage']['benefits']['reasons'] = "Il y a aussi beaucoup plus de raisons pour lesquelles vous devriez envisager d'ajouter SSL à votre site Web";
$_LANG['store']['ssl']['landingPage']['benefits']['encrypt'] = "Chiffrer les données sensibles";
$_LANG['store']['ssl']['landingPage']['benefits']['privacy'] = "Protéger la confidentialité des utilisateurs";
$_LANG['store']['ssl']['landingPage']['benefits']['secure'] = "Transactions en ligne sécurisées";
$_LANG['store']['ssl']['landingPage']['benefits']['https'] = "Activez HTTPS et l'icône de verrouillage";
$_LANG['store']['ssl']['landingPage']['benefits']['legitimacy'] = "Prouver la légitimité";
$_LANG['store']['ssl']['landingPage']['benefits']['seo'] = "Augmentez le classement SEO";
$_LANG['store']['ssl']['landingPage']['browser']['title'] = "Les navigateurs ont changé, ne vous laissez pas distancer";
$_LANG['store']['ssl']['landingPage']['browser']['insecureNotice'] = "Les pages Web non diffusées via HTTPS sont désormais affichées comme «non sécurisées» dans <strong> Google Chrome </strong> et <strong> Mozilla Firefox </strong>. Ne laissez pas votre site Web en faire partie. Ajoutez SSL aujourd'hui.";
$_LANG['store']['ssl']['landingPage']['competitiveUpgrade'] = "Mettez à niveau avec nous et obtenez jusqu'à 12 mois supplémentaires gratuits.";
$_LANG['store']['ssl']['landingPage']['browser']['competitiveUpgrade'] = "Mettez à niveau avec nous et obtenez jusqu'à 12 mois supplémentaires gratuits.";
$_LANG['store']['ssl']['landingPage']['evs']['upgradeTitle'] = "Mise à niveau vers SSL Validation Étendu (EV)";
$_LANG['store']['ssl']['landingPage']['evs']['description'] = "Bien que tous les certificats SSL utilisent des méthodes similaires pour protéger et valider vos données, le niveau de confiance et d'assertion qu'ils fournissent varie.";
$_LANG['store']['ssl']['landingPage']['evs']['whatIs'] = "<strong>Les certificats de validation étendus</strong> offrent le plus haut niveau de validation et de confiance. Ils valident et affichent le nom et l'emplacement des entreprises et des organisations pour donner aux clients une confiance accrue lorsqu'ils traitent avec des entreprises en ligne.";
$_LANG['store']['ssl']['landingPage']['evs']['learn'] = "En savoir plus sur les certificats SSL à validation étendue";
$_LANG['store']['ssl']['landingPage']['help']['title'] = "Aidez-moi à choisir le bon type de certificat";
$_LANG['store']['ssl']['landingPage']['help']['guide'] = "Bien que le besoin de sécurité en ligne soit universel, tous les certificats SSL ne sont pas créés égaux. Le guide ci-dessous est connu pour vous aider à décider quel type de certificat vous convient.";
$_LANG['store']['ssl']['landingPage']['help']['dv']['title'] = "Validation du domaine (DV)";
$_LANG['store']['ssl']['landingPage']['help']['dv']['verify'] = "Vérifie la propriété et le contrôle du nom de domaine uniquement";
$_LANG['store']['ssl']['landingPage']['help']['dv']['issued'] = "Émis en quelques minutes";
$_LANG['store']['ssl']['landingPage']['help']['dv']['compliance'] = "Maintient la conformité du navigateur";
$_LANG['store']['ssl']['landingPage']['help']['dv']['for'] = "Idéal pour les pages Web non critiques";
$_LANG['store']['ssl']['landingPage']['help']['dv']['type'] = "Pensez à DV comme à obtenir une carte de bibliothèque - aucune confirmation de qui vous êtes vraiment, des exigences très minimales à obtenir et délivré très rapidement.";
$_LANG['store']['ssl']['landingPage']['help']['dv']['browse'] = "Parcourir les certificats (DV)";
$_LANG['store']['ssl']['landingPage']['help']['ov']['title'] = "Validation de l'organisation (OV)";
$_LANG['store']['ssl']['landingPage']['help']['ov']['verify'] = "Validation améliorée comprenant l'authentification de l'identité du demandeur";
$_LANG['store']['ssl']['landingPage']['help']['ov']['issued'] = "Émis en un jour";
$_LANG['store']['ssl']['landingPage']['help']['ov']['compliance'] = "Maintient la conformité du navigateur";
$_LANG['store']['ssl']['landingPage']['help']['ov']['for'] = "Idéal pour les pages Web plus sensibles telles que les pages de connexion";
$_LANG['store']['ssl']['landingPage']['help']['ov']['type'] = "Pensez à OV comme obtenir un permis de conduire - plus de cerceaux à sauter qu'une carte de bibliothèque mais plus fiable comme forme d'identification.";
$_LANG['store']['ssl']['landingPage']['help']['ov']['browse'] = "Parcourir les certificats (OV)";
$_LANG['store']['ssl']['landingPage']['help']['ev']['title'] = "Validation étendue (EV)";
$_LANG['store']['ssl']['landingPage']['help']['ev']['verify'] = "Approche normalisée de l'authentification, représentant le plus haut niveau d'authentification pour les certificats SSL";
$_LANG['store']['ssl']['landingPage']['help']['ev']['issued'] = "Généralement délivré dans un délai de 1 à 3 jours";
$_LANG['store']['ssl']['landingPage']['help']['ev']['compliance'] = "Maintient la conformité du navigateur et des autres normes de l'industrie";
$_LANG['store']['ssl']['landingPage']['help']['ev']['for'] = "Idéal pour les pages Web sensibles, y compris le commerce électronique, les services bancaires en ligne, les ouvertures de compte";
$_LANG['store']['ssl']['landingPage']['help']['ev']['type'] = "Pensez à EV comme obtenir un passeport - des processus beaucoup plus rigoureux, des délais plus longs et plus de vérification de qui vous êtes qu'avec une carte de bibliothèque ou un permis de conduire. Reconnu internationalement comme le moyen le plus fiable pour vérifier votre identité.";
$_LANG['store']['ssl']['landingPage']['help']['ev']['browse'] = "Parcourir les certificats (EV)";
$_LANG['store']['ssl']['landingPage']['viewAll'] = "Voir tous les certificats SSL";
$_LANG['store']['ssl']['landingPage']['buyNow'] = "Acheter maintenant";
$_LANG['store']['ssl']['landingPage']['faq']['title'] = "FAQ";
$_LANG['store']['ssl']['landingPage']['faq']['q1'] = "Qu'est-ce qu'un certificat SSL?";
$_LANG['store']['ssl']['landingPage']['faq']['a1'] = "Les certificats SSL permettent le cryptage des données sur Internet et permettent la transmission sécurisée des données d'un serveur Web à un navigateur. Avec SSL, votre site Web peut utiliser le protocole https et affichera un cadenas dans les navigateurs Web des utilisateurs finaux pour indiquer que la connexion est sécurisée.";
$_LANG['store']['ssl']['landingPage']['faq']['q2'] = "Pourquoi ai-je besoin d'un certificat SSL?";
$_LANG['store']['ssl']['landingPage']['faq']['a2'] = "Les certificats SSL sont une partie essentielle d'Internet. Ils chiffrent non seulement la communication entre votre ordinateur et le serveur où se trouve un site Web, mais ils permettent également de vérifier qu'un site est ce qu'il prétend être.";
$_LANG['store']['ssl']['landingPage']['faq']['q3'] = "Quels sont les différents types de SSL?";
$_LANG['store']['ssl']['landingPage']['faq']['a3'] = "Il existe 3 niveaux de contrôle différents sur lesquels les certificats SSL sont basés. Validation du domaine (DV), Validation de l'organisation (OV) et Validation étendue (EV). La principale différence entre les types de certificats concerne les informations que l'autorité de certification, RapidSSL, GeoTrust et DigiCert, requiert et valide pour émettre un certificat. Les niveaux de certificat plus élevés nécessitent plus d'informations et sont souvent affichés dans la barre du navigateur. EV SSL, par exemple, transforme la barre de navigateur en vert et affiche le nom de l'organisation aux visiteurs pour générer plus de confiance.";
$_LANG['store']['ssl']['landingPage']['faq']['q4'] = "Qu'est-ce qu'un certificat SSL Wildcard";
$_LANG['store']['ssl']['landingPage']['faq']['a4'] = "Un certificat SSL Wildcard offre les mêmes fonctionnalités de cryptage et d'authentification que les autres certificats SSL, mais peut également être appliqué à un nombre illimité de sous-domaines d'un site Web. Un certificat SSL Wildcard prend en charge le domaine racine (example.com) ainsi que ses sous-domaines.";
$_LANG['store']['ssl']['landingPage']['faq']['q5'] = "Quels sont les avantages d'un certificat SSL EV?";
$_LANG['store']['ssl']['landingPage']['faq']['a5'] = "EV, ou Validation Étendue, est la plus haute classe de SSL disponible aujourd'hui et donne plus de crédibilité et de confiance à votre site Web que les autres certificats SSL. Ils incluent des fonctionnalités telles que la barre d'adresse verte et l'affichage du nom de votre entreprise qui ont fait leurs preuves pour renforcer la confiance et la confiance des consommateurs.";
$_LANG['store']['ssl']['landingPage']['faq']['q6'] = "Et si j'ai déjà un certificat SSL?";
$_LANG['store']['ssl']['landingPage']['faq']['a6'] = "Vous pouvez nous contacter à tout moment. Nous offrons des prix très compétitifs et si vous avez déjà un certificat existant, nous ajouterons toute validité restante que vous avez sur votre certificat SSL concurrent existant jusqu'à un maximum de 12 mois supplémentaires.";

$_LANG['creditCardStore'] = "Enregistrer la carte pour un paiement plus rapide à l'avenir";

$_LANG['support']['ccRecipients'] = "Destinataires CC";
$_LANG['support']['addCcRecipients'] = "Entrer l'adresse courriel";
$_LANG['support']['removeRecipient'] = "Supprimer le destinataire";
$_LANG['support']['successDelete'] = "Le destinataire CC :email à été supprimé";
$_LANG['support']['deleteEmailNotExisting'] = "Le courriel :email n'est pas un destinataire CC";
$_LANG['support']['addEmailExists'] = "Le courriel :email est déjà un destinataire CC";
$_LANG['support']['successAdd'] = "Le destinataire CC :email a été ajouté";
$_LANG['support']['clientEmail'] = "L'adresse courriel du client ne peut pas être ajoutée en tant que destinataire CC";
$_LANG['support']['emailNotPossible'] = "Il n'est pas possible d'ajouter l'adresse courriel :email comme destinataire CC";
$_LANG['support']['invalidEmail'] = "Adresse courriel non valide saisie.";
$_LANG['support']['ipAddress'] = "Adresse IP";
$_LANG['support']['ticketError'] = "We cannot process your ticket request at this time. Please try again later.";

$_LANG['confirmAndPay'] = "Confirmer et payer";
$_LANG['paymentPreApproved'] = "Paiement pré-approuvé avec :gateway";
$_LANG['expressCheckoutInfo'] = "Votre paiement est en attente de confirmation. Cela ne prend généralement que quelques minutes pour terminer les paiements. Si vous ne recevez pas de reçu par courriel dans quelques minutes, veuillez contacter le support.";
$_LANG['expressCheckoutError'] = "Une erreur s'est produite lors du traitement de votre paiement. Veuillez contacter le support.";

$_LANG['subscription']['active'] = "Vous avez un abonnement actif";
$_LANG['subscription']['manual'] = "Vous pouvez toujours effectuer un paiement manuel, mais cela peut entraîner un surpaiement.";
$_LANG['subscription']['moreDetails'] = "Plus de détails";
$_LANG['subscription']['makePayment'] = "Effectuer un paiement";
$_LANG['subscription']['paypalDetails'] = "Détails de l'abonnement PayPal";
$_LANG['subscription']['subscriptionWarning'] = "Tout abonnement actif ci-dessous sera automatiquement appliqué à cette facture. Si un paiement d'abonnement entraîne un trop-payé, vous recevrez un crédit qui sera automatiquement appliqué à votre prochaine facture.";
$_LANG['subscription']['subscriptionid'] = "ID d'abonnement";
$_LANG['subscription']['status'] = "État de l'abonnement";
$_LANG['subscription']['lastpayment'] = "Dernier paiement";
$_LANG['subscription']['nextpaymentdate'] = "Prochaine date de paiement";
$_LANG['subscription']['subscriptionstartdate'] = "Date de début d'abonnement";
$_LANG['subscription']['failedpaymentscount'] = "Nombre de paiements échoués";
$_LANG['subscription']['errorFetchingDetails'] = "Une erreur s'est produite lors de la tentative d'obtention des informations d'abonnement. Veuillez contacter le support.";

$_LANG['navMarketConnectService']['sitelockvpn'] = "VPN";
$_LANG['store']['sitelockvpn']['tagline'] = "Obtenez un accès illimité à un Internet sans soucis de confidentialité, restrictions de contenu ou plafonds de données.";
$_LANG['store']['sitelockvpn']['manageService'] = "Gérez votre service VPN SiteLock";
$_LANG['store']['sitelockvpn']['cartShortDescription'] = "SiteLock VPN permet des sessions de navigation anonymes et cryptées sur n'importe quelle connexion réseau.";
$_LANG['store']['sitelockvpn']['cartTitle'] = "VPN SiteLock";
$_LANG['store']['sitelockvpn']['promo']['sidebar']['title'] = "Réseau privé virtuel (VPN)";
$_LANG['store']['sitelockvpn']['promo']['sidebar']['body'] = "Anonymisez votre navigation";
$_LANG['store']['sitelockvpn']['adminPreview'] = "Les plans VPN SiteLock que vous activez seront affichés ici";

$_LANG['store']['sitelockvpn']['title'] = "VPN SiteLock";
$_LANG['store']['sitelockvpn']['getStarted'] = "Commencer";
$_LANG['store']['sitelockvpn']['subtitle1'] = "Sécuriser et protéger votre";
$_LANG['store']['sitelockvpn']['subtitle2'] = "Navigation sur le Web";
$_LANG['store']['sitelockvpn']['tagline1'] = "Haute vitesse, sécurisé et facile";
$_LANG['store']['sitelockvpn']['tagline2'] = "à utiliser instantanément.";
$_LANG['store']['sitelockvpn']['feature1']['title'] = "Obtenez un accès sécurisé et privé à Internet.";
$_LANG['store']['sitelockvpn']['feature1']['subtitle'] = "<strong> Protégez vos données personnelles </strong> et ayez l'esprit tranquille chaque fois que vous utilisez le Wi-Fi public, accédez à des comptes personnels et professionnels sur la route, ou souhaitez simplement garder votre historique de navigation pour vous.";
$_LANG['store']['sitelockvpn']['feature1']['highlights']['one'] = "Cachez votre adresse IP";
$_LANG['store']['sitelockvpn']['feature1']['highlights']['two'] = "Protégez votre identité en ligne";
$_LANG['store']['sitelockvpn']['feature1']['highlights']['three'] = "Aucun journal d'activité pour suivre la navigation";
$_LANG['store']['sitelockvpn']['feature1']['highlights']['four'] = "Sécurisez vos transactions bancaires";
$_LANG['store']['sitelockvpn']['feature1']['highlights']['five'] = "Utilisez un cryptage de niveau militaire";
$_LANG['store']['sitelockvpn']['feature1']['highlights']['six'] = "Soyez en sécurité sur les réseaux Wi-Fi publics";
$_LANG['store']['sitelockvpn']['feature2']['title'] = "Diffusez et parcourez sans limitations.";
$_LANG['store']['sitelockvpn']['feature2']['subtitle'] = "Du streaming vidéo aux réseaux sociaux, <strong> notre VPN fonctionne partout </strong> et vous permet d'accéder aux sites et applications que vous aimez. Une plus grande vitesse pour une navigation plus agréable, pas de mise en mémoire tampon et plus de longue attente.";
$_LANG['store']['sitelockvpn']['feature2']['highlights']['one'] = "Accéder aux sites Web bloqués";
$_LANG['store']['sitelockvpn']['feature2']['highlights']['two'] = "Regardez des services de streaming partout";
$_LANG['store']['sitelockvpn']['feature2']['highlights']['three'] = "Contournez la censure locale d'Internet";
$_LANG['store']['sitelockvpn']['feature2']['highlights']['four'] = "Jouer à des jeux verrouillés par région";
$_LANG['store']['sitelockvpn']['feature2']['highlights']['five'] = "Obtenez de meilleures offres en ligne";
$_LANG['store']['sitelockvpn']['feature2']['highlights']['six'] = "Restez privé et anonyme";
$_LANG['store']['sitelockvpn']['feature3']['title'] = "Protégez tous vos appareils.";
$_LANG['store']['sitelockvpn']['feature3']['subtitle'] = "<strong> Configuration VPN en 1 clic </strong> pour Mac, Windows, iOS et Android.";
$_LANG['store']['sitelockvpn']['feature3']['subtitle2'] = "Accédez à Internet où que vous soyez à partir d'un ordinateur, d'un smartphone ou d'une tablette. La configuration automatique est prise en charge pour toutes les principales plates-formes <sup> * </sup>, ce qui vous permet de surfer sans restriction, sans codage ni configuration complexe requise. <strong> Téléchargez et connectez-vous simplement. </strong>";
$_LANG['store']['sitelockvpn']['feature3']['subtitle3'] = "* D'autres plateformes peuvent être configurées manuellement.";
$_LANG['store']['sitelockvpn']['pricing']['oneSubscription'] = "Un seul abonnement couvre et protège";
$_LANG['store']['sitelockvpn']['pricing']['fiveDevices'] = "jusqu'à 5 appareils simultanément.";
$_LANG['store']['sitelockvpn']['pricing']['features']['noRestrictions'] = "Pas de restrictions";
$_LANG['store']['sitelockvpn']['pricing']['features']['highSpeed'] = "Réseau haute vitesse";
$_LANG['store']['sitelockvpn']['pricing']['features']['unlimited'] = "Bande passante illimitée";
$_LANG['store']['sitelockvpn']['pricing']['features']['encryption'] = "Cryptage AES 256 bits";
$_LANG['store']['sitelockvpn']['plans']['features']['allInclude'] = "Tous les plans d'abonnement incluent";
$_LANG['store']['sitelockvpn']['plans']['features']['noRestrictions'] = "Pas de restrictions";
$_LANG['store']['sitelockvpn']['plans']['features']['highSpeed'] = "Réseau haute vitesse";
$_LANG['store']['sitelockvpn']['plans']['features']['unlimited'] = "Bande passante illimitée";
$_LANG['store']['sitelockvpn']['plans']['features']['encryption'] = "Cryptage AES 256 bits";
$_LANG['store']['sitelockvpn']['plans']['features']['protocol'] = "OpenVPN, L2TP-IPsec <br> et protocoles PPTP";
$_LANG['store']['sitelockvpn']['plans']['features']['simultaneous'] = "Connexions simultanées sur<br>jusqu'à 5 appareils";
$_LANG['store']['sitelockvpn']['plans']['features']['apps'] = "Applications pour Windows, Mac, iOS, <br> Android et Linux";
$_LANG['store']['sitelockvpn']['plans']['features']['switching'] = "Changement de serveur illimité";
$_LANG['store']['sitelockvpn']['plans']['features']['countries'] = "40+ Pays";
$_LANG['store']['sitelockvpn']['plans']['features']['servers'] = "1000+ Serveurs";
$_LANG['store']['sitelockvpn']['plans']['features']['support'] = "Assistance 24/7 aux États-Unis";
$_LANG['store']['sitelockvpn']['world']['features']['title'] = "Des vitesses incroyablement rapides, une bande passante illimitée";
$_LANG['store']['sitelockvpn']['world']['features']['servers'] = "Serveurs";
$_LANG['store']['sitelockvpn']['world']['features']['countries'] = "Pays";
$_LANG['store']['sitelockvpn']['world']['features']['unlimited'] = "Illimité";
$_LANG['store']['sitelockvpn']['world']['features']['bandwidth'] = "Bande passante";

$_LANG['store']['noDomain'] = "Aucun domaine requis";
$_LANG['store']['noDomainRequired'] = "Aucun domaine n'est requis pour ce produit";
$_LANG['back'] = "Retour";

$_LANG['errors']['badRequest'] = "Mauvaise Demande";
$_LANG['errors']['badRequestTryAgain'] = "Une erreur s'est produite. Veuillez réessayer.";

$_LANG['paymentMethods']['iban'] = "IBAN";
$_LANG['paymentMethods']['mandateAcceptance'] = "En fournissant votre IBAN et en confirmant ce paiement, vous autorisez :companyName et Stripe, notre prestataire de services de paiement, à envoyer des instructions à votre banque pour débiter votre compte conformément à ces instructions. Vous avez droit à un remboursement de votre banque selon les termes et conditions de votre accord avec votre banque. Un remboursement doit être demandé dans les 8 semaines à compter de la date de débit de votre compte.";

$_LANG['metrics']['title'] = "Métrique";
$_LANG['metrics']['explanation'] = "Ce produit a des frais de facturation basés sur l'utilisation en plus du prix de base. Les mesures d'utilisation et leurs informations de tarification sont affichées ci-dessous.";
$_LANG['metrics']['from'] = "Du";
$_LANG['metrics']['to'] = "Au";
$_LANG['metrics']['startingQuantity'] = "Quantité de départ";
$_LANG['metrics']['unit'] = "Unité";
$_LANG['metrics']['pricePerUnit'] = "Prix par unité";
$_LANG['metrics']['pricePer'] = "Prix par";
$_LANG['metrics']['viewPricing'] = "Voir les tarifs";
$_LANG['metrics']['pricing'] = "Tarifs";
$_LANG['metrics']['startingFrom'] = "À partir de";
$_LANG['metrics']['pricingschema']['simple']['info'] = "Cet article a une structure de prix unique";
$_LANG['metrics']['pricingschema']['simple']['detail'] = "Le prix unitaire est constant quel que soit le volume.";
$_LANG['metrics']['pricingschema']['grad']['info'] = "Cet article a une structure de prix graduée.";
$_LANG['metrics']['pricingschema']['grad']['detail'] = "Le prix unitaire est calculé par période de consommation. Le prix total est la somme des calculs de périodes.";
$_LANG['metrics']['pricingschema']['flat']['info'] = "Cet article a une structure de prix à volume fixe.";
$_LANG['metrics']['pricingschema']['flat']['detail'] = "Le prix unitaire est déterminé par le volume total consommé.";
$_LANG['metrics']['previousUsage'] = "Utilisation précédente";
$_LANG['metrics']['currentUsage'] = "Utilisation actuelle";
$_LANG['metrics']['lastUpdated'] = "Dernière mise à jour";
$_LANG['metrics']['metric'] = "Métrique";
$_LANG['metrics']['billing'] = "Facturation";
$_LANG['metrics']['includedNotCounted'] = "Inclus";
$_LANG['metrics']['includedInBase'] = "inclus dans le prix de base";

$_LANG['metrics']['invoiceitem']['perunit'] = ":consumed :metricname @ :price par :perUnitName";
$_LANG['metrics']['invoiceitem']['included'] = ":included :metricname inclus";

$_LANG['bankPaymentDeclined'] = "Les détails du compte bancaire que vous avez saisis ont été refusés. Veuillez essayer un autre compte ou contacter l'assistance.";
$_LANG['invoicePaymentInitiated'] = "Merci! Votre paiement a été lancé avec succès. Vous recevrez un courriel de confirmation une fois le paiement effectué.";
$_LANG['genericPaymentDeclined'] = "Votre paiement a été refusé. Merci de réessayer ou de contacter notre support.";

$_LANG['sitelockvpn']['loginPanelText'] = "Connectez-vous pour configurer et gérer vos informations d'identification d'utilisateur VPN et télécharger les clients VPN.";
$_LANG['store']['save'] = "Économisez :saving%";
$_LANG['marketConnect']['codeGuard']['manageBackup'] = "Gérer les sauvegardes";
$_LANG['store']['chooseExistingDomain'] = "Choisissez un domaine existant";
$_LANG['store']['choosePaymentTerm'] = "Choisissez le terme de paiement";
$_LANG['store']['chooseDomain'] = "Choisissez un domaine";
$_LANG['store']['subOfExisting'] = "Sous-domaine d'un domaine existant";
$_LANG['store']['domainAlreadyOwned'] = "Un domaine que je possède déjà";
$_LANG['store']['eligible'] = "Éligible";
$_LANG['store']['login'] = "Connexion";
$_LANG['store']['addToExistingPackage'] = "pour l'ajouter à un forfait d'hébergement existant.";

$_LANG['marketConnect']['sitelock']['manageSecurity'] = "Gérez votre sécurité";
$_LANG['marketConnect']['sitelock']['ftpHost'] = "Hôte FTP";
$_LANG['marketConnect']['sitelock']['ftpUsername'] = "Utilisateur FTP";
$_LANG['marketConnect']['sitelock']['ftpPassword'] = "Mot de passe FTP";
$_LANG['marketConnect']['sitelock']['ftpPath'] = "Chemin FTP";
$_LANG['marketConnect']['sitelock']['updateFtp'] = "Mettre à jour les informations d'identification FTP";
$_LANG['marketConnect']['sitelock']['manage'] = "Connectez-vous à SiteLock";
$_LANG['marketConnect']['sitelockvpn']['manageVPN'] = "Gérez votre VPN";
$_LANG['marketConnect']['emailServices']['manageEmail'] = "Gérez vos courriels";
$_LANG['marketConnect']['emailServices']['manage'] = "Log in to SpamExperts";
$_LANG['marketConnect']['sitelockvpn']['manage'] = "Log in to SiteLock VPN";
$_LANG['marketConnect']['websiteBuilder']['buildWebsite'] = "Créez votre site Web";

$_LANG['creditCardHolderName'] = "Nom du titulaire";

$_LANG['redirectingToCompleteCheckout'] = "Redirection en cours pour compléter le paiement. Veuillez patienter...";
$_LANG['paypalEmailAddress'] = "Adresse courriel PayPal";

$_LANG['fromJust'] = "à partir de";
$_LANG['forJust'] = "jusqu'à";
$_LANG['remoteTransError'] = "Échec de la transaction à distance. Veuillez contacter le support.";

$_LANG['imageUnavailable'] = "Image non disponible";

$_LANG['emailPreferences']['affiliate'] = "Courriels d'affiliation - Recevoir des notifications d'affiliation";
$_LANG['emailPreferences']['domain'] = "Courriels de domaine - Avis de confirmation d'enregistrement, de transfert et de renouvellement";
$_LANG['emailPreferences']['general'] = "Courriels généraux - Tous les Courriels liés au compte";
$_LANG['emailPreferences']['invoice'] = "Courriels de facturation - Nouvelles factures, rappels et avis de retard";
$_LANG['emailPreferences']['product'] = "Courriels de produits - Courriels de bienvenue, suspensions et autres notifications de cycle de vie";
$_LANG['emailPreferences']['support'] = "Courriels de support - Recevez un CC de toutes les communications de ticket de support";

$_LANG['navMarketConnectService']['marketgoo'] = "Outils SEO";
$_LANG['store']['marketgoo']['title'] = "Outils SEO Marketgoo";
$_LANG['store']['marketgoo']['headline'] = "Améliorez le trafic de votre site";
$_LANG['store']['marketgoo']['tagline'] = "et <em> Développez votre entreprise </em> avec Marketgoo";
$_LANG['store']['marketgoo']['tab']['how'] = "Comment ça marche?";
$_LANG['store']['marketgoo']['tab']['features'] = "Caractéristiques et prix";
$_LANG['store']['marketgoo']['tab']['testimonials'] = "Ce que disent les autres utilisateurs";
$_LANG['store']['marketgoo']['tab']['faqs'] = "FAQ et assistance";
$_LANG['store']['marketgoo']['features']['1'] = "Inscrivez-vous et obtenez un rapport SEO instantané";
$_LANG['store']['marketgoo']['features']['2'] = "Obtenez votre plan de référencement facile";
$_LANG['store']['marketgoo']['features']['3'] = "Suivez les instructions simples étape par étape";
$_LANG['store']['marketgoo']['features']['4'] = "Commencez à vous améliorer";
$_LANG['store']['marketgoo']['featuresdetail']['4'] = "Mettez votre plan de référencement en action (sans avoir besoin d'experts) et obtenez un rapport d'avancement mensuel";
$_LANG['store']['marketgoo']['features']['5'] = "Suivi et surveillance";
$_LANG['store']['marketgoo']['featuresdetail']['5'] = "Découvrez le classement de vos concurrents pour les mots clés sur lesquels vous vous concentrez et suivez la popularité de leur site";
$_LANG['store']['marketgoo']['featurematrix']['1'] = "Soumission des moteurs de recherche";
$_LANG['store']['marketgoo']['featurematrix']['2'] = "Connectez Google Analytics";
$_LANG['store']['marketgoo']['featurematrix']['3'] = "Télécharger le rapport SEO au format PDF";
$_LANG['store']['marketgoo']['featurematrix']['4'] = "Pages numérisées";
$_LANG['store']['marketgoo']['featurematrix']['5'] = "Suivi des concurrents";
$_LANG['store']['marketgoo']['featurematrix']['6'] = "Suivi et optimisation des mots clés";
$_LANG['store']['marketgoo']['featurematrix']['7'] = "Rapport et plan mis à jour";
$_LANG['store']['marketgoo']['featurematrix']['8'] = "Plan de référencement personnalisé";
$_LANG['store']['marketgoo']['featurematrix']['9'] = "Rapport d'avancement mensuel";
$_LANG['store']['marketgoo']['completeStepByStep'] = "<span>Complet</span> avec un guide étape par étape";
$_LANG['store']['marketgoo']['signup'] = "S'inscrire maintenant";
$_LANG['store']['marketgoo']['testimonials']['casestudy'] = "Lire l'étude de cas";
$_LANG['store']['marketgoo']['faqs']['title'] = "FAQ et assistance";
$_LANG['store']['marketgoo']['faqs']['q1'] = "Dois-je choisir Lite ou Pro?";
$_LANG['store']['marketgoo']['faqs']['a1'] = "Voir une comparaison vidéo des plans";
$_LANG['store']['marketgoo']['faqs']['q2'] = "Marketgoo apporte-t-il les modifications recommandées ou dois-je le faire?";
$_LANG['store']['marketgoo']['faqs']['a2'] = "Marketgoo est un outil DIY, alors même si nous vous aidons à analyser votre site et à vous donner des recommandations, ainsi que des tâches et des instructions pour optimiser votre site, nous n'effectuons pas ces changements pour vous.";
$_LANG['store']['marketgoo']['faqs']['q3'] = "Pourquoi ai-je besoin de SEO?";
$_LANG['store']['marketgoo']['faqs']['a3'] = "Vous travaillez sur votre référencement afin d'améliorer le classement de votre site dans les résultats de recherche. Cela conduit à attirer plus de trafic - et idéalement, à convertir ce trafic en clients et en prospects.";
$_LANG['store']['marketgoo']['adminPreview'] = "Les plans Marketgoo que vous activez seront affichés ici";
$_LANG['store']['marketgoo']['labelBestValue'] = "Meilleure offre!";

$_LANG['upTo'] = "Jusqu'à :num";
$_LANG['weekly'] = "Hebdomadaire";
$_LANG['daily'] = "Quotidien";
$_LANG['limited'] = "Limité";

$_LANG['marketConnect']['marketgoo']['manageSEO'] = "Marketgoo SEO";
$_LANG['marketConnect']['marketgoo']['manage'] = "Connexion au tableau de bord";

$_LANG['store']['marketgoo']['cartTitle'] = "Outils Marketgoo SEO";
$_LANG['store']['marketgoo']['cartShortDescription'] = "Améliorez le trafic de votre site et développez votre entreprise avec les outils SEO DIY de Marketgoo.";

$_LANG['store']['marketgoo']['promo']['sidebar']['title'] = "Outils Marketgoo SEO";
$_LANG['store']['marketgoo']['promo']['sidebar']['body'] = "Améliorez le trafic de votre site et développez votre activité";

$_LANG['emailPreferences']['oneRequired'] = "Vous devez avoir au moins une adresse e-mail activée pour recevoir des notifications liées au domaine, comme requis par l'ICANN.";
$_LANG['emailPreferences']['domainContactRequired'] = "Pour désactiver les notifications de domaine, veuillez activer les notifications de domaine pour le titulaire principal du compte ou un autre contact.";
$_LANG['emailPreferences']['domainClientRequired'] = "Pour désactiver les notifications de domaine, veuillez créer un autre contact configuré pour les recevoir.";

$_LANG['twoFactor']['duosecurity']['friendlyName'] = "Sécurité Duo";
$_LANG['twoFactor']['duosecurity']['description'] = "Obtenez des codes via Duo Push, SMS ou rappel téléphonique.";
$_LANG['twoFactor']['totp']['friendlyName'] = "Jetons temporels";
$_LANG['twoFactor']['totp']['description'] = "Obtenez des codes à partir d'une application comme Google Authenticator ou Duo.";
$_LANG['twoFactor']['yubico']['friendlyName'] = "Yubico";
$_LANG['twoFactor']['yubico']['description'] = "Générez des codes à l'aide d'un périphérique matériel YubiKey.";

$_LANG['orderForm']['selectCategory'] = "Veuillez choisir une catégorie dans le menu de la barre latérale";

$_LANG['marketConnect']['ox']['manage'] = "Log in to OX App Suite";

$_LANG['store']['sampleProduct'] = "Ceci est un exemple de produit";
$_LANG['store']['emailServices']['tab']['overview'] = "Aperçu";
$_LANG['store']['emailServices']['tab']['howitworks'] = "Comment ça fonctionne";
$_LANG['store']['emailServices']['tab']['pricing'] = "Tarification";
$_LANG['store']['emailServices']['tab']['faq'] = "FAQ";
$_LANG['store']['emailServices']['incoming']['title'] = "Filtrage des e-mails entrants";
$_LANG['store']['emailServices']['outgoing']['title'] = "Filtrage des e-mails sortants";
$_LANG['store']['emailServices']['archiving']['title'] = "Archivage des e-mails";
$_LANG['store']['emailServices']['overview']['learn'] = "En savoir plus";
$_LANG['store']['emailServices']['overview']['buy'] = "Acheter";
$_LANG['store']['emailServices']['overview']['incoming']['tagline'] = "Protégez votre réseau";
$_LANG['store']['emailServices']['overview']['incoming']['headline'] = "Éliminez le spam et les virus des e-mails avant qu'ils n'atteignent votre réseau";
$_LANG['store']['emailServices']['overview']['outgoing']['tagline'] = "Protégez votre réputation";
$_LANG['store']['emailServices']['overview']['outgoing']['headline'] = "Empêchez le spam et les virus de quitter votre réseau sans le savoir";
$_LANG['store']['emailServices']['overview']['archiving']['tagline'] = "Sauvegarde et conformité";
$_LANG['store']['emailServices']['overview']['archiving']['headline'] = "Ne perdez plus jamais un e-mail et assurez l'intégrité des données de messagerie pour la conformité légale";
$_LANG['store']['emailServices']['benefits']['incoming']['title'] = "Le filtrage des e-mails entrants vous offre tous ces avantages ...";
$_LANG['store']['emailServices']['benefits']['incoming']['1'] = "Protection complète de la boîte de réception à des prix compétitifs";
$_LANG['store']['emailServices']['benefits']['incoming']['2'] = "Filtrage extrêmement précis";
$_LANG['store']['emailServices']['benefits']['incoming']['3'] = "Configuration facile";
$_LANG['store']['emailServices']['benefits']['incoming']['4'] = "Augmentez la continuité et la redondance des e-mails entrants";
$_LANG['store']['emailServices']['benefits']['incoming']['5'] = "Diverses options de rapport";
$_LANG['store']['emailServices']['benefits']['incoming']['6'] = "Interface conviviale pour vous garder un contrôle total sur votre messagerie";
$_LANG['store']['emailServices']['benefits']['incoming']['7'] = "Augmentez la productivité des employés";
$_LANG['store']['emailServices']['benefits']['incoming']['8'] = "Compatible avec n'importe quel serveur de messagerie";
$_LANG['store']['emailServices']['benefits']['incoming']['q1'] = "Pourquoi choisir le filtre entrant SpamExperts?";
$_LANG['store']['emailServices']['benefits']['incoming']['a1'] = "Le filtrage des e-mails entrants filtre tous les e-mails entrants et élimine le spam et les virus avant que ces menaces n'atteignent votre réseau avec un taux de précision de près de 100%. Le panneau de commande complet vous permet de garder le contrôle total. De plus, si votre serveur de messagerie est en panne, votre e-mail sera mis en file d'attente. Les e-mails en file d'attente peuvent être consultés, lus et traités via l'interface Web, ajoutant à la continuité de vos e-mails entrants!";
$_LANG['store']['emailServices']['benefits']['incoming']['q2'] = "Pourquoi avez-vous besoin d'un filtre entrant professionnel?";
$_LANG['store']['emailServices']['benefits']['incoming']['a2'] = "Arrêtez de courir le risque de menaces de réseau informatique. Si votre boîte de réception est remplie de courriers électroniques non sollicités chaque jour, c'est le signe que vous avez besoin d'une solution de filtrage entrant professionnelle. Bénéficiez d'une protection complète pour votre boîte de réception et dites adieu aux menaces de spam, de virus et de logiciels malveillants!";
$_LANG['store']['emailServices']['benefits']['incoming']['q3'] = "Comment ça fonctionne";
$_LANG['store']['emailServices']['benefits']['incoming']['a3'] = "Une fois que votre domaine est (automatiquement) déployé sur le filtre entrant et que le filtrage est activé, le courrier électronique passera par le cloud de filtrage SpamExperts. Les e-mails entrants sont analysés et scannés en temps réel en toute sécurité. Aucune formation ou configuration n'est requise et tout fonctionne sur le champs. Tout message détecté comme spam est placé en quarantaine, tandis que le non-spam est envoyé à votre serveur de messagerie. La quarantaine peut être surveillée dans le SpamPanel convivial, via des rapports par e-mail, ou même directement dans votre client de messagerie! Plus de temps perdu à gérer le spam, concentrez simplement votre énergie sur les tâches commerciales, tout en gardant le contrôle total.";
$_LANG['store']['emailServices']['benefits']['outgoing']['title'] = "Le filtrage des e-mails sortants vous offre tous ces avantages ...";
$_LANG['store']['emailServices']['benefits']['outgoing']['1'] = "Plus de liste noire";
$_LANG['store']['emailServices']['benefits']['outgoing']['2'] = "Protégez la réputation de votre marque et de vos systèmes informatiques";
$_LANG['store']['emailServices']['benefits']['outgoing']['3'] = "Évitez les coûts liés à la radiation";
$_LANG['store']['emailServices']['benefits']['outgoing']['4'] = "Augmentez la continuité et la livraison des e-mails sortants";
$_LANG['store']['emailServices']['benefits']['outgoing']['5'] = "Améliorez la productivité des employés";
$_LANG['store']['emailServices']['benefits']['outgoing']['6'] = "Améliorez la gestion des abus";
$_LANG['store']['emailServices']['benefits']['outgoing']['q1'] = "Qu'est-ce que le filtrage sortant?";
$_LANG['store']['emailServices']['benefits']['outgoing']['a1'] = "Le filtrage des e-mails sortants est essentiel pour protéger la réputation de votre infrastructure informatique et garantir que tous vos e-mails sortants arrivent en toute sécurité là où ils le devraient. Cette solution professionnelle empêchera le spam et les virus de quitter votre réseau et empêchera vos adresses IP d'être à nouveau sur liste noire. De plus, le filtre sortant SpamExperts vous offre les rapports et les outils pour détecter les comptes compromis et verrouiller les utilisateurs de spam.";
$_LANG['store']['emailServices']['benefits']['outgoing']['q2'] = "Pourquoi en avez-vous besoin?";
$_LANG['store']['emailServices']['benefits']['outgoing']['a2'] = "Votre réseau a-t-il déjà envoyé des spams à votre insu? En raison des faiblesses du réseau, presque tous les appareils peuvent être compromis pour transmettre des messages SMTP sortants, ce qui permet d'envoyer des spams ou des logiciels malveillants depuis votre réseau sans que vous le sachiez! Par conséquent, il est essentiel que vous investissiez dans une solution professionnelle de filtrage sortant. Maintenez la bonne réputation de votre entreprise, empêchez les spams de quitter votre réseau et évitez d'être mis sur liste noire afin que vos e-mails arrivent toujours là où ils sont censés aller.";
$_LANG['store']['emailServices']['benefits']['archiving']['title'] = "L'archivage des e-mails vous offre tous ces avantages ...";
$_LANG['store']['emailServices']['benefits']['archiving']['1'] = "Comprend le filtrage des e-mails entrants et sortants!";
$_LANG['store']['emailServices']['benefits']['archiving']['2'] = "Ne perdez plus jamais un e-mail!";
$_LANG['store']['emailServices']['benefits']['archiving']['3'] = "Atteindre la conformité légale";
$_LANG['store']['emailServices']['benefits']['archiving']['4'] = "Améliorez les performances du système informatique";
$_LANG['store']['emailServices']['benefits']['archiving']['5'] = "Gestion conviviale de la protection des données";
$_LANG['store']['emailServices']['benefits']['archiving']['6'] = "Ajout de la continuité des e-mails, de la prise en charge de la journalisation et d'une redistribution facile";
$_LANG['store']['emailServices']['benefits']['archiving']['7'] = "Archive compressée, cryptée et sécurisée";
$_LANG['store']['emailServices']['benefits']['archiving']['q1'] = "Archivage des e-mails";
$_LANG['store']['emailServices']['benefits']['archiving']['a1'] = "L'archivage des e-mails préserve et protège tous les e-mails entrants et sortants pour un accès ultrieur. C'est un excellent moyen de récupérer des e-mails perdus ou supprimés accidentellement, d'accélérer la réponse d'audit, de sécuriser les e-mails et les pièces jointes de propriété intellectuelle, ainsi qu'à des fins de «découverte électronique» en cas de litige.";
$_LANG['store']['emailServices']['benefits']['archiving']['q2'] = "Pourquoi vous en avez besoin";
$_LANG['store']['emailServices']['benefits']['archiving']['a2a'] = "Êtes-vous désespérément à la recherche d'un e-mail important de l'année dernière, mais vous n'arrivez pas à le retrouver et vous risquez une amende ou la perte d'un accord commercial important à cause de cela? Évitez cela avec une solution professionnelle d'archivage des e-mails. L'archivage des e-mails est un outil essentiel pour préserver une sauvegarde sécurisée de tous les e-mails et être conforme à la loi.";
$_LANG['store']['emailServices']['benefits']['archiving']['a2b'] = "Dans le même temps, étant donné que les échanges d'e-mails ont un pouvoir judiciaire et sont juridiquement contraignants, la conformité des e-mails est devenue une préoccupation extrêmement importante pour les organisations. Par conséquent, il est obligatoire dans certaines industries de conserver une sauvegarde sécurisée de tous les messages électroniques et d'être conforme à la loi.";
$_LANG['store']['emailServices']['signup']['title'] = "Inscrivez-vous et commencez";
$_LANG['store']['emailServices']['signup']['choose'] = "Choisissez un produit";
$_LANG['store']['emailServices']['signup']['additional'] = "Options additionelles";
$_LANG['store']['emailServices']['signup']['order'] = "Commandez maintenant";
$_LANG['store']['emailServices']['signup']['none'] = "Aucun disponible";
$_LANG['store']['emailServices']['options']['incomingFilter'] = "Filtrage entrant";
$_LANG['store']['emailServices']['options']['outgoingFilter'] = "Filtrage sortant";
$_LANG['store']['emailServices']['options']['incomingArchive'] = "Archivage entrant";
$_LANG['store']['emailServices']['options']['outgoingArchive'] = "Archivage sortant";
$_LANG['store']['emailServices']['options']['incomingFilterArchive'] = "Filtrage et archivage entrants";
$_LANG['store']['emailServices']['options']['outgoingFilterArchive'] = "Filtrage et archivage sortants";
$_LANG['store']['emailServices']['options']['addFor'] = "Ajoutez :description pour <span>seulement :pricing de plus</span>";
$_LANG['store']['emailServices']['faqs']['title'] = "Questions fréquemment posées";
$_LANG['store']['emailServices']['faqs']['q1'] = "Comment ça marche?";
$_LANG['store']['emailServices']['faqs']['a1'] = "Les e-mails sont acheminés via des serveurs d'auto-apprentissage intelligents SpamExperts qui détectent et bloquent le spam avant qu'il ne vous atteigne.";
$_LANG['store']['emailServices']['faqs']['q2'] = "Quelle est la précision du filtrage?";
$_LANG['store']['emailServices']['faqs']['a2'] = "Grâce au traitement de millions d'e-mails chaque jour, nos filtres d'e-mails ont un taux de pointe avec une précision de près de 100%.";
$_LANG['store']['emailServices']['faqs']['q3'] = "Puis-je récupérer les messages bloqués?";
$_LANG['store']['emailServices']['faqs']['a3'] = "Oui, un panneau de contrôle complet avec recherche dans les journaux, mise en quarantaine et de nombreux autres outils vous permet de vérifier l'état de tout e-mail qui est passé par le système.";
$_LANG['store']['emailServices']['faqs']['q4'] = "Combien de temps faut-il pour la configuration?";
$_LANG['store']['emailServices']['faqs']['a4'] = "La configuration est rapide, automatisée et elle sera opérationnelle et protégera votre courrier électronique en quelques minutes.";
$_LANG['store']['emailServices']['faqs']['q5'] = "Qu'est-ce que l'archivage des e-mails?";
$_LANG['store']['emailServices']['faqs']['a5'] = "Les e-mails sont si importants de nos jours, avec l'archivage vos e-mails sont stocké en toute sécurité, ce qui vous donne plus de confiance et de tranquillité d'esprit.";
$_LANG['store']['emailServices']['faqs']['q6'] = "Combien d'e-mails puis-je stocker?";
$_LANG['store']['emailServices']['faqs']['a6'] = "L'archivage des e-mails comprend 10 Go de stockage d'e-mails compressés par défaut. Si vous avez besoin de plus de stockage, des licences supplémentaires de 10 Go peuvent être ajoutées.";
$_LANG['store']['emailServices']['preview'] = "Les produits de service de messagerie que vous activez s'afficheront ici";
$_LANG['store']['emailServices']['domain'] = "domaine";
$_LANG['domainDns']['a'] = "A (Address)";
$_LANG['domainDns']['aaaa'] = "AAAA (Address)";
$_LANG['domainDns']['mxe'] = "MXE (Mail Easy)";
$_LANG['domainDns']['mx'] = "MX (Mail)";
$_LANG['domainDns']['cname'] = "CNAME (Alias)";
$_LANG['domainDns']['txt'] = "SPF (txt)";
$_LANG['domainDns']['url'] = "Redirection d'URL";
$_LANG['domainDns']['frame'] = "Masquage d'URL";

$_LANG['navContacts'] = "Contacts";
$_LANG['navUserManagement'] = "Gestion des utilisateurs";
$_LANG['navSwitchAccount'] = "Changer de compte";
$_LANG['navAccountSecurity'] = "Sécurité du compte";

$_LANG['never'] = "Jamais";

$_LANG['yourProfile'] = "Votre profil";
$_LANG['verifyEmailAddress'] = "Merci de vérifier votre boîte courriel et d'ouvrir le courriel correspondant pour vérifier votre courriel.";

$_LANG['emailVerification']['title'] = "Vérification de l'E-mail";
$_LANG['emailVerification']['success'] = "Votre adresse e-mail a été vérifiée";
$_LANG['emailVerification']['expired'] = "Votre lien de vérification par e-mail a expiré";
$_LANG['emailVerification']['notFound'] = "Désolé, nous n'avons pas trouvé de vérification en attente correspondant à votre demande.";
$_LANG['emailVerification']['loginToRequest'] = "Veuillez vous connecter pour demander un nouveau lien de vérification par e-mail.";

$_LANG['switchAccount']['title'] = "Choisissez votre compte";
$_LANG['switchAccount']['choose'] = "Choisissez un compte pour vous connecter et gérer";
$_LANG['switchAccount']['noneFound'] = "Aucun compte trouvé.";
$_LANG['switchAccount']['createInstructions'] = "Pour créer un nouveau compte, vous devrez passer une nouvelle commande.";
$_LANG['switchAccount']['noLongerActive'] = "Ce compte n'est plus actif";
$_LANG['switchAccount']['invalidChooseAnother'] = "Compte non valide demandé. Merci d'en choisir un autre.";
$_LANG['switchAccount']['cancelAndReturn'] = "Annuler et revenir à la page d'accueil";
$_LANG['switchAccount']['forcedSwitchRequest'] = "L'URL à laquelle vous avez tenté d'accéder nécessite que vous soyez connecté en tant qu'autre client.";

$_LANG['shopNow'] = "Achetez maintenant";
$_LANG['clientOwner'] = "Propriétaire";

$_LANG['userManagement']['title'] = "Gestion des utilisateurs";
$_LANG['userManagement']['managePermissions'] = "Gérer les autorisations";
$_LANG['userManagement']['permissions'] = "Autorisations";
$_LANG['userManagement']['usersFound'] = ":count Utilisateurs trouvés";
$_LANG['userManagement']['userDescriptor'] = "Adresse e-mail / Dernière connexion";
$_LANG['userManagement']['lastLogin'] = "Dernière connexion";
$_LANG['userManagement']['actions'] = "Actions";
$_LANG['userManagement']['emailAddress'] = "Adresse e-mail";
$_LANG['userManagement']['removeAccess'] = "Supprimer l'accès";
$_LANG['userManagement']['pendingInvites'] = "Invitations en attente";
$_LANG['userManagement']['inviteSent'] = "Invitation envoyée";
$_LANG['userManagement']['resendInvite'] = "Renvoyer l'invitation";
$_LANG['userManagement']['cancelInvite'] = "Annuler l'invitation";
$_LANG['userManagement']['accountOwnerPermissionsInfo'] = "Les propriétaires de compte disposent toujours des autorisations complètes sur un compte client.";
$_LANG['userManagement']['inviteNewUser'] = "Inviter un nouvel utilisateur";
$_LANG['userManagement']['inviteEmail'] = "E-mail d'invitation";
$_LANG['userManagement']['inviteNewUserDescription'] = "Inviter un nouvel utilisateur vous permet d'inviter un nouvel utilisateur sur votre compte. Si l'invité dispose déjà d'un compte utilisateur, il pourra accéder à votre compte en utilisant ses identifiants de connexion existants. Si l'utilisateur n'a pas encore de compte utilisateur, il pourra en créer un.";
$_LANG['userManagement']['allPermissions'] = "Toutes les autorisations";
$_LANG['userManagement']['choosePermissions'] = "Choisissez les autorisations";
$_LANG['userManagement']['sendInvite'] = "Envoyer une invitation";
$_LANG['userManagement']['removeAccessSure'] = "Voulez-vous vraiment supprimer cet accès utilisateur?";
$_LANG['userManagement']['removeAccessInfo'] = "Ils ne pourront plus accéder ni administrer ce compte.";
$_LANG['userManagement']['cancelInviteSure'] = "Voulez-vous vraiment annuler cette invitation?";
$_LANG['userManagement']['cancelInviteInfo'] = "L'utilisateur ne sera pas informé de cette annulation.";
$_LANG['userManagement']['permissionsUpdateSuccess'] = "Autorisations mises à jour avec succès!";
$_LANG['userManagement']['userRemoveSuccess'] = "L'utilisateur a bien été supprimé!";
$_LANG['userManagement']['inviteSentSuccess'] = "Invitation envoyée avec succès!";
$_LANG['userManagement']['alreadyLinked'] = "L'adresse e-mail saisie est déjà un utilisateur de ce compte";
$_LANG['userManagement']['alreadyInvited'] = "L'adresse e-mail que vous avez saisie a déjà une invitation active.";
$_LANG['userManagement']['inviteResendSuccess'] = "Invitation renvoyée avec succès!";
$_LANG['userManagement']['inviteCancelled'] = "Invitation annulée avec succès!";
$_LANG['userManagement']['settings'] = "Les paramètres de sécurité suivants s'appliquent à votre compte utilisateur.";

$_LANG['userProfile']['profile'] = "Profil";
$_LANG['userProfile']['changeEmail'] = "Changer l'adresse email";
$_LANG['userProfile']['notVerified'] = "E-mail non vérifié";
$_LANG['userProfile']['verified'] = "E-mail vérifié";

$_LANG['accountInvite']['title'] = "Accepter l'invitation";
$_LANG['accountInvite']['youHaveBeenInvited'] = "Vous avez été invité à :clientName";
$_LANG['accountInvite']['givenAccess'] = ":ot:senderName:ct vous a donné accès au compte :ot:clientName:ct .";
$_LANG['accountInvite']['inviteAcceptLoggedIn'] = "Pour accepter l'invitation, cliquez simplement sur le bouton ci-dessous.";
$_LANG['accountInvite']['inviteAcceptLoggedOut'] = "Pour accepter l'invitation, veuillez vous connecter ou vous inscrire ci-dessous.";
$_LANG['accountInvite']['accept'] = "Accepter l'invitation";
$_LANG['accountInvite']['userAlreadyAssociated'] = "Votre compte utilisateur est déjà associé au compte d'invitation cible";
$_LANG['accountInvite']['acceptSuccess'] = "Invitation de compte acceptée!";
$_LANG['accountInvite']['emailAlreadyExists'] = "Un utilisateur existe déjà avec cette adresse e-mail. Veuillez vous connecter ou utiliser un autre e-mail.";
$_LANG['accountInvite']['notFound'] = "Désolé, nous n'avons pas trouvé d'invitation en attente correspondant à votre demande.";
$_LANG['accountInvite']['contactAdministrator'] = "Veuillez contacter l'administrateur du compte pour demander une nouvelle invitation.";

$_LANG['clientareanavcontacts'] = "Gestion des contacts";

$_LANG['permissions']['descriptions']['profile'] = "Accéder et modifier les informations de profil client";
$_LANG['permissions']['descriptions']['contacts'] = "Accéder et gérer les contacts";
$_LANG['permissions']['descriptions']['products'] = "Afficher l'accès aux produits, services et modules complémentaires";
$_LANG['permissions']['descriptions']['manageproducts'] = "Autoriser les réinitialisations de mot de passe et autres actions";
$_LANG['permissions']['descriptions']['productsso'] = "Autoriser la connexion unique aux services";
$_LANG['permissions']['descriptions']['domains'] = "Afficher l'accès aux enregistrements de domaine";
$_LANG['permissions']['descriptions']['managedomains'] = "Autoriser la gestion de domaine, par exemple. serveurs de noms / whois / transferts";
$_LANG['permissions']['descriptions']['invoices'] = "Consulter et accéder au paiement des factures";
$_LANG['permissions']['descriptions']['quotes'] = "Afficher et accepter les devis";
$_LANG['permissions']['descriptions']['tickets'] = "Accès pour ouvrir, répondre et gérer les tickets d'assistance";
$_LANG['permissions']['descriptions']['affiliates'] = "Accès pour afficher et demander des retraits";
$_LANG['permissions']['descriptions']['emails'] = "Accès pour afficher l'historique des e-mails du compte";
$_LANG['permissions']['descriptions']['orders'] = "Autoriser la passation de nouvelles commandes";

$_LANG['closed'] = "Fermé";
$_LANG['noPermission'] = "Aucune autorisation";

$_LANG['domainDetails']['error']['getNs'] = "Un problème est survenu lors de la récupération des serveurs de noms de domaine. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['saveNs'] = "Un problème est survenu lors de la mise à jour des serveurs de noms de domaine. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['getContact'] = "Un problème est survenu lors de la récupération des coordonnées du domaine. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['saveContact'] = "Un problème est survenu lors de la mise à jour des coordonnées du domaine. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['getDns'] = "Un problème est survenu lors de la récupération des enregistrements DNS. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['saveDns'] = "Un problème est survenu lors de la mise à jour des enregistrements DNS. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['getEmailFwd'] = "Un problème est survenu lors de la récupération des redirecteurs d'e-mails. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['saveEmailFwd'] = "Un problème est survenu lors de la mise à jour des redirecteurs d'e-mails. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['deleteNs'] = "Un problème est survenu lors de la suppression du serveur de noms privé. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['modifyNs'] = "Un problème est survenu lors de la modification du serveur de noms privé. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['registerNs'] = "Un problème est survenu lors de l'enregistrement du serveur de noms privé. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['saveRegLock'] = "Un problème est survenu lors de la mise à jour de l'état de verrouillage du domaine. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['releaseDomain'] = "Un problème est survenu lors de la libération du domaine. Veuillez contacter l'assistance.";
$_LANG['domainDetails']['error']['resendNotification'] = "Un problème est survenu lors du renvoi de l'e-mail de notification. Veuillez contacter l'assistance.";

$_LANG['idnLanguage']['afr'] = "Afrikaans";
$_LANG['idnLanguage']['alb'] = "Albanais";
$_LANG['idnLanguage']['ara'] = "Arabe";
$_LANG['idnLanguage']['arg'] = "Aragonais";
$_LANG['idnLanguage']['arm'] = "Arménien";
$_LANG['idnLanguage']['asm'] = "Assamais";
$_LANG['idnLanguage']['ast'] = "Asturien";
$_LANG['idnLanguage']['ave'] = "Avestan";
$_LANG['idnLanguage']['awa'] = "Awadhi";
$_LANG['idnLanguage']['aze'] = "Azerbaïdjanais";
$_LANG['idnLanguage']['ban'] = "Balinais";
$_LANG['idnLanguage']['bal'] = "Baloutches";
$_LANG['idnLanguage']['bas'] = "Basa";
$_LANG['idnLanguage']['bak'] = "Bachkir";
$_LANG['idnLanguage']['baq'] = "Basque";
$_LANG['idnLanguage']['bel'] = "Biélorusse";
$_LANG['idnLanguage']['ben'] = "Bengali";
$_LANG['idnLanguage']['bho'] = "Bhojpuri";
$_LANG['idnLanguage']['bos'] = "Bosniaque";
$_LANG['idnLanguage']['bul'] = "Bulgare";
$_LANG['idnLanguage']['bur'] = "Birman";
$_LANG['idnLanguage']['car'] = "Carib";
$_LANG['idnLanguage']['cat'] = "Catalan";
$_LANG['idnLanguage']['che'] = "Tchétchène";
$_LANG['idnLanguage']['chi'] = "Chinois";
$_LANG['idnLanguage']['chv'] = "Chuvash";
$_LANG['idnLanguage']['cop'] = "Coptic";
$_LANG['idnLanguage']['cos'] = "Corse";
$_LANG['idnLanguage']['scr'] = "Croate";
$_LANG['idnLanguage']['cze'] = "Tchèque";
$_LANG['idnLanguage']['dan'] = "Danois";
$_LANG['idnLanguage']['div'] = "Divehi";
$_LANG['idnLanguage']['doi'] = "Dogri";
$_LANG['idnLanguage']['dut'] = "Néerlandais";
$_LANG['idnLanguage']['eng'] = "Anglais";
$_LANG['idnLanguage']['est'] = "Estonien";
$_LANG['idnLanguage']['fao'] = "Féroïen";
$_LANG['idnLanguage']['fij'] = "Fidjien";
$_LANG['idnLanguage']['fin'] = "Finlandais";
$_LANG['idnLanguage']['fre'] = "Français";
$_LANG['idnLanguage']['fry'] = "Frison";
$_LANG['idnLanguage']['gla'] = "Gaélique; Gaélique écossais";
$_LANG['idnLanguage']['geo'] = "Géorgien";
$_LANG['idnLanguage']['ger'] = "Allemand";
$_LANG['idnLanguage']['gon'] = "Gondi";
$_LANG['idnLanguage']['gre'] = "Grec";
$_LANG['idnLanguage']['guj'] = "Gujarati";
$_LANG['idnLanguage']['heb'] = "Hébreu";
$_LANG['idnLanguage']['hin'] = "Hindi";
$_LANG['idnLanguage']['hun'] = "Hongrois";
$_LANG['idnLanguage']['ice'] = "Islandais";
$_LANG['idnLanguage']['inc'] = "Indic";
$_LANG['idnLanguage']['ind'] = "Indonésien";
$_LANG['idnLanguage']['inh'] = "Ingouche";
$_LANG['idnLanguage']['gle'] = "Irlandais";
$_LANG['idnLanguage']['ita'] = "Italien";
$_LANG['idnLanguage']['jpn'] = "Japonais";
$_LANG['idnLanguage']['jav'] = "Javanais";
$_LANG['idnLanguage']['kas'] = "Kashmiri";
$_LANG['idnLanguage']['kaz'] = "Kazakh";
$_LANG['idnLanguage']['khm'] = "Khmer";
$_LANG['idnLanguage']['kir'] = "Kirghiz";
$_LANG['idnLanguage']['kor'] = "Coréen";
$_LANG['idnLanguage']['kur'] = "Kurde";
$_LANG['idnLanguage']['lao'] = "Lao";
$_LANG['idnLanguage']['lat'] = "Latin";
$_LANG['idnLanguage']['lav'] = "Latvian";
$_LANG['idnLanguage']['lit'] = "Lituanien";
$_LANG['idnLanguage']['ltz'] = "Luxembourgeois";
$_LANG['idnLanguage']['mac'] = "Macédonien";
$_LANG['idnLanguage']['may'] = "Malais";
$_LANG['idnLanguage']['mal'] = "Malayalam";
$_LANG['idnLanguage']['mlt'] = "Maltais";
$_LANG['idnLanguage']['mao'] = "Maori";
$_LANG['idnLanguage']['mol'] = "Moldave";
$_LANG['idnLanguage']['mon'] = "Mongol";
$_LANG['idnLanguage']['nep'] = "Népalais";
$_LANG['idnLanguage']['nor'] = "Norvégien";
$_LANG['idnLanguage']['ori'] = "Oriya";
$_LANG['idnLanguage']['oss'] = "Ossetian";
$_LANG['idnLanguage']['per'] = "Persan";
$_LANG['idnLanguage']['pol'] = "Polonais";
$_LANG['idnLanguage']['por'] = "Portugais";
$_LANG['idnLanguage']['pan'] = "Punjabi";
$_LANG['idnLanguage']['pus'] = "Pushto";
$_LANG['idnLanguage']['raj'] = "Rajasthani";
$_LANG['idnLanguage']['rum'] = "Roumain";
$_LANG['idnLanguage']['rus'] = "Russe";
$_LANG['idnLanguage']['smo'] = "Samoan";
$_LANG['idnLanguage']['san'] = "Sanskrit";
$_LANG['idnLanguage']['srd'] = "Sarde";
$_LANG['idnLanguage']['scc'] = "Serbe";
$_LANG['idnLanguage']['snd'] = "Sindhi";
$_LANG['idnLanguage']['sin'] = "Cinghalais";
$_LANG['idnLanguage']['slo'] = "Slovaque";
$_LANG['idnLanguage']['slv'] = "Slovène";
$_LANG['idnLanguage']['som'] = "Somali";
$_LANG['idnLanguage']['spa'] = "Espagnol";
$_LANG['idnLanguage']['swa'] = "Swahili";
$_LANG['idnLanguage']['swe'] = "Suédois";
$_LANG['idnLanguage']['syr'] = "Syriaque";
$_LANG['idnLanguage']['tgk'] = "Tadjik";
$_LANG['idnLanguage']['tam'] = "Tamil";
$_LANG['idnLanguage']['tel'] = "Telugu";
$_LANG['idnLanguage']['tha'] = "Thaïlandais";
$_LANG['idnLanguage']['tib'] = "Tibétain";
$_LANG['idnLanguage']['tur'] = "Turc";
$_LANG['idnLanguage']['ukr'] = "Ukrainien";
$_LANG['idnLanguage']['urd'] = "Ourdou";
$_LANG['idnLanguage']['uzb'] = "Ouzbek";
$_LANG['idnLanguage']['vie'] = "Vietnamien";
$_LANG['idnLanguage']['wel'] = "Gallois";
$_LANG['idnLanguage']['yid'] = "Yiddish";
$_LANG['cart']['idnLanguageDescription'] = "Nous avons détecté que le domaine que vous avez entré est un nom de domaine international. Afin de continuer, veuillez sélectionner la langue de votre domaine.";
$_LANG['cart']['idnLanguage'] = "Choisissez la langue IDN";
$_LANG['cart']['selectIdnLanguageForRegister'] = "Veuillez sélectionner la langue du domaine que vous souhaitez enregistrer.";

$_LANG['support']['requestor']['operator'] = "Opérateur";
$_LANG['support']['requestor']['owner'] = "Propriétaire";
$_LANG['support']['requestor']['authorizeduser'] = "Utilisateur autorisé";
$_LANG['support']['requestor']['registereduser'] = "Utilisateur enregistré";
$_LANG['support']['requestor']['subaccount'] = "Sous-compte";
$_LANG['support']['requestor']['guest'] = "Invité";

$_LANG['twoFactor']['enabled'] = "Authentification à deux facteurs activé";
$_LANG['twoFactor']['disabled'] = "Authentification à deux facteurs désactivé";

$_LANG['store']['poweredBy'] = "Propulsé par : :service";

$_LANG['navMarketConnectService']['ox'] = "Email professionnel";

$_LANG['store']['ox']['title'] = "Email professionnel";
$_LANG['store']['ox']['manage'] = "Gérer les comptes";
$_LANG['store']['ox']['appSuite'] = "OX App Suite";
$_LANG['store']['ox']['promoHeading'] = "OX App Suite est une suite de puissantes applications de messagerie et productivité conçues pour les entreprises de toute taille (et budget).";
$_LANG['store']['ox']['viewPricing'] = "Voir les plans & la tarification";
$_LANG['store']['ox']['standout']['feature1']['title'] = "Attendez plus des e-mails";
$_LANG['store']['ox']['standout']['feature2']['title'] = "Dites adieu au spam";
$_LANG['store']['ox']['standout']['feature3']['title'] = "Travaillez n'importe où";
$_LANG['store']['ox']['standout']['feature1']['bullet1'] = "Email professionnel@votre-domaine.com";
$_LANG['store']['ox']['standout']['feature1']['bullet2'] = "Sûr et fiable; avec 99,9% de disponibilité";
$_LANG['store']['ox']['standout']['feature1']['bullet3'] = "Utiliser des applications de messagerie Web, mobiles ou de bureau";
$_LANG['store']['ox']['standout']['feature1']['bullet4'] = "D'énormes boîtes aux lettres de 10 Go et 50 Go";
$_LANG['store']['ox']['standout']['feature2']['detail'] = "En utilisant l'intelligence artificielle et un logiciel de défense prédictive des e-mails, OX App Suite se bat pour protéger votre boîte de réception contre le spam, les virus, les logiciels malveillants et les attaques de phishing.";
$_LANG['store']['ox']['standout']['feature3']['detail'] = "OX App Suite se synchronise sur tous vos appareils. Et l'accès mobile et de bureau ne pose aucun problème car OX App Suite fonctionne de manière transparente sur tous les clients natifs.";
$_LANG['store']['ox']['featuresHeadline'] = "Fonctionnalités";
$_LANG['store']['ox']['feature1']['title'] = "Stockage de fichiers dans le cloud";
$_LANG['store']['ox']['feature1']['detail'] = "Stockez et partagez vos documents importants en toute sécurité dans le cloud. Et avec (jusqu'à) 50 Go, vous aurez beaucoup d'espace pour les années à venir.";
$_LANG['store']['ox']['feature2']['title'] = "Calendrier et contacts";
$_LANG['store']['ox']['feature2']['detail'] = "Communiquez comme une entreprise avec l'agenda partagé, l'assistant de planification, le support iCal et la liste d'adresses globale!";
$_LANG['store']['ox']['feature3']['title'] = "De nombreuses fonctionnalités de messagerie";
$_LANG['store']['ox']['feature3']['detail'] = "Vos fonctionnalités de messagerie préférées sont toutes ici, y compris les redirecteurs, les répondeurs automatiques, les filtres, les signatures, les notifications et plus encore!";
$_LANG['store']['ox']['feature4']['title'] = "Ajoutez des applications de productivité!";
$_LANG['store']['ox']['feature4']['detail'] = "Créez, modifiez et partagez des documents Microsoft Office tels que Word, Excel et PowerPoint avec les puissantes applications en ligne d'App Suite.";
$_LANG['store']['ox']['feature5']['title'] = "Apportez vos applications";
$_LANG['store']['ox']['feature5']['detail'] = "Ajoutez facilement vos services de messagerie et / ou applications préférés dans App Suite; comme Gmail, Dropbox, Zoom (à venir) et plus encore!";
$_LANG['store']['ox']['feature6']['title'] = "La confidentialité absolue";
$_LANG['store']['ox']['feature6']['detail'] = "Ni App Suite, ni nous-mêmes, ne lirons, numériserons ou partagerons jamais vos informations personnelles ou par e-mail avec des tiers. Pour toujours.";
$_LANG['store']['ox']['pricingHeadline'] = "Plans & tarification";
$_LANG['store']['ox']['faq1']['question'] = "Quelles applications sont incluses dans OX App Suite?";
$_LANG['store']['ox']['faq1']['answer'] = "Tous les plans OX App Suite incluent l'accès au Webmail, au calendrier, aux tâches et au carnet d'adresses. Le package Productivité ajoute des documents OX Drive et OX (texte, feuilles de calcul et présentations).";
$_LANG['store']['ox']['faq2']['question'] = "Puis-je ajouter des comptes de messagerie externes à OX App Suite?";
$_LANG['store']['ox']['faq2']['answer'] = "Oui, OX App Suite prend en charge la connexion de tous les comptes de messagerie IMAP externes, y compris les fournisseurs populaires tels que Gmail, Yahoo et Outlook.com. Ajoutez simplement votre adresse e-mail et votre mot de passe dans App Suite et tout e-mail envoyé à ces comptes apparaîtra dans votre interface App Suite.";
$_LANG['store']['ox']['faq3']['question'] = "Puis-je synchroniser le calendrier et les contacts entre OX App Suite et mon appareil mobile?";
$_LANG['store']['ox']['faq3']['answer'] = "Oui, OX App Suite prend entièrement en charge CalDAV et CardDAV. Et pour les utilisateurs d'Android, la synchronisation est facile via notre application Android Sync dédiée.";
$_LANG['store']['ox']['faq4']['question'] = "OX App Suite fonctionnera-t-il sur mon appareil?";
$_LANG['store']['ox']['faq4']['answer'] = "App Suite fonctionne de manière transparente avec la plupart des clients de messagerie natifs de bureau et mobiles.";
$_LANG['store']['ox']['faq4']['devices'] = "Appareils mobiles: iPhone sur iOS 11 / iOS 12, Smartphone sur Android 4.1 ou version ultérieure<br>Navigateurs pris en charge: Safari, Chrome (dernière et précédente version), Mozilla Firefox (dernière et précédente version), Microsoft Internet Explorer 11 / Edge";
$_LANG['store']['ox']['faq5']['question'] = "OX App Suite protège-t-il contre le spam et les virus?";
$_LANG['store']['ox']['faq5']['answer'] = "Oui! OX App Suite utilise une technologie propriétaire ainsi que des partenariats avec des fournisseurs bien établis dans le secteur de l'antispam pour garder votre boîte de réception aussi propre et sûre que possible.";
$_LANG['store']['ox']['faq6']['question'] = "Qu'est-ce que OX Drive (Productivité)?";
$_LANG['store']['ox']['faq6']['answer'] = "OX Drive est une solution de stockage en ligne pour stocker vos documents, photos et supports dans le cloud. Cela signifie que vous n'avez besoin que d'accéder à OX App Suite et OX Drive et que vous aurez également accès à tous vos fichiers. OX Drive vous permet de synchroniser vos fichiers avec tous vos appareils à l'aide du navigateur ou des applications natives.";
$_LANG['store']['ox']['faq7']['question'] = "Qu'est-ce que OX Documents (Productivité)?";
$_LANG['store']['ox']['faq7']['answer'] = "OX Text, OX Spreadsheet et OX Presentation sont les 3 applications du terme plus large OX Documents. Ces applications peuvent être utilisées pour créer et modifier des documents texte, des feuilles de calcul et des présentations en ligne. Créez et modifiez vos documents où que vous soyez en utilisant les fonctionnalités et fonctions familières de votre solution logicielle Office et sur tous vos appareils.";
$_LANG['store']['ox']['faq8']['question'] = "Quelles langues sont prises en charge par OX App Suite?";
$_LANG['store']['ox']['faq8']['answer'] = "OX App Suite prend en charge les langues suivantes: anglais, allemand, espagnol, français, italien, néerlandais, polonais, 中文 简体, 中文 繁體, 日本語 日本";
$_LANG['store']['ox']['faq9']['question'] = "Puis-je migrer mon compte e-mail existant d'un autre fournisseur?";
$_LANG['store']['ox']['faq9']['answer'] = "Oui, nous proposons en libre-service un outil de migration intuitif et facile à utiliser. Migrer de tous les fournisseurs de mails populaires y compris Apple iCloud, Gmail, Outlook.com/Windows Live/Hotmail, Yahoo Mail, GMX, ou T-Online, ou saisissez les données d'accès de vous fournisseur utilisant l'IMAP/POP3 ou tout autre protocole préféré.";
$_LANG['store']['ox']['pricing']['features']['sla'] = "SLA de disponibilité de 99,9%";
$_LANG['store']['ox']['pricing']['features']['antivirus'] = "Antivirus et antispam Premium";
$_LANG['store']['ox']['pricing']['features']['email'] = "email@votre-domaine.com";
$_LANG['store']['ox']['pricing']['features']['size'] = "Taille des boîtes aux lettres";
$_LANG['store']['ox']['pricing']['features']['webmail'] = "Webmail complet";
$_LANG['store']['ox']['pricing']['features']['imap'] = "Accès mobile et bureau (IMAP)";
$_LANG['store']['ox']['pricing']['features']['calendars'] = "Calendriers, contacts, tâches partagés";
$_LANG['store']['ox']['pricing']['features']['caldav'] = "CardDAV & CalDAV";
$_LANG['store']['ox']['pricing']['features']['portal'] = "Page de portail intégrée";
$_LANG['store']['ox']['pricing']['features']['migration'] = "Outil de migration en libre-service";
$_LANG['store']['ox']['pricing']['features']['filestorage'] = "Stockage de fichiers dans le cloud";
$_LANG['store']['ox']['pricing']['features']['collab'] = "Partage de fichiers et collaboration";
$_LANG['store']['ox']['pricing']['features']['officeapps'] = "Suite Office en ligne";
$_LANG['store']['ox']['pricing']['features']['appsword'] = "Créer / modifier des documents Word";
$_LANG['store']['ox']['pricing']['features']['appsspreadsheets'] = "Créer / modifier des feuilles de calcul";
$_LANG['store']['ox']['pricing']['features']['appsslides'] = "Créer / modifier PowerPoint";
$_LANG['store']['ox']['cartTitle'] = "Email professionnel";
$_LANG['store']['ox']['cartShortDescription'] = "Obtenez une messagerie professionnelle de qualité professionnelle avec des outils de communication et de collaboration complets pour un travail sécurisé et fiable.";
$_LANG['store']['ox']['promo']['sidebar']['title'] = "Email professionnel";
$_LANG['store']['ox']['promo']['sidebar']['body'] = "E-mail fiable et abordable pour votre petite entreprise";

$_LANG['store']['addon']['wptk']['title'] = "WP Toolkit";
$_LANG['store']['addon']['wptk']['pleskTitle'] = "Smart Updates for WordPress";
$_LANG['store']['addon']['wptk']['pleskTagline'] = "Super charge your WordPress experience";
$_LANG['store']['addon']['wptk']['getItNow'] = "Get It Now";
$_LANG['store']['addon']['wptk']['redefined1'] = "WordPress Management Redefined with";
$_LANG['store']['addon']['wptk']['redefined2'] = "WP Toolkit Deluxe for";
$_LANG['store']['addon']['wptk']['switchCpanel'] = "Looking for WP Toolkit for cPanel?";
$_LANG['store']['addon']['wptk']['switchPlesk'] = "Looking for WP Toolkit for Plesk?";
$_LANG['store']['addon']['wptk']['introTitle'] = "WP Toolkit Deluxe delivers powerful WordPress plugin &amp; theme management, security hardening, automation, cloning, and backup/restores all from a single user-friendly dashboard.";
$_LANG['store']['addon']['wptk']['introBody'] = "Take the guesswork, and the legwork, out of managing WordPress. In addition to everything you’d expect, from easy backup and restores to search engine index management and one-click WordPress login, you also get automatic Smart Updates, staging and cloning to easily duplicate or test existing websites, one-click security hardening, and so much more!";
$_LANG['store']['addon']['wptk']['pleskIntroTitle'] = "Smart Updates for WordPress Toolkit identifies and analyzes any potential updates for your WordPress installations, then either performs the update at no risk to your live website or notifies you that a potentially dangerous update is now available.";
$_LANG['store']['addon']['wptk']['pleskIntroBody'] = "Using cutting-edge intelligence and automation, Smart Updates keeps your WordPress websites up-to-date, online, and safe from any potentially damaging updates to your core files, plugins, and theme.";
$_LANG['store']['addon']['wptk']['midTitle1'] = "The Only Toolkit You'll :breaktag Ever Need...";
$_LANG['store']['addon']['wptk']['featureTitle1'] = "Create Quickly &amp; Easily";
$_LANG['store']['addon']['wptk']['featureBody1'] = "Install and configure plugins and themes to customize the look and feel of any (or all) of your WordPress websites simultaneously with just a few clicks.";
$_LANG['store']['addon']['wptk']['featureTitle2'] = "Experiment Safely";
$_LANG['store']['addon']['wptk']['featureBody2'] = "Clone any existing WordPress site to test designs, plugins, or any aspect of your site. Then sync back to your live site anytime you choose.";
$_LANG['store']['addon']['wptk']['featureTitle3'] = "Enjoy Security";
$_LANG['store']['addon']['wptk']['featureBody3'] = "A single click of a button will scan and harden your WordPress websites against your selected security risks. You can also password protect specific sites or pages.";
$_LANG['store']['addon']['wptk']['featureTitle4'] = "Automate Updates";
$_LANG['store']['addon']['wptk']['featureBody4'] = "Smart Updates automatically identifies and analyzes updates for compatibility and safety, then either installs or notifies you of any issue, ensuring your site’s safety.";
$_LANG['store']['addon']['wptk']['featureTitle5'] = "Cloning &amp; Mass Hardening";
$_LANG['store']['addon']['wptk']['featureBody5'] = "Create a duplicate of your live site to experiment with, all while protecting all of your WordPress sites with a single click.";
$_LANG['store']['addon']['wptk']['featureTitle6'] = "Maintenance Mode";
$_LANG['store']['addon']['wptk']['featureBody6'] = "Take your site down while displaying a custom message.";
$_LANG['store']['addon']['wptk']['smartUpdates']['featureTitle1'] = "How Does It Work?";
$_LANG['store']['addon']['wptk']['smartUpdates']['featureBody1'] = "Smart Updates clones and updates a copy of the live website, then compares the two versions to determine success.";
$_LANG['store']['addon']['wptk']['smartUpdates']['featureTitle2'] = "What If An Update Is Safe?";
$_LANG['store']['addon']['wptk']['smartUpdates']['featureBody2'] = "Safe updates can be automatically installed to the live website, at no risk of breaking or otherwise damaging the website.";
$_LANG['store']['addon']['wptk']['smartUpdates']['featureTitle3'] = "What If An Update Is Unsafe?";
$_LANG['store']['addon']['wptk']['smartUpdates']['featureBody3'] = "The site owner will be presented with an interface to review each issue discovered to decide if they wish to proceed.";
$_LANG['store']['addon']['wptk']['plesk']['featureTitle1'] = "WordPress Simplified";
$_LANG['store']['addon']['wptk']['plesk']['featureBody1'] = "One-click installer to initialize and configure WordPress from start to finish. One dashboard to mass-manage multiple WordPress instances.";
$_LANG['store']['addon']['wptk']['plesk']['featureTitle2'] = "Stage and Test";
$_LANG['store']['addon']['wptk']['plesk']['featureBody2'] = "Test new features and ideas in a sandbox before pushing them to production – No plugins required, no separate server needed.";
$_LANG['store']['addon']['wptk']['plesk']['featureTitle3'] = "Secure Against Attacks";
$_LANG['store']['addon']['wptk']['plesk']['featureBody3'] = "Hardens your site by default, further enhanced with the Toolkit’s security scanner. No security expertise necessary.";
$_LANG['store']['addon']['wptk']['plesk']['featureTitle4'] = "Run and Automate";
$_LANG['store']['addon']['wptk']['plesk']['featureBody4'] = "Singularly or mass-execute updates to the WP core, themes or plugins. Monitor and run all your WordPress sites from one dashboard.";
$_LANG['store']['addon']['wptk']['plesk']['featureTitle5'] = "Cut Out Complexity";
$_LANG['store']['addon']['wptk']['plesk']['featureBody5'] = "Stage, Clone, Sync, Update, Migrate and other complex tasks executed with one click. No more stressed-out dev teams, no more high-risk activities.";
$_LANG['store']['addon']['wptk']['plesk']['featureTitle6'] = "Simple, but not Amateur";
$_LANG['store']['addon']['wptk']['plesk']['featureBody6'] = "Get full control with WP-CLI, maintenance mode, debug management, search engine index management and more.";
$_LANG['store']['addon']['wptk']['midTitle2'] = "The Most Complete, Secure, and Versatile Toolkit for WordPress";
$_LANG['store']['addon']['wptk']['screenshotDesc'] = "WP Toolkit Deluxe provides everything you need to install, configure, update, and secure WordPress websites. Upgrade to WP Toolkit Deluxe today for as low as :price.";
$_LANG['store']['addon']['wptk']['screenshotDescFree'] = "WP Toolkit Deluxe provides everything you need to install, configure, update, and secure WordPress websites. Upgrade to WP Toolkit Deluxe today.";
$_LANG['store']['addon']['wptk']['smartUpdates']['screenshotDesc'] = "Smart Updates for WP Toolkit provides everything you need to keep your WordPress websites up-to-date and running smoothly. Upgrade to Smart Updates today for as low as :price.";
$_LANG['store']['addon']['wptk']['smartUpdates']['screenshotDescFree'] = "Smart Updates for WP Toolkit provides everything you need to keep your WordPress websites up-to-date and running smoothly. Upgrade to Smart Updates today.";
$_LANG['store']['addon']['wptk']['getStartedToday'] = "Get started with WP Toolkit Deluxe today!";
$_LANG['store']['addon']['wptk']['smartUpdates']['getStartedToday'] = "Get started with Smart Updates for WP Toolkit today!";
$_LANG['store']['addon']['wptk']['chooseDomains'] = "Choose domains to add:";
$_LANG['store']['addon']['wptk']['addAddonFor'] = "Add :addon for";
$_LANG['store']['addon']['wptk']['unavailable'] = "Not available";
$_LANG['store']['addon']['wptk']['for'] = "for";
$_LANG['store']['addon']['wptk']['totalInCart'] = "Total in cart:";
$_LANG['store']['addon']['wptk']['proceedToCheckout'] = "Proceed to Checkout";
$_LANG['store']['addon']['wptk']['loginToSeePricing'] = "Log in to see pricing to add to your existing hosting";
$_LANG['store']['addon']['wptk']['loginNow'] = "Log In Now";
$_LANG['store']['addon']['wptk']['browsePackages'] = "Browse Hosting Packages";
$_LANG['store']['addon']['wptk']['faqQ1'] = "What is WP Toolkit?";
$_LANG['store']['addon']['wptk']['faqA1'] = "WP Toolkit is a management interface for Wordpress from cPanel and Plesk that allows you to install, configure, and manage WordPress websites.";
$_LANG['store']['addon']['wptk']['faqQ2'] = "How is WP Toolkit Deluxe different?";
$_LANG['store']['addon']['wptk']['faqA2'] = "WP Toolkit Deluxe is a paid upgrade with advanced features including plugin and theme management, staging, cloning, Smart Updates and more.";
$_LANG['store']['addon']['wptk']['faqQ3'] = "What is Smart Updates?";
$_LANG['store']['addon']['wptk']['faqA3'] = "Smart Updates automatically tests updates for themes, plugins, languages, and WordPress itself in a completely safe environment at no risk to your live website.";
$_LANG['store']['addon']['wptk']['faqQ4'] = "How much does WP Toolkit cost?";
$_LANG['store']['addon']['wptk']['faqA4'] = "WP Toolkit Deluxe is available as an add-on for applicable hosting packages. To see pricing, please <a href=\":webRoot/login.php\">login</a> to view pricing for your existing domains, or <a href=\":webRoot/register.php\">sign up</a> as a new customer.";
$_LANG['store']['addon']['wptk']['faqQ5'] = "How do I access WP Toolkit?";
$_LANG['store']['addon']['wptk']['faqA5'] = "If you have access, you will find a WP Toolkit icon and link in your cPanel dashboard. For those with WP Toolkit Deluxe, you will also find a login link from the hosting service view within our <a href=\":webRoot/clientarea.php\">client area</a>.";
$_LANG['store']['addon']['wptk']['faqQ6'] = "How much does Smart Updates cost?";
$_LANG['store']['addon']['wptk']['faqA6'] = "Smart Updates is available as an add-on for applicable hosting packages. To see pricing, please <a href=\":webRoot/login.php\">login</a> to view pricing for your existing domains, or <a href=\":webRoot/register.php\">sign up</a> as a new customer.";
$_LANG['store']['addon']['wptk']['faqQ7'] = "How do I access WP Toolkit?";
$_LANG['store']['addon']['wptk']['faqA7'] = "If you have access, you will find a WP Toolkit icon and link in your Plesk dashboard. Smart Updates will be accessible only after purchase.";

$_LANG['store']['addon']['notFound']['productUnavailable'] = "Produit non disponible";
$_LANG['store']['addon']['notFound']['productUnavailableText'] = "Ce produit n'est actuellement pas disponible.<br>Merci de nous contacter si vous pensez qu'il s'agit d'une erreur.";
$_LANG['store']['addon']['notFound']['contactSupport'] = "Contacter le support";
$_LANG['store']['addon']['notFound']['ref'] = "Ref";

$_LANG['ox']['intro'] = "Here, you can create and manage users, mailboxes, and aliases for your OX App Suite subscription.";
$_LANG['ox']['accountCount'] = "Vous avez créé <span class=\"number\">:number</span> sur <span class=\"limit\">:limit</span> comptes disponibles.";
$_LANG['ox']['refresh'] = "Rafraîchir";
$_LANG['ox']['emailActions'] = "Gestion des e-mails";
$_LANG['ox']['createUser'] = "Créer un utilisateur";
$_LANG['ox']['emailAccounts'] = "Comptes e-mail";
$_LANG['ox']['emailAddress'] = "Adresse e-mail";
$_LANG['ox']['mailboxSize'] = "Taille de la boîte aux lettres";
$_LANG['ox']['setPassword'] = "Définir le mot de passe";
$_LANG['ox']['delete'] = "Supprimer";
$_LANG['ox']['noAccounts'] = "Aucun compte existant";
$_LANG['ox']['accountRequired'] = "Le champ du compte est obligatoire";
$_LANG['ox']['passwordRequired'] = "Le champ du mot de passe est obligatoire";
$_LANG['ox']['deleteAccount'] = "Supprimer le compte <span class=\"email\"></span>?";
$_LANG['ox']['manageAccount'] = "Gérer le compte <span class=\"email\"></span>";
$_LANG['ox']['setPasswordFor'] = "Définir le mot de passe pour <span class=\"email\"></span>";
$_LANG['ox']['deleteAccountQuestion'] = "Êtes-vous sûr de vouloir supprimer ce compte?";
$_LANG['ox']['deleteAccountWithAliasesQuestion'] = "Are you sure you want to delete this account and any aliases?";
$_LANG['ox']['settings']['retrieval'] = "Paramètres de récupération";
$_LANG['ox']['settings']['retrievalIntro'] = "Pour configurer votre compte de messagerie dans une application de messagerie, utilisez les informations ci-dessous.";
$_LANG['ox']['settings']['usageInstructions'] = "Instructions d'utilisation";
$_LANG['ox']['settings']['username'] = "Nom d'utilisateur";
$_LANG['ox']['settings']['email'] = "Utiliser l'adresse e-mail du compte";
$_LANG['ox']['settings']['password'] = "Utilisez le mot de passe du compte";
$_LANG['ox']['settings']['incoming'] = "Serveur entrant (IMAP)";
$_LANG['ox']['settings']['pop'] = "Serveur entrant (POP3)";
$_LANG['ox']['settings']['outgoing'] = "Serveur sortant";
$_LANG['ox']['settings']['port'] = "Port : :port";
$_LANG['ox']['settings']['davSettings'] = "Calendriers et contacts";
$_LANG['ox']['settings']['davSettingsIntro'] = "Pour accéder à vos calendriers et contacts sur vos appareils personnels, vous devez configurer votre logiciel client pour qu'il se connecte à CalDAV pour les calendriers et CardDAV pour les contacts. Utilisez les informations ci-dessous pour configurer votre client.";
$_LANG['ox']['settings']['caldavPassword'] = "Saisissez le même mot de passe que celui que vous utilisez pour votre connexion par e-mail.";
$_LANG['ox']['settings']['serverUrl'] = "URL du serveur";
$_LANG['ox']['settings']['migrationTitle'] = "Outil de migration";
$_LANG['ox']['settings']['migrationIntro'] = "Migrez de tous les services de messagerie électronique courants, notamment Apple iCloud, Gmail, Outlook.com/Windows Live/Hotmail, Yahoo Mail, GMX ou T-Online, ou saisissez manuellement les informations de votre fournisseur en utilisant IMAP/POP3 ou un autre protocole disponible.";
$_LANG['ox']['settings']['migrationLaunch'] = "Démarrer l'outil de migration";
$_LANG['ox']['displayName'] = "Nom d'affichage";
$_LANG['ox']['required']['displayName'] = "Le nom d'affichage est un champ obligatoire.";
$_LANG['ox']['required']['firstName'] = "Le prénom est un champ obligatoire.";
$_LANG['ox']['required']['lastName'] = "Le nom de famille est un champ obligatoire.";
$_LANG['ox']['required']['email'] = "L'adresse e-mail est un champ obligatoire.";
$_LANG['ox']['required']['password'] = "Le mot de passe est un champ obligatoire.";
$_LANG['ox']['required']['passwordMatchMissing'] = "La confirmation du mot de passe est un champ obligatoire.";
$_LANG['ox']['required']['passwordMatch'] = "Le mot de passe de confirmation doit correspondre au mot de passe.";
$_LANG['ox']['accessSuite'] = "Portail en ligne";
$_LANG['ox']['accountDeleted'] = "Le compte a bien été supprimé.";
$_LANG['ox']['accountCreated'] = "Compte créé avec succès.";
$_LANG['ox']['accountModified'] = "Compte modifié avec succès.";
$_LANG['ox']['passwordChanged'] = "Le mot de passe du compte a bien été modifié.";
$_LANG['ox']['alias']['intro'] = "Email aliases act as additional email addresses from which you can send and receive mail.";
$_LANG['ox']['alias']['emailAliases'] = "Email Aliases";
$_LANG['ox']['alias']['deleteTitle'] = "Delete alias <span class=\"alias\"></span>@:domain?";
$_LANG['ox']['alias']['deleteQuestion'] = "Are you sure you want to delete this alias?";
$_LANG['ox']['alias']['deleteSuccess'] = "Alias deleted successfully.";
$_LANG['ox']['alias']['createButton'] = "Create";
$_LANG['ox']['alias']['createSuccess'] = "Alias created successfully.";

$_LANG['orderForm']['upgradeQuantityCannotBeLowerThanMinimum'] = "La quantité de service ne peut pas être modifiée en dessous du minimum (:minimum).";
$_LANG['orderForm']['upgradeQuantityMustChange'] = "Vous devez choisir une mise à niveau du plan ou modifier la quantité.";
$_LANG['orderForm']['downgradeNotPossible'] = "Il n'est pas possible de rétrograder ce produit. Veuillez plutôt passer une nouvelle commande pour ce service.";
$_LANG['unavailable'] = "Indisponible";
$_LANG['orderForm']['idnNotEnabled'] = "Nous ne prenons pas en charge les noms de domaine internationaux pour le moment. Veuillez essayer un autre nom de domaine.";

$_LANG['store']['ssl']['landingPage']['secureInMinutes'] = "Sécurisez votre site en quelques minutes grâce à notre déploiement entièrement automatisés";
$_LANG['store']['fromJust'] = "à partir de";
$_LANG['store']['forJust'] = "jusqu'à";

$_LANG['goCardless']['paymentPending'] = "Un paiement a été envoyé et sera traité par votre banque le :date. <br>Un e-mail de confirmation de paiement vous sera envoyé une fois le paiement traité.";
$_LANG['goCardless']['automaticPayment'] = "Il existe une configuration de paiement automatique pour ce compte. Aucun paiement manuel n'est requis.";

$_LANG['contactDetails'] = "Détails du contact";
$_LANG['createNewSupportRequest'] = "Créer une nouvelle demande d'assistance";

$_LANG['nonotifications'] = "Aucune notification";
$_LANG['apply'] = "Appliquer";
$_LANG['admin']['returnToAdmin'] = "Revenir à l'administration";
$_LANG['searchOurKnowledgebase'] = "Rechercher dans notre base de connaissances";
$_LANG['browseProducts'] = "Parcourir les produits";
$_LANG['secureYourDomain'] = "Sécurisez votre nom de domaine en l'enregistrant aujourd'hui";
$_LANG['secureYourDomainShort'] = "Sécurisez votre nom de domaine";
$_LANG['transferYourDomain'] = "Transférez votre domaine";
$_LANG['transferExtend'] = "Transférez maintenant pour étendre votre domaine d'un an";
$_LANG['howCanWeHelp'] = "Comment pouvons-nous aider aujourd'hui";
$_LANG['homepage']['submitTicket'] = "Soumettre un ticket";
$_LANG['homepage']['manageServices'] = "Gérer les services";
$_LANG['homepage']['manageDomains'] = "Gérer les domaines";
$_LANG['homepage']['supportRequests'] = "Demandes d'assistance";
$_LANG['homepage']['makeAPayment'] = "Effectuer un paiement";
$_LANG['homepage']['yourAccount'] = "Votre compte";

$_LANG['downloads']['numDownload'] = ":num Fichier";
$_LANG['downloads']['numDownloads'] = ":num Fichiers";
$_LANG['knowledgebase']['numArticle'] = ":num Article";
$_LANG['knowledgebase']['numArticles'] = ":num Articles";

$_LANG['userLogin']['createAccount'] = "Créer un compte";
$_LANG['userLogin']['signInToContinue'] = "Connectez-vous à votre compte pour continuer.";
$_LANG['userLogin']['notRegistered'] = "Pas enregistré?";

$_LANG['networkIssues']['scheduled'] = "Il y a :count Problèmes programmés impactant le réseau.";
$_LANG['networkIssues']['http'] = "HTTP";
$_LANG['networkIssues']['ftp'] = "FTP";
$_LANG['networkIssues']['pop3'] = "POP3";
$_LANG['networkIssues']['affectingYou'] = "Ce problème affecte un serveur qui peut avoir un impact sur vos services";

$_LANG['chooseFile'] = "Choisir le fichier";
$_LANG['support']['postedBy'] = "Ajouté par :name le :date :requestorType";

$_LANG['requestor'] = "Demandeur";

$_LANG['facebook']['notAuthorized'] = "Vous n'avez pas autorisé l'utilisation de Facebook pour l'authentification. Nous ne pouvons pas l'utiliser pour vous connecter.";

$_LANG['navMarketConnectService']['siteBuilder'] = "Site Builder";
$_LANG['marketConnect']['siteBuilder']['ftpHost'] = "Hôte FTP";
$_LANG['marketConnect']['siteBuilder']['ftpUsername'] = "Utilisateur FTP";
$_LANG['marketConnect']['siteBuilder']['ftpPassword'] = "Mot de passe FTP";
$_LANG['marketConnect']['siteBuilder']['ftpPath'] = "Chemin FTP";
$_LANG['marketConnect']['siteBuilder']['updateFtp'] = "Mettre à jour les identifiants FTP";
$_LANG['marketConnect']['siteBuilder']['manage'] = "Se connecter à Site Builder";
$_LANG['store']['siteBuilder']['upgrade']['title'] = "Mise à jour Site Builder";
$_LANG['store']['siteBuilder']['upgrade']['required'] = "Mise à jour requise";
$_LANG['store']['siteBuilder']['upgrade']['requiredDescription'] = "Pour utiliser à la foncitonnalité désirée, vous devez mettre à jour votre plan Site Builder.";
$_LANG['store']['siteBuilder']['upgrade']['recommended'] = "Le plan recommandé est affiché.";
$_LANG['store']['siteBuilder']['upgrade']['login'] = "Merci de vous connecter pour voir les options disponibles.";
$_LANG['store']['siteBuilder']['upgrade']['no'] = "Aucune mise à jour disponible";
$_LANG['store']['siteBuilder']['upgrade']['noUpgrade'] = "Il n'y a aucune mise à jour disponible actuellement.";
$_LANG['store']['siteBuilder']['upgrade']['submitTicket'] = "Contacter le support";
$_LANG['store']['siteBuilder']['upgrade']['to'] = "Mettre à jour :product pour :amount";
$_LANG['store']['siteBuilder']['upgrade']['noPlans'] = "Aucun plan Site Builder actif trouvé.";
$_LANG['store']['siteBuilder']['upgrade']['loggedInAs'] = "Vous êtes actuellement connecté en tant que :email";
$_LANG['store']['siteBuilder']['upgrade']['switchUser'] = "Déconnecté/Changer utilisateur";

$_LANG['domainRenewal']['freeWithService'] = "Renouvellement gratuit avec le service";
$_LANG['domainRenewal']['freeWithServiceDesc'] = "Le renouvellement est fourni automatiquement sans frais supplémentaires quand le service associé est actif.";

$_LANG['store']['siteBuilder']['title'] = "Site Builder";
$_LANG['store']['siteBuilder']['introHeadline'] = "Votre voyage en ligne <br class=\"hidden-xs\">commence ici.";
$_LANG['store']['siteBuilder']['intro1'] = "La création d'une présence web requiert la bonne plateforme. Faites-vous remarquer grâce à notre DIY Site Builder par glisser-déposer.";
$_LANG['store']['siteBuilder']['intro2'] = "Que vous souhaitiez faire votre promotion ou celle de votre entreprise, notre constructeur de site est un modèle et un assistant au contenu guidé. Il est suffisamment simple pour les débutants et riche en fonctionnalités pour les professionnels. Il ressemble à PowerPoint mais avec plus de muscle, d'élégance et de simplicité. Une solution que vous aurez plaisir à utiliser.";
$_LANG['store']['siteBuilder']['featuresTitle'] = "Les fonctionnalités Site Builder";
$_LANG['store']['siteBuilder']['featuresEssentials'] = "Les essentielles";
$_LANG['store']['siteBuilder']['featuresSocial'] = "Réseaux sociaux et blogue";
$_LANG['store']['siteBuilder']['featuresStore'] = "Magasin en ligne";
$_LANG['store']['siteBuilder']['features']['essentials']['tagline'] = "Notre Site Builder inclu le set complet de fonctionnalité.";
$_LANG['store']['siteBuilder']['features']['blog']['tagline'] = "Partager votre histoire fait toute la différence. Connectez-vous à vos visiteurs via les réseaux sociaux et votre blogue.";
$_LANG['store']['siteBuilder']['features']['store']['tagline'] = "Les ventes en ligne peuvent dynamiser vos affaire. Construisez site web comme un magasin, une boutique ou une enseigne.";
$_LANG['store']['siteBuilder']['features']['essentials']['1'] = "Éditeur par glisser/déposer";
$_LANG['store']['siteBuilder']['features']['essentials']['2'] = "Fonctions de construction";
$_LANG['store']['siteBuilder']['features']['essentials']['3'] = "Blocs construction préconçus";
$_LANG['store']['siteBuilder']['features']['essentials']['4'] = "Intégration version mobile";
$_LANG['store']['siteBuilder']['features']['essentials']['5'] = "Intégration collection photos";
$_LANG['store']['siteBuilder']['features']['essentials']['6'] = "Enreg. et sauvegarde automatique";
$_LANG['store']['siteBuilder']['featuresdescriptions']['essentials']['1'] = "L'éditeur par glisser/déposer permet aux clients d'ajouter et d'organiser les éléments du site Web directement sur la page, avec une mise en évidence prédictive des zones de placement.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['essentials']['2'] = "Vous pouvez utiliser des éléments de mise en page prêts à l'emploi tels que du texte, des boutons, des photos ou des icônes, pour créer une mise en page de site Web personnalisée et professionnelle.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['essentials']['3'] = "Ne perdez plus de temps à manipuler des mises en page de contenu. Une collection de plus de 350 blocs de contenu vous aide à créer des sites Web professionnels sans aucune compétence technique.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['essentials']['4'] = "Les sites web seront top sur tous les appareils. Les modèles sont 100% responsive pour tous les appareils, y compris les smartphones, tablettes et ordinateurs de bureau.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['essentials']['5'] = "Dynamisez votre site Web grâce à une sélection de plus de 200 000 photos professionnelles de qualité supérieure en haute résolution. Notre créateur de site comprend également l'optimistation des images et vidéos intégrées.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['essentials']['6'] = "Vous pouvez être sûr de ne perdre aucun travail grâce à la sauvegarde en temps réel. L'éditeur enregistre automatiquement tout pendant que vous travaillez.";
$_LANG['store']['siteBuilder']['features']['blog']['1'] = "Page de blogue";
$_LANG['store']['siteBuilder']['features']['blog']['2'] = "Brouillon d'article";
$_LANG['store']['siteBuilder']['features']['blog']['3'] = "Éditeur d'article";
$_LANG['store']['siteBuilder']['features']['blog']['4'] = "Partage sociaux";
$_LANG['store']['siteBuilder']['features']['blog']['5'] = "Commentaires et Likes Facebook";
$_LANG['store']['siteBuilder']['features']['blog']['6'] = "Instagram and Twitter Connect";
$_LANG['store']['siteBuilder']['featuresdescriptions']['blog']['1'] = "Share your story and connect with your visitors by adding a customizable blog to your website. Configure post appearance on your published website.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['blog']['2'] = "Create your blog post now to save and publish later to coincide with specific news or a special promotion.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['blog']['3'] = "Make changes to a blog post after it has already been published using the built-in post content authoring tool and editor.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['blog']['4'] = "Encourage your visitors to like and share your content by adding icons for social media platforms such as Facebook, Twitter, LinkedIn and Pinterest to your site.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['blog']['5'] = "Give visitors the option to comment and like your linked Facebook page without leaving your website.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['blog']['6'] = "Automatically showcase your Instagram photos on your website every time you post and keep your site visitors updated by displaying a live feed of your Twitter account.";
$_LANG['store']['siteBuilder']['features']['store']['1'] = "Flexible Plans";
$_LANG['store']['siteBuilder']['features']['store']['2'] = "Secure and Worldwide Payments";
$_LANG['store']['siteBuilder']['features']['store']['3'] = "Easy and Quick Checkout";
$_LANG['store']['siteBuilder']['features']['store']['5'] = "Product Listing and Management";
$_LANG['store']['siteBuilder']['features']['store']['6'] = "Promotions, Discounts and Coupons";
$_LANG['store']['siteBuilder']['features']['store']['7'] = "Stock Management";
$_LANG['store']['siteBuilder']['features']['store']['8'] = "Worldwide Shipping";
$_LANG['store']['siteBuilder']['features']['store']['9'] = "Tax and VAT";
$_LANG['store']['siteBuilder']['features']['store']['10'] = "Order Management and Tracking";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['1'] = "Whether you’re a boutique, shop, or full store, plans available for 10, 50, and 500 products.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['2'] = "Connect with Paypal, Square, Stripe and over 50 trusted credit card payment providers to instantly accept credit cards.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['3'] = "Give customers a faster and easier checkout with optional registration during check out. Provide a secure one-page checkout that includes customer order comments.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['5'] = "Choose from multiple product page layouts and customize the descriptions and designs as you wish. Make it easier for customers to find products by organizing them into categories.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['6'] = "Create discount coupons or promotional codes to increase sales. Increase your conversions by showing regular prices alongside discounted prices.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['7'] = "Inventory tracking helps to know if it’s time to replenish a product stock and what product variations are the most popular.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['8'] = "You can give your customers real-time carrier rates at checkout by connecting your online store with a carrier company such as USPS, FedEx, UPS, Australia Post, Canada Post, etc.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['9'] = "Apply tax calculations for any country or define specific zones. Fully control the calculation of taxes; set up taxes per location, add tax per group of products, or setup tax-free products.";
$_LANG['store']['siteBuilder']['featuresdescriptions']['store']['10'] = "Instantly receive order notifications via email. Manage and view an overview of all orders, search for orders, filter them by categories and update orders, customer information and add tacking number for shipping.";
$_LANG['store']['siteBuilder']['viewPricing'] = "View pricing and packages";
$_LANG['store']['siteBuilder']['templatesTitle'] = "Business Accelerating Templates";
$_LANG['store']['siteBuilder']['templatesOutro'] = "Get Site Builder to view all 150+ templates that give you a quick and easy way to get started.";
$_LANG['store']['siteBuilder']['tryFree'] = "Try Site Builder for FREE";
$_LANG['store']['siteBuilder']['tryFreeIntro'] = "With the Open Trial, you can try Site Builder and fully build your new website for FREE with no upfront costs.";
$_LANG['store']['siteBuilder']['tryFreeIntro2'] = "Pay nothing until you're ready to publish!";
$_LANG['store']['siteBuilder']['tryFreeCta'] = "Try Site Builder today for FREE";
$_LANG['store']['siteBuilder']['pricingTitle'] = "Pricing";
$_LANG['store']['siteBuilder']['featuresLabelTitle'] = "Features";
$_LANG['store']['siteBuilder']['featuresLabels']['0'] = "Professional Quality Website Templates";
$_LANG['store']['siteBuilder']['featuresLabels']['1'] = "User-First Design for All Skill Levels";
$_LANG['store']['siteBuilder']['featuresLabels']['2'] = "Easy Drag & Drop Editing";
$_LANG['store']['siteBuilder']['featuresLabels']['3'] = "Responsive to Mobile Devices";
$_LANG['store']['siteBuilder']['featuresLabels']['4'] = "Free Image Gallery";
$_LANG['store']['siteBuilder']['featuresLabels']['5'] = "Component Based Building Blocks";
$_LANG['store']['siteBuilder']['featuresLabels']['6'] = "Blog";
$_LANG['store']['siteBuilder']['featuresLabels']['7'] = "Auto Layouts for Proportional Spacing";
$_LANG['store']['siteBuilder']['featuresLabels']['8'] = "Contact Form Builder";
$_LANG['store']['siteBuilder']['featuresLabels']['9'] = "Restore Websites";
$_LANG['store']['siteBuilder']['featuresLabels']['10'] = "Theme Inheritance";
$_LANG['store']['siteBuilder']['featuresLabels']['11'] = "Social Media Integration";
$_LANG['store']['siteBuilder']['featuresLabels']['12'] = "SEO Friendly";
$_LANG['store']['siteBuilder']['featuresLabels']['13'] = "Built-In Analytics";
$_LANG['store']['siteBuilder']['featuresLabels']['14'] = "Pages";
$_LANG['store']['siteBuilder']['featuresLabels']['15'] = "E-Commerce Products";
$_LANG['store']['siteBuilder']['compareTitle'] = "How does our Site Builder compare<br class=\"hidden-xs\">with competitors?";
$_LANG['store']['siteBuilder']['compare1'] = "User-First Design for all Skill Levels";
$_LANG['store']['siteBuilder']['compare1desc'] = "Designed for simplicity and ease-of-use mean higher CSS (Customer Satisfaction Scores) and a better user experience.";
$_LANG['store']['siteBuilder']['compare2'] = "Responsive to Mobile Devices";
$_LANG['store']['siteBuilder']['compare2desc'] = "Saves a lot of time and effort when creating a website for different mobile devices.";
$_LANG['store']['siteBuilder']['compare3'] = "Component-Based Building Blocks";
$_LANG['store']['siteBuilder']['compare3desc'] = "The Pre-designed Building Blocks will help you build professional websites without wasting time manipulating content layouts.";
$_LANG['store']['siteBuilder']['compare4'] = "No Coding required";
$_LANG['store']['siteBuilder']['compare4desc'] = "SiteBuilder is not targeting professional coders. Our aim is to provide SMEs with a platform that anybody can use to create elegant websites that work on any device, in minutes.";
$_LANG['store']['siteBuilder']['compare5'] = "Pay less for more";
$_LANG['store']['siteBuilder']['compare5desc'] = "Half the price of other website builder tools but receive all the benefits and better features.";

$_LANG['store']['siteBuilder']['templates']['singlePage'] = "Single Page Templates";
$_LANG['store']['siteBuilder']['templates']['multiPage'] = "Multi-Page Templates";
$_LANG['store']['siteBuilder']['templates']['eCommerce'] = "e-Commerce Templates";
$_LANG['store']['siteBuilder']['templates']['typeLabels']['single'] = "Single Page";
$_LANG['store']['siteBuilder']['templates']['typeLabels']['multi'] = "Multi-Page";
$_LANG['store']['siteBuilder']['templates']['typeLabels']['ecom'] = "e-Commerce";
$_LANG['store']['siteBuilder']['templates']['barber-shop'] = "Barber Shop";
$_LANG['store']['siteBuilder']['templates']['bike-event'] = "Bike Event";
$_LANG['store']['siteBuilder']['templates']['childcare'] = "Childcare";
$_LANG['store']['siteBuilder']['templates']['conference'] = "Conference";
$_LANG['store']['siteBuilder']['templates']['creative-portfolio'] = "Creative Portfolio";
$_LANG['store']['siteBuilder']['templates']['dj'] = "DJ";
$_LANG['store']['siteBuilder']['templates']['gardener'] = "Gardener";
$_LANG['store']['siteBuilder']['templates']['makeup-artist'] = "Makeup Artist";
$_LANG['store']['siteBuilder']['templates']['painters'] = "Painters";
$_LANG['store']['siteBuilder']['templates']['landscape-photographer'] = "Landscape Photographer";
$_LANG['store']['siteBuilder']['templates']['rock-band'] = "Rock Band";
$_LANG['store']['siteBuilder']['templates']['seafood-restaurant'] = "Seafood Restaurant";
$_LANG['store']['siteBuilder']['templates']['sushi-restaurant'] = "Sushi Restaurant";
$_LANG['store']['siteBuilder']['templates']['tailor-shop'] = "Tailor Shop";
$_LANG['store']['siteBuilder']['templates']['training-courses'] = "Training Courses";
$_LANG['store']['siteBuilder']['templates']['travel-tours'] = "Travel Tours";
$_LANG['store']['siteBuilder']['templates']['wedding-planner'] = "Wedding Planner";
$_LANG['store']['siteBuilder']['templates']['writer'] = "Writer";
$_LANG['store']['siteBuilder']['templates']['architect'] = "Architect";
$_LANG['store']['siteBuilder']['templates']['beauty-salon'] = "Beauty Salon";
$_LANG['store']['siteBuilder']['templates']['biography'] = "Biography";
$_LANG['store']['siteBuilder']['templates']['blog-page'] = "Blog Page";
$_LANG['store']['siteBuilder']['templates']['burger-cafe'] = "Burger Cafe";
$_LANG['store']['siteBuilder']['templates']['car-dealer'] = "Car Dealer";
$_LANG['store']['siteBuilder']['templates']['catering-services'] = "Catering Services";
$_LANG['store']['siteBuilder']['templates']['city-hotel'] = "City Hotel";
$_LANG['store']['siteBuilder']['templates']['cleaning-services'] = "Cleaning Services";
$_LANG['store']['siteBuilder']['templates']['coffee-house'] = "Coffee House";
$_LANG['store']['siteBuilder']['templates']['crossfit'] = "Crossfit";
$_LANG['store']['siteBuilder']['templates']['dentist-v2'] = "Dentist";
$_LANG['store']['siteBuilder']['templates']['event-venue'] = "Event Venue";
$_LANG['store']['siteBuilder']['templates']['handyman'] = "Handyman";
$_LANG['store']['siteBuilder']['templates']['life-coach'] = "Life Coach";
$_LANG['store']['siteBuilder']['templates']['local-cafe'] = "Local Cafe";
$_LANG['store']['siteBuilder']['templates']['locksmith'] = "Locksmith";
$_LANG['store']['siteBuilder']['templates']['mobile-app'] = "Mobile App";
$_LANG['store']['siteBuilder']['templates']['mortgage-brokers'] = "Mortgage Brokers";
$_LANG['store']['siteBuilder']['templates']['photographer'] = "Photographer";
$_LANG['store']['siteBuilder']['templates']['real-estate'] = "Real Estate";
$_LANG['store']['siteBuilder']['templates']['spa'] = "Spa";
$_LANG['store']['siteBuilder']['templates']['villa-rental'] = "Villa Rental";
$_LANG['store']['siteBuilder']['templates']['wedding-event'] = "Wedding Event";
$_LANG['store']['siteBuilder']['templates']['animal-groomers'] = "Animal Groomers";
$_LANG['store']['siteBuilder']['templates']['bakery'] = "Bakery";
$_LANG['store']['siteBuilder']['templates']['beauty-store'] = "Beauty Store";
$_LANG['store']['siteBuilder']['templates']['blinds'] = "Blinds";
$_LANG['store']['siteBuilder']['templates']['bookstore'] = "Bookstore";
$_LANG['store']['siteBuilder']['templates']['furniture-collection'] = "Furniture Collection";
$_LANG['store']['siteBuilder']['templates']['grape-farm'] = "Grape Farm";
$_LANG['store']['siteBuilder']['templates']['grocery-store'] = "Grocery Store";
$_LANG['store']['siteBuilder']['templates']['home-decor'] = "Home Decor";
$_LANG['store']['siteBuilder']['templates']['toy-store'] = "Toy Store";
$_LANG['store']['siteBuilder']['templates']['tyre-repairs'] = "Tyre Repairs";

$_LANG['marketConnect']['siteBuilder']['buildWebsite'] = "Construisez votre site web";
$_LANG['store']['siteBuilder']['cartTitle'] = "Responsive site builder";
$_LANG['store']['siteBuilder']['cartShortDescription'] = "Add our site builder to your order to create an awesome looking website, store or blog.";

$_LANG['clickHere'] = "Cliquez ici";
$_LANG['buy'] = "Acheter";
$_LANG['viewMore'] = "Voir plus...";

$_LANG['store']['siteBuilder']['promo']['sidebar']['title'] = "Ajouter Site Builder";
$_LANG['store']['siteBuilder']['promo']['sidebar']['body'] = "Créer rapidement votre site web avec Site Builder";

$_LANG['cPanel']['wptk'] = "WordPress Toolkit";

$_LANG['wptk']['goToWebsite'] = "Go to Website";
$_LANG['wptk']['goToAdmin'] = "Admin";
$_LANG['wptk']['createNew'] = "Create New";
$_LANG['wptk']['installationSuccess'] = "<strong>Success!</strong> <a href=\"\" target=\"_blank\" id=\"newWordPressLink\">Visit</a> your new WordPress® install, or go to the <a href=\"\" target=\"_blank\" id=\"newWordPressAdminLink\">Admin Area</a>.";
$_LANG['wptk']['installWordPress'] = "Install WordPress®";
$_LANG['wptk']['installWordPressShort'] = "Install";

$_LANG['api']['client']['countryError'] = "Pays valide requis";

$_LANG['plesk']['mail'] = "Mail";
$_LANG['plesk']['applications'] = "Applications";
$_LANG['plesk']['statistics'] = "Statistics";
$_LANG['plesk']['users'] = "Users";
$_LANG['plesk']['manageDomains'] = "Manage Domains";

$_LANG['contactCreated'] = "Contact created successfully!";
$_LANG['contactUpdated'] = "Contact updated successfully!";
$_LANG['contactDeleted'] = "Contact deleted successfully!";
$_LANG['recommended'] = "Recommended";

$_LANG['ssl']['siteSeal'] = "Site Seal";
$_LANG['ssl']['getSiteSeal'] = "Get Site Seal Code";
$_LANG['ssl']['copyTheSiteSeal'] = "Copy your site seal code from the text below:";
$_LANG['ssl']['howToUseSiteSeal'] = "How to Use the Site Seal Code";
$_LANG['ssl']['siteSealError1'] = "You can only retrieve the seal HTML code after the certificate authority issues the certificate.";
$_LANG['ssl']['sealSuccess'] = "Your site seal code has been successfully retrieved.";
$_LANG['ssl']['rapidSslInstructions'] = "Copy the HTML image tag to your HTML document in the location in which you want the RapidSSL seal to display.";
$_LANG['ssl']['siteSealInstructions1'] = "Copy the DigiCert Seal HTML section and paste it into your HTML document in the location in which you want your site seal to display.";
$_LANG['ssl']['siteSealInstructions2'] = "Copy the DigiCert Seal Code section and paste it into the HEAD section of your HTML document.";
$_LANG['ssl']['certError1'] = "You can only retrieve the certificate after the certificate authority issues it.";
$_LANG['ssl']['certError2'] = "If you submitted the configuration information recently, allow time for the certificate authority to complete security checks and issue the certificate. For DV orders, this is typically under 24 hours. OV and EV certificates may require up to 3–5 days.";
$_LANG['ssl']['certError3'] = "If you continue to see this message, <a href=\"submitticket.php\">contact support</a>.";
$_LANG['ssl']['retrieved'] = "The system successfully retrieved your certificate.";
$_LANG['ssl']['copyCert'] = "Copy your certificate from the text below:";
$_LANG['ssl']['installing'] = "Installing Your Certificate";
$_LANG['ssl']['howToInstall'] = "To install your certificate, upload the certificate above to your server or control panel. The method to do this depends on your hosting environment.";
$_LANG['ssl']['installFurtherInfo'] = "For more information, see the :anchorRapidSSL Installation Support:endAnchor page.";

$_LANG['recommendations']['title']['generic'] = "Recommendations";
$_LANG['recommendations']['title']['addedTo'] = "Added to Cart";
$_LANG['recommendations']['title']['yourOrder'] = "Based on Your Order";
$_LANG['recommendations']['title']['yourProducts'] = "Based on Your Products";
$_LANG['recommendations']['explain']['generic'] = "Based on your order, we recommend:";
$_LANG['recommendations']['explain']['product'] = "Based on this product, we recommend:";
$_LANG['recommendations']['explain']['ordered'] = "Because you ordered <strong>:productName</strong>, we recommend:";
$_LANG['recommendations']['learnMore'] = "Click to learn more.";
$_LANG['recommendations']['productAdded'] = "Product Added";
$_LANG['recommendations']['taglinePlaceholder'] = "A description (tagline) is not available for this product.";

$_LANG['copyToClipboard'] = "Copy to Clipboard";

$_LANG['usagebilling']['metric']['diskSpace'] = "Disk Space";
$_LANG['usagebilling']['metric']['bandwidth'] = "Bandwidth";
$_LANG['usagebilling']['metric']['emailAccounts'] = "Email Accounts";
$_LANG['usagebilling']['metric']['addonDomains'] = "Addon Domains";
$_LANG['usagebilling']['metric']['parkedDomains'] = "Parked Domains";
$_LANG['usagebilling']['metric']['subDomains'] = "Sub Domains";
$_LANG['usagebilling']['metric']['mysqlDatabases'] = "MySQL Databases";
$_LANG['usagebilling']['metric']['mysqlDiskUsage'] = "MySQL Disk Usage";
$_LANG['usagebilling']['metric']['subAccounts'] = "Sub-Accounts";

$_LANG['idna']['emptyLabel'] = "The domain name input is empty.";
$_LANG['idna']['labelTooLong'] = "The domain label has exceeded the maximum length.";
$_LANG['idna']['domainTooLong'] = "The domain has exceeded the maximum length.";
$_LANG['idna']['invalidDomain'] = "The domain is invalid.";
$_LANG['idna']['unknownError'] = "An unknown error occurred.";

$_LANG['domains']['europeanDomainTerms'] = "Important Information Regarding Your Contact Data: We are contractually obligated to share your personal information with the registry for this TLD. We will transfer your personal information to the registry, which may publish it to WHOIS publicly. For details on why we share your personal information, review our privacy policy and the domain registration agreement.";


$_LANG['store']['ssl']['shared']['oneYearPrice'] = "1 Year";
$_LANG['store']['ssl']['shared']['twoYearPrice'] = "2 Years";
$_LANG['store']['ssl']['shared']['threeYearPrice'] = "3 Years";

$_LANG['store']['ssl']['landingPage']['multiYear']['title'] = "Multi-Year SSL Certificates";
$_LANG['store']['ssl']['landingPage']['multiYear']['p1'] = "Multi-year certificates allow you to pay a single discounted price for two or three years of SSL certificate coverage. When you purchase a multi-year SSL certificate, you lock in a single price for up to 3 years of coverage.";
$_LANG['store']['ssl']['landingPage']['multiYear']['p2'] = "Initially, you will receive a certificate that is valid for the Certificate Authority Browser Forum's maximum allowed term (1 year and 1 month) with the right to unlimited certificate reissues during the order period.";
$_LANG['store']['ssl']['landingPage']['multiYear']['p3'] = "Automated reissuance will occur automatically throughout the term to ensure continued protection for your website.";
$_LANG['store']['ssl']['landingPage']['multiYear']['p4'] = "For example, a 2-year SSL certificate order works as follows:";
$_LANG['store']['ssl']['landingPage']['multiYear']['p5'] = "SSL certificates must be revalidated periodically. The maximum certificate lifetime is 13 months, requiring revalidation annually.";
$_LANG['store']['ssl']['landingPage']['multiYear']['benefits']['title'] = "Benefits";
$_LANG['store']['ssl']['landingPage']['multiYear']['benefits']['b1'] = "Enjoy increasing discounts for each year of coverage that you purchase.";
$_LANG['store']['ssl']['landingPage']['multiYear']['benefits']['b2'] = "Remove the hassle of annual billing.";
$_LANG['store']['ssl']['landingPage']['multiYear']['benefits']['b3'] = "Annual validation. Yearly validation of identity in shorter validity certificates prevents potential fraud and spoofing.";
$_LANG['navMarketConnectService']['cpanelseo'] = "cPanel SEO";
$_LANG['marketConnect']['cPanelSEO']['manage'] = "Log in to cPanel SEO";
$_LANG['store']['cPanelSEO']['title'] = "cPanel SEO";
$_LANG['store']['cPanelSEO']['tagline'] = "Be Found Online With :lineBreak cPanel SEO";
$_LANG['store']['cPanelSEO']['getStarted'] = "Get Started";
$_LANG['store']['cPanelSEO']['productTourTitle'] = "Product Tour";
$_LANG['store']['cPanelSEO']['measureResultsTitle'] = "Measurable Results at Your Fingertips";
$_LANG['store']['cPanelSEO']['measureResults1'] = "Let's say you want to grow your business in the next year. You could start by investing some money in an SEO agency, but that seems like an overwhelming task for someone who doesn't have technical skills!";
$_LANG['store']['cPanelSEO']['measureResults2'] = ":startBold Luckily, there is an easier way :endBold: let us ensure that people are finding out what makes YOUR company great from their searches online using cPanel SEO.";
$_LANG['store']['cPanelSEO']['features']['keywords']['title'] = "Keywords";
$_LANG['store']['cPanelSEO']['features']['advisor']['title'] = "Advisor";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['title'] = "Rank Tracker";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['title'] = "Site Audit";
$_LANG['store']['cPanelSEO']['features']['textOptimizer']['title'] = "Text Optimizer";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['title'] = "Benchmarking";
$_LANG['store']['cPanelSEO']['features']['keywords']['line1'] = "A 53M+ keyword database for research and inspiration";
$_LANG['store']['cPanelSEO']['features']['keywords']['bullet1'] = "Get comprehensive keyword data";
$_LANG['store']['cPanelSEO']['features']['keywords']['bullet2'] = "Find out which keywords your website's ranking for";
$_LANG['store']['cPanelSEO']['features']['keywords']['bullet3'] = "Identify promising keywords for better traffic";
$_LANG['store']['cPanelSEO']['features']['keywords']['bullet4'] = "Analyze your competition's keywords and rankings";
$_LANG['store']['cPanelSEO']['features']['keywords']['bullet5'] = "Compare international markets";
$_LANG['store']['cPanelSEO']['features']['keywords']['bullet6'] = "Profit from a 53M+ keyword database";
$_LANG['store']['cPanelSEO']['features']['advisor']['line1'] = "Receive, manage, and solve tasks to improve your website";
$_LANG['store']['cPanelSEO']['features']['advisor']['bullet1'] = "Kanban-style Task Manager";
$_LANG['store']['cPanelSEO']['features']['advisor']['bullet2'] = "Customized and prioritized tasks";
$_LANG['store']['cPanelSEO']['features']['advisor']['bullet3'] = "Detailed instructions and additional information";
$_LANG['store']['cPanelSEO']['features']['advisor']['bullet4'] = "No expert knowledge needed";
$_LANG['store']['cPanelSEO']['features']['advisor']['bullet5'] = "Updated weekly";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['line1'] = "Monitor your rankings and those of your competitors";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['bullet1'] = "Track essential rankings weekly or daily";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['bullet2'] = "Local rankings for brick-and-mortar businesses";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['bullet3'] = "International rankings for global companies";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['bullet4'] = "Keep an eye on your competition";
$_LANG['store']['cPanelSEO']['features']['rankTracker']['bullet5'] = "Track keyword rankings or dedicated pages";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['line1'] = "Check the technical foundation of your website";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['bullet1'] = "Automated weekly site audits";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['bullet2'] = "Technical website check";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['bullet3'] = "Prioritized results";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['bullet4'] = "Shows improvements";
$_LANG['store']['cPanelSEO']['features']['siteAudit']['bullet5'] = "Translated results to advisor tasks";
$_LANG['store']['cPanelSEO']['features']['textOptimizer']['line1'] = "Improve your rankings with data-driven content optimization";
$_LANG['store']['cPanelSEO']['features']['textOptimizer']['bullet1'] = "Compare your text to Amazon™'s and Google™'s top 10 results";
$_LANG['store']['cPanelSEO']['features']['textOptimizer']['bullet2'] = "Increase the content quality in a guided manner";
$_LANG['store']['cPanelSEO']['features']['textOptimizer']['bullet3'] = "Add, increase, or reduce keywords as instructed";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['line1'] = "Analyse competitors, compare performance and improve your SEO";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['bullet1'] = "Discover domains that share rankings for the same keywords";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['bullet2'] = "Identify your niche's leader";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['bullet3'] = "Compare keyword rankings of two or more domains";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['bullet4'] = "Track and compare your competition's rankings for important keywords";
$_LANG['store']['cPanelSEO']['features']['benchmarking']['bullet5'] = "Track and compare visibility scores";
$_LANG['store']['cPanelSEO']['audience']['freelancersTitle'] = "Freelancers";
$_LANG['store']['cPanelSEO']['audience']['freelancersDesc'] = "cPanel SEO was designed to provide immediate value for your personal website or your clients’ sites, from an initial site audit through recommendations to improve your search engine results.";
$_LANG['store']['cPanelSEO']['audience']['smbizTitle'] = "Small and Medium-sized Businesses";
$_LANG['store']['cPanelSEO']['audience']['smbizDesc'] = "You don't have to be an SEO expert to improve your business's Google rankings. cPanel SEO will identify the best keywords for your business while also keeping an eye on the performance of your competitors.";
$_LANG['store']['cPanelSEO']['moneyBackGuarantee'] = "Flexible Pricing Options With :guaranteeStart 30 Day Money Back Guarantee :guaranteeEnd";
$_LANG['store']['cPanelSEO']['featurematrix']['1'] = "Projects";
$_LANG['store']['cPanelSEO']['featurematrix']['2'] = "Full-Access Accounts";
$_LANG['store']['cPanelSEO']['featurematrix']['3'] = "Read-Only Accounts";
$_LANG['store']['cPanelSEO']['featurematrix']['4'] = "Competitor Benchmarking";
$_LANG['store']['cPanelSEO']['featurematrix']['5'] = "Competitors per project";
$_LANG['store']['cPanelSEO']['featurematrix']['6'] = "Keyword Research";
$_LANG['store']['cPanelSEO']['featurematrix']['7'] = "Rank Tracker";
$_LANG['store']['cPanelSEO']['featurematrix']['8'] = "Keyword crawls";
$_LANG['store']['cPanelSEO']['featurematrix']['9'] = "Keyword check";
$_LANG['store']['cPanelSEO']['featurematrix']['10'] = "Site Audit";
$_LANG['store']['cPanelSEO']['featurematrix']['11'] = "Pages to crawl";
$_LANG['store']['cPanelSEO']['featurematrix']['12'] = "SEO Advisor";
$_LANG['store']['cPanelSEO']['featurematrix']['13'] = "SEO Text Optimizer";
$_LANG['store']['cPanelSEO']['faqTitle'] = "Frequently Asked Questions";
$_LANG['store']['cPanelSEO']['faq1'] = "What is SEO?";
$_LANG['store']['cPanelSEO']['faq1ans'] = "<p>SEO is an acronym for Search Engine Optimization. It is an essential online marketing strategy dedicated to driving prospective customers to your website. Its goal is to optimize a website to gain top positions for selected keywords on search engines. This goal is achieved by strategically employing measures to improve the website's technical setup and contents and obtaining backlinks from other domains.</p><p>SEO is divided into three general categories:</p><ol><li>Keywords and rankings</li><li>On-page SEO</li><li>Off-page SEO</li></ol><p>SEO specialists apply measures to meet the search engine's ranking factors for each category. Search engines use ranking factors to determine the position in which it lists a website in search results.</p>";
$_LANG['store']['cPanelSEO']['faq2'] = "Why Do I Need SEO?";
$_LANG['store']['cPanelSEO']['faq2ans'] = "<p>Every day, millions of people use search engines to find information or services from all aspects of life: Recipes, guides, products, flights, navigation, tickets, entertainment, and more. Most people navigate the web using search engines to find answers to their questions and solutions to their challenges.</p><p>A study shows that 68% of the web's traffic comes from search engines. 53% of this traffic has its origins in organic search—search results that are not ads (paid search) and can be improved through SEO.</p><img src=\":image1\"><p>In other words, organic search (SEO) and paid search (SEA, ads in search results) make up the lion's share of traffic on the web.</p><p>Even where we go offline is significantly influenced by search engines: We use Google and Apple Maps and local search results to find places and nearby services like hairdressers, supermarkets, restaurants, and doctors. We choose our destination based on online reviews. And we instruct search engine-based services to guide us there, be it by car, public transportation, or on foot.</p><p>Now, imagine if your business, products, and services are not listed in search results. Imagine people can't find you online to buy your products or find their way to your brick-and-mortar business. Instead, they will most likely choose your competition.</p>";
$_LANG['store']['cPanelSEO']['faq3'] = "What Can SEO Do For Me?";
$_LANG['store']['cPanelSEO']['faq3ans'] = "<p>With the help of SEO, users can find your business, products, and services online—and buy them. As mentioned, that means that people can find you online and much easier offline, too.</p><p>SEO maximizes your chances to be listed in top positions for keywords crucial to your business. The better your position, the more people will find their way to your website—preferably on the first page (or top ten) of search results.</p><p><strong>Why Page One?</strong></p><p>Good question. Studies have shown that 31.7% of users click on the first organic search result (position one); a whopping 75.1% of all clicks go to the top three search results. After that, the number of clicks shrinks rapidly with every following position.</p><img src=\":image2\"><p>This behavior shows that users rarely look at page two or lower results, let alone click on any of them.</p><img src=\":image3\"><p>That's why businesses need to be present on the first page of search results, at least for relevant keywords.</p><p>In short: It's crucial for freelancers and business owners to</p><ol><li>Own a website or any kind of online presence, even if they offer their products or services offline</li><li>Perform SEO to make sure they rank on page one for relevant keywords</li></ol>";
$_LANG['store']['cPanelSEO']['faq4'] = "Why Are Keywords Important?";
$_LANG['store']['cPanelSEO']['faq4ans'] = "<p><em>Keyword</em> is a technical term for search queries (words, phrases, sentences, and questions). With their help, users find content that answers their questions and provides solutions. Put simply, a keyword is the link between users and your website. Search engines compare keywords with websites, looking for content with the highest relevance.</p><p>A big part of SEO lies in identifying keywords that have the potential to drive relevant traffic to your website—in other words, bringing in prospective customers. To do that, you need to identify search terms (or keywords) people use when searching for offers like yours. This process is called keyword research. Ideally, keyword research provides you with a list of keywords covering search queries across the entire customer journey.</p>";
$_LANG['store']['cPanelSEO']['faq5'] = "What Is Keyword Optimization?";
$_LANG['store']['cPanelSEO']['faq5ans'] = "<p>So we know that relevance is a crucial factor for a top position in search results. To create relevant content, you want to deal with the topics and questions around a keyword on an individual subpage or URL. Then, make sure your keyword appears in crucial spots on your page.</p><p>Let's say you are in the ice cream business. One of your keywords is <em>s'mores ice cream sandwich</em>. Now you focus on everything that has to do with a <em>s'mores ice cream sandwich</em>.</p><p>What you want to do is create a recipe page for a <em>s'mores ice cream sandwich</em> where users find an easy-to-follow recipe, pictures or videos, and answers to questions they might have. <em>S'mores ice cream sandwich</em> is your focus keyword that should appear in your page's URL, title, headlines, and more.</p><p>Providing a dedicated and keyword-optimized page makes it easy for search engines—and users, too—to determine what your page is all about. That way, they can list it in good positions in related search results.</p>";
$_LANG['store']['cPanelSEO']['faq6'] = "How to use the Advisor";
$_LANG['store']['cPanelSEO']['faq6ans'] = "<p>First, check out the advisor's board by clicking Advisor in the top navigation bar. It is a Kanban board helping you organize your tasks by status. Your tasks are color coded by importance:</p><ul><li><strong>Red:</strong> High. Solve ASAP.</li><li><strong>Yellow:</strong> Medium. Tackle those soon.</li><li><strong>Blue:</strong> Low. Keep them in mind and solve them when you can.</li></ul><img src=\":image1\"><p>You can drag and drop as you complete tasks, assign tasks to other users (depending on your plan), and filter by the assignee.</p><p>As mentioned above, tasks are a mix of standard basic SEO measures and issues found in weekly automated audits of your website.</p>";
$_LANG['store']['cPanelSEO']['faq7'] = "I want an advisor for other websites. How do I get it?";
$_LANG['store']['cPanelSEO']['faq7ans'] = "<p>Keep in mind that you do need a <em>Project</em> for the Advisor feature to work. Also, most of the Advisor's tasks are tailored to a Project's website (usually yours or your client's). If you manage more than one website, you'll need to create an extra Project for each of them.</p><p>To add or switch to another project, click the <em>Projects</em> menu in the top navigation bar. Depending on your plan, you might need to upgrade it to add another Project.</p>";
$_LANG['store']['cPanelSEO']['faq8'] = "How do I assign tasks to other users?";
$_LANG['store']['cPanelSEO']['faq8ans'] = "<p>To assign a task to other users, you'll need a plan that allows additional users. If your plan includes additional users, you'll find the Assignee menu in your Advisor and tasks. Simply choose a user to assign a task or filter the Advisor by. To add a new user, click on your profile avatar and then click <em>Users</em>. If your plan does not include additional users, you won't see the <em>Assignee</em> menu in your Advisor or tasks. Upgrade your plan to add users.</p>";
$_LANG['store']['cPanelSEO']['faq9'] = "There are tasks I've already covered. Why do they pop up?";
$_LANG['store']['cPanelSEO']['faq9ans'] = "<p>There are two reasons why you might see tasks you've already solved or covered. As mentioned above, tasks are a mix of basic SEO measures and issues found in weekly automated audits of your website.</p><p>First, the tasks covering basic SEO measures are the same for everyone and are not tailored to your website or business. For example, we don't know whether you created a Google account for your business and set up Search Console or if you installed SEO plugins. If you already did—great work! Simply flag those tasks as Done.</p><p>The second reason is that the Advisor is automatically updated based on the results of automated weekly Site Audits. In other words, if a Site Audit identifies any issues concerning a task you completed in the past, it will automatically be updated and pop up in the Open section.</p>";
$_LANG['store']['cPanelSEO']['faq10'] = "What is Project Visibility?";
$_LANG['store']['cPanelSEO']['faq10ans'] = "<p>Maybe you already stopped to think, “Wait, but I don't care about my visibility for keywords that have nothing to do with my business.” And you are right. While Visibility is a great score to get an idea of your overall performance and compare websites in general, it's not tailored to your specific keyword set.</p><p>That's why we provide <em>Project Visibility</em>. This metric is calculated the same way as Visibility, but instead of using 500,000 cross-industry keywords, Project Visibility is exclusively based on keywords in your Rank Tracker.</p><p>In other words, Project Visibility is a custom visibility score for the unique set of keywords relevant to your business.</p><p>You'll find Project Visibility here: <em>Projects → Rank Tracker → Visibility</em>.</p><p>As you might already know, you can also track your competitors' rankings in your Rank Tracker. That way, you'll get Project Visibility for them, too, allowing for a much more realistic comparison. So, even if they have a slightly different product or service portfolio, Project Visibility accounts exclusively for keywords you actually share.</p>";
$_LANG['store']['cPanelSEO']['faq11'] = "Why is Visibility score useful?";
$_LANG['store']['cPanelSEO']['faq11ans'] = "<p>Use your Visibility score as an indicator of your overall SEO performance, problems, and potential for optimization.</p><p><strong>1. Get An Idea of Your Overall SEO Performance</strong></p><p>You can track rankings for single keywords and know which position you rank on. It's an important thing to do. However, rank tracking does not give you a bird's eye view perspective of the overall improvement of your rankings—but Visibility does. When your SEO measures are effective and rankings improve, so does your Visibility score.</p><p><strong>2. Diagnose SEO Problems</strong></p><p>A sudden drop in your Visibility indicates problems in your SEO performance. Use Visibility like an alert. If it drops significantly, start digging for what happened. Here's a list of common reasons:</p><ul><li>You were hit with a <strong>Google Penalty</strong>. Check Search Console for notifications. Make sure to follow <a href=\":googleWebmasterGuidelinesUrl\" target=\"_blank\">Google's Webmaster Guidelines</a>.</li><li>There are ramifications from a recent change in Google's algorithm. Inquire about recent <strong>Google Updates</strong> and what they entail.</li><li>Your competitors optimized their websites and content, and now they out-compete you. Compare their (historical) <strong>Visibility</strong> with yours. Use the <a href=\":waybackMachineUrl\" target=\"_blank\">Wayback Machine</a> to compare how their content changed.</li><li>You relaunched your site without SEO in mind. For example, check <em>robots.txt</em> and <em>.htaccess</em> for accidentally blocked pages, increased 404 status codes, faulty 301-redirects, and internal links.<br><br>You changed your content in a way that didn't help your rankings. Consider reversing the changes.<br><br>Your website has technical issues. Run a <em>Site Audit</em> or check your <strong><em>Advisor</em></strong> for open technical tasks. Check your backend for outdated, recently updated, or incompatible <strong>plugins</strong> that may cause havoc.<br><br>Hosting issues are the cause. Inquire whether your host made recent changes, has been hacked, moved their servers, or experienced technical difficulties. See if your server has issues.</li></ul><p>Keep in mind that this list is not exhaustive. One or more of those reasons can apply simultaneously, or there could be other reasons altogether.</p><p><strong>3. Competitor Comparison</strong></p><p>Visibility is a great metric for a quick comparison of two or more websites. Check your Visibility against theirs. Who is out-competing who? Has a competitor outperformed you in the past or vice versa? Who's leading the field, and how big is the gap between you and your fiercest competitor? Answering those questions will help you develop an SEO strategy to come out (and stay) at the top of your niche.</p><p><strong>4. Track Visibility Development Over Time With Historical Data</strong></p><p>Want to know how a website fared over time? We provide historical data going all the way back to 2009, free of seasonal fluctuations. That way, you can track and compare historic Visibility and see their development over long periods of time.</p>";
$_LANG['store']['cPanelSEO']['faq12'] = "How Can I Improve My Visibility Score?";
$_LANG['store']['cPanelSEO']['faq12ans'] = "<p>Short answer: Don't make improving Visibility a goal in your SEO strategy.</p><p>Long answer: Visibility <em>reflects</em> the quality of your rankings in a single metric; it won't lead to better rankings. Make it your goal to improve your rankings for relevant keywords that prospective customers actually use to find products and services like yours. Improving your rankings will improve your Visibility, too. But it's your rankings that really matter.</p><p>As a rule of thumb, your Visibility score will be higher if</p><ul><li>Your domain's URLs rank in good positions</li><li>You have a high number of indexed URLs with good rankings</li><li>You rank well for keywords with a high search volume</li></ul>";
$_LANG['store']['cPanelSEO']['promo']['sidebar']['title'] = "SEO Tools";
$_LANG['store']['cPanelSEO']['promo']['sidebar']['body'] = "Improve your site performance with accurate, reliable, and easy-to-use site rankings, keywords, and an advisor.";
$_LANG['store']['cPanelSEO']['cartTitle'] = "SEO Tools";
$_LANG['store']['cPanelSEO']['cartShortDescription'] = "Improve your site performance with accurate, reliable, and easy-to-use site rankings, keywords, and an advisor.";

////////// End of french language file.  Do not place any translation strings below this line!
