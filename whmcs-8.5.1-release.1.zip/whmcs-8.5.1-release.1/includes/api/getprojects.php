<?php //ICB0 72:0                                                             ?><?php //00ee5
// *************************************************************************
// *                                                                       *
// * WHMCS - The Complete Client Management, Billing & Support Solution    *
// * Copyright (c) WHMCS Ltd. All Rights Reserved,                         *
// * Version:8.5.1 (8.5.1-release.1)                                      *
// * BuildId:82a5460.189                                                  *
// * Build Date:14 Jun 2022                                               *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@whmcs.com                                                 *
// * Website: http://www.whmcs.com                                         *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only  in  accordance  with  the  terms  of such  license and with the *
// * inclusion of the above copyright notice.  This software  or any other *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license.  WHMCompleteSolution may terminate this license if you don't *
// * comply with any of the terms and conditions set forth in our end user *
// * license agreement (EULA).  In such event,  licensee  agrees to return *
// * licensor  or destroy  all copies of software  upon termination of the *
// * license.                                                              *
// *                                                                       *
// * Please see the EULA file for the full End User License Agreement.     *
// *                                                                       *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvmPoBzjmp2m6CzTdEZoHjWBZ9hRp8O3ql9d8lWE0KKJ4B8zXmmF83Qehtt4INgj9FiveoT2
6X1c/54cnh2WW4s0ZtUQH5JOlk06pF0Puo7K+W4AzniqQ9nmTn+QdY5pZJZZT8KTdKAO7rLg3XuZ
OVvmdrQ3WcJqQWIYuntpLGU6lyOONsRz0qykAkX3f2c0TqM5neKO0gs4YZkaWKTlenr5qJIp2tkt
PQArjKhUVFW6qJxeV55MAdgYi+FnxvK5r++05izYFfAnH5jikxhBX/nXAkao7UZ1CVknte23le/w
UAh6WY5l3igA0LUSZuz4/CtuzdnuXJsIMfAqhmr8246iHCW3DdarEx9btta9b9IUkeswDyHD6X80
TokhPM1rujsrBaXxzM+Hd5bjL83vdTFhvQ56niudE8xyoPmEAq0TEkawKdE1WLZOLkWMcNLVgZRU
ueD7grZclKESV/GCU4rqdLbDSGSFrDt6v3ZmfMq58cwNTosmLquGRyMOmqDv8eQTdQ00pDTXLqn8
ZqCVRuTPjcbdYlteBhnp7erczg+Xq/gm6sa0bk+VtlmtdLLdn3iRLWJfHlySoVSijJ+5ET63NULi
UpfUUhlq2Wavyu7pBdczcbafz2ghIetams01/zqV+ByCIipmRc85w9W1zczuFbG/eJkPNmvood5R
tpzRKQzHRSHcxpsLf/9DhVH4lZydp9MGc/KOC+tO6S8pMbeig2fBe/smPe/fy5eRS6kfNRExRKce
ouy7E2kViprsemq1nL9LzI1R5nBkULFhdumC0V/niDRrNFGZOYcGyH0Mkrp7tThDT25oJPaHZh8l
Z2ks15+IO6NYm/2e27V6xesqA6IIEAhHPUOrnphSPT45veoF2qWYd0Zeon+ZFjGAVNetTnfhUfGo
5pk2PpaSuwe1PeU3Oyrfb7cznHRXS8IYgBJ1tcZmMS1R8H9EOa7ya251CpsPQgJoPaFmygR4h2Y7
aWHU4H5ft52cWRv1e2hylYDA+jqCPE5siuTDKHUA0JzCaNMLWmpHbPKzzQZN+IBJBulaBP6aQUVS
LMG7HQyqRf/fFW/ZWedw600NH4ygA8CeoXOBx8x95CnA3jv/mCvjmdMBP9Tnlp6ie25vOHidj8s0
jzI6Io7l2/3ioe6QzZynuzlVRL4GluF1Wnhupsdq5Fr/PzJJlkk6n9v4cgQhnwFkzEsGiwNbp9Dj
zH9dg22tqbLdZ7E5LFC2nj359i+i3EpLGtS1LQm1lQxkAqtEkhh0f3iAU0DrtKcVzPMyrqNM7exU
gI2IuADmgFicPL1kWDuFtPnpMprr5SHw/H4LkwzMo6GHjnACQ6Q3vljKFiGKLt5WR5Ckq7CSNuuv
V/0vbembc2y1zH6vncZt7kyCjJKr2DoVSUDfsKFutiVQEhWDsuSdzZz80d2v6dONU0pCt70m517v
Z5YUCeOcrLvXvBskNIu0v8v3FlCoQbzaVeJs2QdK3mTa3NEU2oW2JAFy3QkqgY/YmsjrPpcTGgT4
i7sujYmU4WPV4ghGh3FHlIWDmhk429kIKfaJY7OGKpsCaI213qYZd9d8QcY5E7SmTCfKpEqhVsV/
CSMtTC7/Ecn2We1iAHzl+qXUq60PJYtnBDFeRgm1o9w1DuZuVBAkiwnJ8gu67Y43dUktlBSx4atX
0KfU+EuTfHBAGcycuFahMCI5Qh7gttuB2/I4lrQgGjvZrrp/lRWBXeOpjVyMN/FP+mGizgdbNxRd
6L6M0Kh31VvHKZIxhoH6k8hIuN9nh8vfz2gFjKD6EbSTmaTWD9pfe+PQesbf/OP7gxtL0PWhuo6p
cJNmhVKd85YzIq+V/7J7XW+raKHfJs7CGrWLQOesCAXdY/MyydlWjTrTLc7oTzQec2ISpH66yUks
gb0u2AiTnz4OEgBLqe4U77qL3M61MskZJuo+R9Uh0BcEJrtdMBgW3MfNHaKccHdlmGWq0oH//Z8K
8O67mNyiJI0Tn7w2nuB9Yb7hN97b96DRYKrA4PscB7fIbQiNPDvhVGMqsV2TRFG3OY8hteB/4yE5
K2nvEUgsGf2Yj4AdqOt1IujBkWX9czWYQzAVgLqquwWRUl/4aBMV8DXdPrPYhf8FhNqlTL4Pb2Gf
0o+bQZIv8bFCiN+CCJsCjCH0yZg8QNb0C4jUbb/5sQGULHNU3dnxBGJEOSYHnv+dcLTeqqVcD1KB
3nFFwrKIPC2j8yOg2XQT/N2wDbhPiL2f2E4E+Z14prE7pbpl5Ac2r5TIHeaCxIHPQ9eu1mDhnMA3
+yhy3arfPA5YfoosQcm/0lpjmTdU7kYQE9KjcyHZBjFkmH+OIDZlSYFHU9zpwvLqJwoMzKBwcXEx
S9eo5LarpMdS9fTHNXlP6aYBI9Wl1efQcPAGlTxej2Ml/eEn6ZFbH+5R/sVPsaQGcNrqwccIp96h
yng7GW1MxEElu6DN959Tolu2CSePBVh00a9ev5cfXGv+r1w2WNswQqm/BFLjcd6+Ia+ddO3W1qIw
+0BLi1/uvLUMUAoBIeHYCHOuB6CIhQY2rdMY+XzMiAIQp44HIOfZtr+2kIlCfmXxtTevSBCB81Ow
ljr7AlHk+axgiJr+McfYlBGlB2nBVRbrRmFnu3ytrlKPk59X1DeEovdi+uD/bqM8Ac0NBXG/7gmI
AI/Kpg0kQ8VyQq956kldH89OhAjRl3jT13FdCHXbTpFiEbKfEIb+YdRDsdxwUxBGU7cMu2eDby19
S4a0cxM0ZuZg0uM4GZlffswTrX9bR/DvJ2wWCyBcg70/B4iv4jAffkNQc9zak51KddASIOGOKgMF
QwbJWr5CX4Vzsb4hz5xdAom+zt3N/NWEWroAeDvRCHxDtvUVEg6/zcVNabuAur+fo1u5wkuOkFKI
gVrzRdxYkKGFv9a8o0K3pYzuclF6J7B9Fve77l3/b6TnVJcoSeY4NUm5q1eSm9Cwy9RnRZBPyPm6
r9oZmLId3kW/3U0Up/jjHrbhfh2lRW+Rv3RsGVqBXFN546QMDVceKt1xL6+1RxceJZ0BsSDD0d1r
htKcz2xH4bL5+1kkq8FgmMvJKdURvN8Lsf4j0QaLPeT/wSHey5TKaJLPMYuS9nfcFpGei+KPN8EN
tHTHxZLmU/tHQxgF0c/gSOVBSC87alBNMqG53p2zpCN9HxbAh0KVx2T99LlR/tP+6oAeha8ZbGWa
b8gHCzZunSVYRjGsKHcMJkQDQLiG1wsfCqgPJKJKAyhoy6jw0qVA8163Qo3LW5KJ72dN9WU0yhm+
LSL8xAgxjM1w+5JbfMeg8XDQGEhtrNgoP3bvagxdhMAqlxcG08N5XUNhPnkSG4yS3nNUDcNZZb0t
fVgZx1TKarh60f+w0P/JIF76XwG2rpyGBpj6wmwQErYhaSEFd/mDnURYcv3PUo460ba03lHeNi8w
IaM00QTAVn4DvpixF/CHqvIEB34tjmCq0fu8b0CH/CpPBWYczZG4umWT/dTt1fhg137oMtOKlkK8
kJAJjcE0UixBy9pwSy/jmB46Ws/35yjCh0L4E596adyivjwJn1bRERsNwVZnysN937E4gt7vtUIx
bAMDyi07M7RL3MhCrBOUh/bLd3V2O7ntNFcIDyMznzMCeA37P/xaeykhLgM00WJcqw05f9oCgok1
LifW7tGx54m95eM/Jl3cieW5v6X3vkTiOD3qHzCU7jIYokHq9rGakFe7lX5PsM6IZ4wZFJ2Fmkoe
Uc7Pe3c7hL8o06/TtgqnY38Dt8P88OTk0MICaR66IN7H0abgzVFGhlqrcLO/cAzx5vreGDAJn33/
ALItZnuR9bpEbn1dNs+xKklHln9WqE/VMuu4bC18z7QotbPPyetnLAA+5KkbRp6negoRaC6y1sJh
cYdbe5KmCzNFFHa6CSoJTjt6c4WEz6H9mE/cHqPIvxGCnM8fH8s0u8BNrbmcQqtJ2zMoAL+7smo5
Rq2JzzBDBq6x8Wod71sxCqMVEIb9oF411OyGxwjF4QrDOEtZ3Bd37oyxxxYBVBXssz/lN9A/Oz2s
UDc2oxX8JjkUbA3PWx8Az4xgDVvX4WN0e+j27gsEWXeSXUuOcOEcqvGK4lBr4jMMQJ8QUyNUdIzB
DRKr6MwQ+MJ3tMdYwKDTaG2JzTKuohAbmQrnFhzUx2Eon92+KOgPt54mNogxsfVNChdmoy4rsZZa
EmcSt3X7Hnyv9eeuV8M5q8qv4FGeXTTr0pjb4cHxhZuTsqrFI1G3n6ywBqbRS9oXO1zthGscxMD7
IiOPdeWqXj1VAMDaKb6Dzyig3jthcM6S5ZYEViBn8Z/Hs/Mn9ETI8JtaEiJKsr6jlX/CceSNBlX6
tWQOAu74nR4Z3V2JTjxLv6L82DGlhTEXQ5WWMI1U3QB1LbKiYu8wjAerSj6FKPVz2vwNG3yxfzG3
LDcR4vM6JOqibD8xCrkyGW/nc3OCX3L7NASe0oTS0+tMQcQXYRtx9ssnZuE7luwPgy6gy556FGnP
Oyj1//pKmVtwjPv4KGPzHN/oma6Ph4RL9TiBWyDepTms55bULmXTp8Li5B00oA7/DMki+xpQPE6F
yLoURboeggfq36ezv8ZoZwlWvRYalXfunb1oKeD6sXH4jReCtrLZpKLhon81bW3VAgKn0VomwqUD
TCrSdcx/2wYNk+jPgP/PLLV9ad/KEeJeP6ShaBakGnNgGzzlXIKU82KRU8QR4hz44PXdnc5Xh+z4
lQjNfoqE5P/yLvagPS9BUbVpzdnr7AzWfCe9GESeBaZYEqjKEyuJL0o26ZJK0OxxoRsCJJdQ1Qaw
7GwTXROMPls5gAl7baO5aBYjCuT/lWyl3pGRutV2zGJ/KbcZRyH01JX/H/RycRrytrdVv24wTgAB
iAqO7xZc4N3al1P1Or0fC5i5B2xNg3jxbJMNQ6Ce5BRXWPZmkadZ/aNvxXbIxwwopy9sZp9kqHuY
DBZgAp5hfx+bevpMWGNX3EHu6KxUfolhlfOb7Tolljs5c1o5+5Ri0+8oXRmxNJ9CbaSG0flQjco4
giO+TMaPQgidesS63e0EcnSasFVjNQGU0dGtD+OteuFDw9fXLZ8IAGbO16AJQ1rAAGbBd3hEXstz
lKKWZDZgQE1bE0dk9V2ffUivSUYK4sHy1Hf7UPuXPo0sbtbZtdunnNfca5nj2EqwJjk4rEIrXfaS
wXLBANRtba1LUEadFanPTQAg075bfAGSiFmrx5LsgQMkUrFN3ftN84eTZWIDFqZqUKrT/B8V4m4K
KkdViGX4pJC9/sf0HWr9oRYtftUAxWWmYa0d1GahyGcVf6Ya2LdMQldAMei6kGEK/NrTYSvCJMi0
7D124dY5pmnMYQ00Y9LFpIuaYyZoaSq9SqHRpzJswSGmfDG/3G5nCq5ufn7tBRkfab7KnrNjkWut
77qUwuYNCD4wDUcPA9p/Xm0EaWXZOQOa90ysu2Uxmd6lrEN0spjO2bnzNVSBCJMPwIFQ8eDtqVsx
rj7mDpASUQtQ2+BljQ5Mf1b8gE7ZatFfQCXV7kFHCdUtkyvwCADsjUQTBcPDtqYy8D1q6gbRgG1B
qhxBEGRrG5r9HEe3yOXfztnFTH9wN2b5NueHAfeSBNzUOPDYP2wEVyXRfwG2Je/94IMET6BdeL+q
w/voBf5oXfrq9lN3N3tV4Q6pD4Ls9FEj338rdlJDrjoqBZK9pj8JPQ51m1QG5hTU4Fpge3aWcZDQ
Eio3WtFGT7OfrqAvs/JT63KBgX2YXxtIdIifDuZbg4bLZ8uOj73wuNKbRkGkZTTXCNyhf58BeCsX
/u+KJi+XEiLCum2e6BlpgKBglG8qKiJEn1w7x7md5iZLS6Ih3/BVbFM1U14SXxweSaKfE1yQ9Y/M
pnjeQx5GBqr7JGVULWP7WaR/Qua5D60LLMYBMu21qGLqaCvh5YLWwlGu3Kq/7gv2HM2Kuivj3mEC
lcVhxvL50Sbn8yiatQEIDumFsodtaaUAoUfGIsp+SgZHlaFGByoz4C63zXH4IcTD1m7I5LrI1z7P
6m+AuRoB//mBJBSEIKxioH3DlhfPYgsNB3wru8G4KD/7tzCL6sN6tfxsQPgR3PjWVlJrjOJHNt3M
M+aQXdh54kpAD9UruHNCoUq7RYQoqjPhgZs7teumUlnEP+o6ovpTDeHL/Zuv45Zz26VLehXwbUTp
A8jm6gg2xKqp7q1NkoKBB9J2MwMXg55jCq1pWRFn4T96MTTx0si8N2MJi8v7Ib4BkoWrhWA5Qn0U
KHoh2irIiJ128sdsPn5eR0mJCQ4AC8CUzjnRi+RTX+YQPr8Y86ISAGjKj28u+63PkKE65uF8IMeQ
KAIC3mQ3NTnS5QsX9tAAw0b2eoHxyBUenyNcMSTIv6d/BV5HjDNjyH90tY2sl4vw/F8+jXPL/XoD
YEoi7ud2joMMu/vHgJxUayWB7gLxzOuU3hCtYSjGIBDhmLW+AauFz9UgByW3e/0QEX8mE3uxCfQo
fPTyqsomoLNSsmJ1Uu1hs41uNfxVHLB4XjibcWMChFeUh130e0LLZ9sIYR1ANf0xNo6z31fSSNOv
/LoyPIw7m0RKjnn804dwQpwWJcEyarOFDbuD/vOiP/kddImiUPzbqCljEJkFFLa4+AujW0Jih7kP
2djPnYKmWAUO22mSiprMzeSSGZBC34qV1RAX6rUPYTK/XmDQEcJVA7JQR99HUNCxhIewduf3ScX+
7x6DSVj5GbmApdLaTPiuIyeqlGc5lhLb54CCo+z+mag80CqNKMSeOE7WztLQfMQBZopi3UzkkUT9
WscMOA6XyK/1yr6RYBxbmgCFxOO0Vx6TyXe60feDhGgtnvO8Gq2Yqggigqr+CyxjJXY8R/loPFac
kfuZEyOUB8CR432DUezyJEoGVqpYtctcxHPLE93q/xyZd8tlRomwBcxvMLGNlishxqUW1fn9otoL
CqeoksQszXSYXaVbKs/+vPegy8294yl8sWrwR2H6f15B6YUX9Zg5zh9LdMwljE7hUKpdpk/deKcK
g9j4ghncLxm1HT6cLBVEPOyDK79UchAEOJJI165j3ykDApUWXNbyYzbzuIuIMLMA9ENEuDNgiU4k
Zu4Yw6ICyE7qCB7kQjsiNvyxY5oR1pJuzQ8N3FV4kYC+azASGqff8ZkHBso7QLCsic+lucjT+Fz+
EiyWL+ZxXVmEL7iYbqNgLfuMpfDhUZVPY/bjkMmzDS0Lvvap1y1emKz0X6QiHZbY/Ow8T2yWlgU0
6qazLDwTR6SKjstcn5o0yjiqxOS2DvhIIUPfZR5FVFySDIT/FG5EcYbYOERj0H9mx+agGrAqprX+
OBHWaq4gHur1B2FgtJSptUgapJO+d0KpdwcvTEh2cARiObfjywtku3XKGRD6gP5uONP4LgsmHQoW
VYTdC19zteOmXdzktMntz+nYr/9I+Ioi3rhJMuS0c+RkdLwl9YUI1h54VlaUr+ktLogEt6naRAr1
2zyXrdGmQxRyiK4HaxLZz2G3b+t6jirtlWeqU4h8sTPbL0J5qUzYsX/mB/F5ycjQs6PKM7vL5YFG
uB4TG/86j+12vZv17dwWf9ncc63ZFW3e/bW+6pRgowp8HmfwPl34KVRNLgF9OO9QbXQ9/bMO33xm
IV0P/ya4+3PIkCNoTIkcMcJjn6gwCAZc9I0tKprvdKbf2Lrbrc0QMr5fAHzqTGUEduHx4icNUSMW
/tLQfj6OoPPIgxBDyQ0VCM1jZxLIXxr83QiPJ35PWc8veNF4dpjalLXdSnjY0XPwvPsBkna2hbK1
ti1Fj8m+zUT3F/s17mZg5ce2DJsayMEQ1ODufnMPgVIlzUfgZXlsayz8/HmpAPMopA1KfR0QcvCr
89kq9N+nledyi9eiImC2yk38tXisBH8BauybI+v7qSL2RWE1YQij6TeVBRzXB61QUZeaEITPYusU
oAL9EgRuZiQrl8r3Cbpl9r5Lu8QPsNBsSUr5xVq0JdN/lPegNbXGuRjYMuGnErEqMbEelLFppRK2
UWg3Ml9X2UuU71nyQ1JBPTL6GEO49joFjrltLXyOXcbZHv2dgo9CfzEzckFS3yj+Tg0t/m4jIBEt
g9g/nB0slkDHbEMHXmRIBwxspuOZbWtjyubUkRtibQsBJdET3mT8Or8egl4BTo9oO9XaUY5zZaW9
MCUKWR7guY2ZZdOemHgZXxCAj757q9JN+HHUofTU0D2eZgh1pQwYXjS7Kov+ANM10/zxMfrvICr+
h4c8FoVv/iUUVTNS0MiWRR+2E2QPcGaFRdxmSUBLkhL7gTCU2YuiSd81uLSSRn/9SBiHFMJFrAAn
B0Q0J/y9ESoKPIBnX2cikzXUUyYpZ/9arBhVlmO5zYXUYx4AsTQ2BiNVtHFxoVJolE5BMJ6oiDnG
uJqjUqIWx+qNRgkKuFA5BWfDDt/g2fQvyJAZk6EyQyKswirppIVAl8sX9mp/wrCWwQk+tC9gyijM
m9wM40pdUgiCTv1VHBq+7wj/hA6ONPXxT+Up4OH4sQpu+sXgP7TiHblYnRFgipNpADpebNXZMsjQ
uNpsAEe0E5pBBannHBYw134ztMxTkoaMaxBLisn9nmv1XzEKiYahmw3ZiNP2oT/6SRgIP0ltwDTc
xpcjAT2RReNpTK0ckuix4ZIwMnXLCLlNVlsPFT5n91f6/wy1sMhS5/m2XGS/ISwqI1TCBRCb1o5J
Jw5URyM664+bpfkGBae4/XxIsX9Oy4pL8kPeCBaY+FKW2EUNBq1I5S0zKf9QkDA7dQVfS1a9I0AM
kQzlUWoUDWjtKIHyKMaWoAMIKmbABQd/B0Jv/Ak6wL13SARUlfPqMIqBSOmuUzLNwxw3N1FQdi0P
kCa/0gJZ0plLA62+c/5jbcH9c7aTjIwci4MI6ZjAUx6EXqABr567IKM7b6KaNT+XPrjYbZt7VUQc
U452Pp/v89Q1n362LRIyrTZbT2T7F+juRh0xBEqceibbx5wh75ZGzRdoHUXh4qBYCtLSHJiq+f9K
abwxy5aOeCaXS34uxReahV6+COQcUBtYrD6H7UWPcKWr3LV1AO7f2SUTJhGEn8+LXKuPD4WtOCZQ
w+OV+jLZfzNJGw4o3QK4PCiiFexAIn79DP+q5J2nKeuXBt77GGS4zuj+VK57EfpB7ydSfc/1Iqoo
joilB2r0ifbIRI2CGcD7+74KFOPb3t/9lMbuVP2JP70wPrzWugIhrGRI62yvV++vieWinvqFH5je
Q86PkZ6kYUnWnbmdg6LC1HCELrh3qTxo4kzqczgxLDvtWW8FQ7r5WEI5xkg6V95lxGy7bX+Wrr5z
NQu5REEVZIjvL+O+USbhmOf70D2hRWblfDvTWkZ7sRFNev/csaW=