-- Geotargeted Results in tblconfiguration
INSERT INTO tbldomain_lookup_configuration (`registrar`, `setting`, `value`, `created_at`, `updated_at`) VALUES ('WhmcsWhois', 'geotargetedResults', 'on', NOW(), NOW());
