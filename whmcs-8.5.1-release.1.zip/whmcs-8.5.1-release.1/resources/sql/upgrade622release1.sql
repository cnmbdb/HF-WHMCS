INSERT INTO `tblconfiguration` (`setting`, `value`) VALUES ('CutUtf8Mb4', 'on');

