-- New Telephone Dropdown Setting
INSERT INTO `tblconfiguration` (`setting`, `value`) VALUES ('PhoneNumberDropdown', '1');
