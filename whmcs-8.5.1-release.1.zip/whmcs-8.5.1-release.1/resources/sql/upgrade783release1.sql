UPDATE `tblclients` SET `state`='ARABA/ÁLAVA' WHERE `state`='ARABA';
UPDATE `tblcontacts` SET `state`='ARABA/ÁLAVA' WHERE `state`='ARABA';
UPDATE `tblquotes` SET `state`='ARABA/ÁLAVA' WHERE `state`='ARABA';
UPDATE `tbltax` SET `state`='ARABA/ÁLAVA' WHERE `state`='ARABA';
