UPDATE tblemailtemplates SET subject = 'Credit Card Payment Due' WHERE name = 'Credit Card Payment Due' AND subject = 'Invoice Payment Reminder';

