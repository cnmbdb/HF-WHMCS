UPDATE `tblclients` SET `state`='Yukon' WHERE `state`='Yukon Territory';
UPDATE `tblcontacts` SET `state`='Yukon' WHERE `state`='Yukon Territory';
UPDATE `tblquotes` SET `state`='Yukon' WHERE `state`='Yukon Territory';
UPDATE `tbltax` SET `state`='Yukon' WHERE `state`='Yukon Territory';

UPDATE `tblclients` SET `state`='Uttarakhand' WHERE `state`='Uttaranchal';
UPDATE `tblcontacts` SET `state`='Uttarakhand' WHERE `state`='Uttaranchal';
UPDATE `tblquotes` SET `state`='Uttarakhand' WHERE `state`='Uttaranchal';
UPDATE `tbltax` SET `state`='Uttarakhand' WHERE `state`='Uttaranchal';
