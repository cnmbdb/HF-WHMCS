<?php
declare(strict_types=1);

namespace App\Service\Impl;


use App\Service\User;

class UserService implements User
{

}