<?php
declare (strict_types=1);

return [
    'cache' => '0',
    'cache_expire' => '60',
    'icp' => '',
];