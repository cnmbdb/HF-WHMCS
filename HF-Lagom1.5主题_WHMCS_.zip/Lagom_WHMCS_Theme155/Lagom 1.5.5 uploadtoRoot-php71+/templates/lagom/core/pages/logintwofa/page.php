<?php

return [
    'display_name' => 'Login Two Factor Auth',
    'description'  => 'Login Two Factor Auth',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
