<?php

return [
    'display_name' => 'Logout',
    'description'  => 'Logout Page',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
