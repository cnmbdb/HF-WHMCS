<?php

return [
    'display_name' => 'Support Ticket - Departments',
    'description'  => 'Support Ticket - Departments',
    'preview'      => '',
    'group'        => 'Client Area',
    'variables'    => [

    ],
];