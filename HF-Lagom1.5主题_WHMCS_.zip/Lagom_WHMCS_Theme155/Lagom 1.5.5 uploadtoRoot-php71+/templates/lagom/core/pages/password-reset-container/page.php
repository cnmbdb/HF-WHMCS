<?php

return [
    'display_name' => 'Password Reset',
    'description'  => 'Password Reset',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
