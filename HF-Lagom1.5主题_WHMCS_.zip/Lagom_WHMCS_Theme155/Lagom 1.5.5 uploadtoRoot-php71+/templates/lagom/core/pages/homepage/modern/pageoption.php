<?php

return [
    'display_name' => 'Modern',
    'description' => 'Modern - Homepage',
    'preview' => 'thumb.png',
    'variables' => [
        
    ],
];


