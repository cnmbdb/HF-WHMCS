<?php

return [
    'display_name' => 'Two Factor New Backup Code',
    'description'  => 'Two Factor New Backup Code',
    'group'        => 'Client Area',
    'preview'      => '',
    'variables'    => [

    ],
];
