<?php

// has site.css
return [
    'homepage'                          => [true],
    'store/ssl/index'                   => [true],
    'store/ssl/dv'                      => [true],
    'store/ssl/ov'                      => [true],
    'store/ssl/ev'                      => [true],
    'store/ssl/wildcard'                => [true],
    'store/ssl/competitive-upgrade'     => [true],
    'store/weebly/index'                => [true],
    'store/spamexperts/index'           => [true],
    'store/sitelock/index'              => [true],
    'store/codeguard/index'             => [true],
    'store/sitelockvpn/index'           => [true],
    'store/marketgoo/index'             => [true],
    'store/ox/index'                    => [true],
];