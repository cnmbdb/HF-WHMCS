<?php

return [
    'display_name' => 'Banner',
    'version'      => '1.4.0',
    'preview'      => 'thumb.png',
    'order' => 3,
    "variables" => [
        'bodyClass' =>  'lagom-layout-condensed lagom-layout-banner',
        'type'      =>  'condensed-banner',
        'modules' => [
            //'vultr',
        ],
    ]
];