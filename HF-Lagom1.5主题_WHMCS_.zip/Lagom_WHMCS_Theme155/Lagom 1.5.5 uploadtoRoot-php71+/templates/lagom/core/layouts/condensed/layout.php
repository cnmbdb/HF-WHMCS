<?php

return [
    'display_name' => 'Condensed',
    'version'      => '1.4.0',
    'preview'      => 'thumb.png',
	'order' => 2,
    "variables" => [
        'bodyClass' =>  'lagom-layout-condensed',
        'type'      =>  'condensed',
        'modules' => [
            //'vultr',
        ],
    ]
];