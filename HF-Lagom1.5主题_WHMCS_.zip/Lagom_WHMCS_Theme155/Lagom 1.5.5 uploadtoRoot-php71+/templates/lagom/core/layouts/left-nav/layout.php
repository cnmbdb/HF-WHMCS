<?php

return [
    'display_name' => 'Left',
    'version'      => '1.4.0',
    'preview'      => 'thumb.png',
	'order' => 4,
    "variables" => [
        'bodyClass' =>  'lagom-layout-left',
        'type'      =>  'navbar-left',
        'modules' => [
            //'vultr',
        ],
    ]
];