<?php

return [
    'displayName'  => 'Default',
    'version'      => '1.4.0',
    'preview'      => 'thumb.png',
	'order' => 1,
    "variables" => [
        'bodyClass' =>  '',
        'type'      =>  'default',
        'modules' => [
            //'vultr',
        ],
    ]
];